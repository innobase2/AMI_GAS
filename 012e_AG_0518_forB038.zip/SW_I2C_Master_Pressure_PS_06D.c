#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"

void Init_I2C_Pressure(void);
void Read_Pressure_Sensor(void);

void Init_I2C_Pressure(void)
{
    SET_SV_OUT;
//      4	P1.6/UCB0SIMO/UCB0SDA/TA0.1/S1	        SDA_PRESSURE
//      5	P1.7/UCB0SOMI/UCB0SCL/TA0.2/S0	        SCL_PRESSURE  
    I2C_PRESSURE_SEL
    // Configure USCI_B0 for I2C mode
    UCB0CTLW0 |= UCSWRST;                     // Software reset enabled
    UCB0CTLW0 |= UCMODE_3 | UCMST | UCSSEL__ACLK |UCSYNC;         // I2C mode, Master mode, sync
    UCB0CTLW1 |= UCASTP_2;                    // Automatic stop generated
                                              // after UCB0TBCNT is reached
    UCB0BRW   = 0x0000;                       // baudrate = ACLK / 8
    UCB0TBCNT = 0x0002;                       // number of bytes to be received
    UCB0I2CSA = 0x004C;                       // Slave address
    UCB0CTL1 &= ~UCSWRST;
    //UCB0IE |= UCRXIE | UCNACKIE | UCBCNTIE; 
    CLR_SV_OUT;
}

void Read_Pressure_Sensor(void)
{
    SET_SV_OUT;
    UCB0STATW &=~       UCBUSY;
    Pressure.Counter       = 0;
    Pressure.Done          = 0;
    Pressure.Delay_on      = 1;      
}


#pragma vector = USCI_B0_VECTOR
__interrupt void USCI_B0_ISR(void)
{
  SET_TEST3;
  switch(__even_in_range(UCB0IV, USCI_I2C_UCBIT9IFG))
  {
    case USCI_NONE:          break;         // Vector 0: No interrupts
    case USCI_I2C_UCALIFG:   break;         // Vector 2: ALIFG
    case USCI_I2C_UCNACKIFG:                // Vector 4: NACKIFG
      UCB0CTL1 |= UCTXSTT;                  // I2C start condition
      break;
    case USCI_I2C_UCSTTIFG:  break;         // Vector 6: STTIFG
    case USCI_I2C_UCSTPIFG:  break;         // Vector 8: STPIFG
    case USCI_I2C_UCRXIFG3:  break;         // Vector 10: RXIFG3
    case USCI_I2C_UCTXIFG3:  break;         // Vector 12: TXIFG3
    case USCI_I2C_UCRXIFG2:  break;         // Vector 14: RXIFG2
    case USCI_I2C_UCTXIFG2:  break;         // Vector 16: TXIFG2
    case USCI_I2C_UCRXIFG1:  break;         // Vector 18: RXIFG1
    case USCI_I2C_UCTXIFG1:  break;         // Vector 20: TXIFG1
    case USCI_I2C_UCRXIFG0:                 // Vector 22: RXIFG0
      Pressure.Mem[Pressure.Counter] = UCB0RXBUF;           // Get RX data
      Pressure.Counter++;
      if(Pressure.Counter == 2)
      {
        Pressure.Done = 1;
        UCB0IE &= ~( UCRXIE | UCNACKIE | UCBCNTIE ) ;
        Stflag.bit.SMclk_Active = 0; 
        __bic_SR_register_on_exit(LPM3_bits); // Exit LPM3
      }
      break;
    case USCI_I2C_UCTXIFG0:  break;         // Vector 24: TXIFG0
    case USCI_I2C_UCBCNTIFG:                // Vector 26: BCNTIFG
      P1OUT ^= BIT0;                        // Toggle LED on P1.0
      break;
    case USCI_I2C_UCCLTOIFG: break;         // Vector 28: clock low timeout
    case USCI_I2C_UCBIT9IFG: break;         // Vector 30: 9th bit
    default: break;
  }
  CLR_TEST3
}
