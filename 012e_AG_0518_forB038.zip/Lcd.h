/*
	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21
COM1	COM1				S7	S9	1D	S8	7A		6A	T4	5A	T3	T2	4A		3A	S10	2A	S11
COM2		COM2			S5	1E	1C	S6	7B	7F	6B	6F	5B	5F	T1	4B	4F	3B	3F	2B	2F
COM3			COM3		S1	1G	1B	S4	7C	7G	6C	6G	5C	5G	D1	4C	4G	3C	3G	2C	2G
COM4				COM4	S2	1F	1A	S3	7D	7E	6D	6E	5D	5E	D2	4D	4E	3D	3E	2D	2E
LDC Name				SEG0	SEG1	SEG2	SEG3	SEG4	SEG5	SEG6	SEG7	SEG8	SEG9	SEG10	SEG11	SEG12	SEG13	SEG14	SEG15	SEG16
MCU Pin #				15	3	2	14	77	76	75	74	73	72	29	45	44	43	42	31	30
MCU Mem					LCDM17	LCDM2		LCDM17	LCDM3		LCDM4		LCDM5		LCDM14	LCDM6		LCDM7		LCDM13	
					S32	S2	S3	S33	S4	S5	S6	S7	S8	S9	S26	S10	S11	S12	S13	S24	S25

*/
#include <msp430.h> 

//;--- segment definitions _ 
#define		    AA       		0x01
#define     	BB       		0x02
#define     	CC       		0x04
#define     	DD       		0x08

#define     	EE       		0x80
#define     	FF       		0x20
#define     	GG       		0x40
#define     	HH       		0x10

//;--- segment definitions _ 
#define		    AA1       		EE
#define     	BB1       		GG
#define     	CC1       		FF
#define     	DD1       		HH

#define     	EE1       		BB
#define     	FF1       		DD
#define     	GG1       		CC
#define     	HH1       		AA

#define         CHAR_0          AA+BB+CC+DD+EE+FF                // displays "0"
#define         CHAR_1          BB+CC                            // displays "1"
#define         CHAR_2          AA+BB+GG+EE+DD                   // displays "2"
#define         CHAR_3          AA+BB+CC+DD+GG                   // displays "3"
#define         CHAR_4          BB+CC+FF+GG                      // displays "4"
#define         CHAR_5          AA+CC+DD+FF+GG                   // displays "5"
#define         CHAR_6          AA+CC+DD+EE+FF+GG                // displays "6"
#define         CHAR_7          AA+BB+CC+FF                      // displays "7"
#define         CHAR_8          AA+BB+CC+DD+EE+FF+GG             // displays "8"
#define         CHAR_9          AA+BB+CC+FF+GG+DD                // displays "9"

#define         CHAR1_0         AA1+BB1+CC1+DD1+EE1+FF1                // displays "0"
#define         CHAR1_1         BB1+CC1                                // displays "1"
#define         CHAR1_2         AA1+BB1+GG1+EE1+DD1                    // displays "2"
#define         CHAR1_3         AA1+BB1+CC1+DD1+GG1                    // displays "3"
#define         CHAR1_4         BB1+CC1+FF1+GG1                        // displays "4"
#define         CHAR1_5         AA1+CC1+DD1+FF1+GG1                    // displays "5"
#define         CHAR1_6         AA1+CC1+DD1+EE1+FF1+GG1                // displays "6"
#define         CHAR1_7         AA1+BB1+CC1+FF1                        // displays "7"
#define         CHAR1_8         AA1+BB1+CC1+DD1+EE1+FF1+GG1            // displays "8"
#define         CHAR1_9         AA1+BB1+CC1+FF1+GG1+DD1                // displays "9"
#define         CHAR1_A         AA1+BB1+CC1    +EE1+FF1+GG1            // " A "
#define         CHAR1_b                +CC1+DD1+EE1+FF1+GG1            // " b "
#define         CHAR1_n                 CC1    +EE1    +GG1            // " n "  // ���� 
#define         CHAR1_r                         EE1    +GG1            // " r "
#define         CHAR1_t                     DD1+EE1+FF1+GG1            // " t "



#define         DI1_MEM              LCDM2
#define         DI2_MEM              LCDM13 
#define         DI3_MEM              LCDM7
#define         DI4_MEM              LCDM6
#define         DI5_MEM              LCDM5 
#define         DI6_MEM              LCDM4
#define         DI7_MEM              LCDM3
#define         S1TO8_MEM            LCDM17
#define         S9_MEM               LCDM2
#define         T4_MEM               LCDM4
#define         T3_MEM               LCDM5
#define         T12_D12_MEM          LCDM14
#define         S10_MEM              LCDM7
#define         S11_MEM              LCDM13

#define         S1                  CC              
#define         S2                  DD
#define         S3                  EE//HH
#define         S4                  GG
#define         S5                  BB
#define         S6                  FF
#define         S7                  AA
#define         S8                  HH
#define         S9                  AA
#define         S10                 HH
#define         S11                 HH

#define         ICON_S1                  S1              
#define         ICON_S2                  S2
#define         ICON_S3                  S3
#define         ICON_S4                  S4
#define         ICON_S5                  S5
#define         ICON_S6                  S6
#define         ICON_S7                  S7
#define         ICON_S8                  S8
#define         ICON_S9                  S9
#define         ICON_S10                 S10
#define         ICON_S11                 S11

#define         T1                  BB
#define         T2                  AA
#define         T3                  HH
#define         T4                  HH

#define         D1                  CC
#define         D2                  DD

#define         ROLL_A              AA1
#define         ROLL_B              BB1
#define         ROLL_C              CC1
#define         ROLL_D              DD1
#define         ROLL_E              EE1
#define         ROLL_F              FF1

#define     MASK_NUM                AA+BB+CC+DD+EE+FF+GG