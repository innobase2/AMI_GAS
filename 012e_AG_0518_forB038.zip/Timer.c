#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"
#include "Meter_Unit.h"
extern inline void Make_same_Frame(uint16 ,uint8 );
extern void Nb_tx_case(void);
extern void Nb_Tx_ComProcess(const uint8 *Tx_temp_ptr);
extern const uint8 _AT_MLWSREGIND_SET[];

void Timer_Init(void);

void Timer_Init(void)
{
  
    //TA0CCR0 = 32768>>3;                         // 8 Hz inerval timer
    //TA0CCTL0 = CCIE;                            // TACCR0 interrupt enabled

    TA0CTL = TASSEL__ACLK | MC__CONTINUOUS  | TACLR; 
    
    TA1CTL = TASSEL__ACLK | MC__CONTINUOUS | TACLR;
    
    TA2CTL = TASSEL__SMCLK | MC__CONTINUOUS | TACLR;
    
    TA3CTL = TASSEL__ACLK | MC__CONTINUOUS | ID__8 | TACLR;  // 32768 / 8 = 4096 hz 
    
    TB0CCTL2 = CM_3 | CCIS_0 | SCS | CAP | CCIE;
                                            // Capture both.edge,
                                            // Use CCI2A=ACLK,
                                            // Synchronous capture,
                                            // Enable capture mode,
                                            // Enable capture interrupt

    TB0CTL = TBSSEL__ACLK | MC__CONTINUOUS; // Use SMCLK as clock source,
                                            // Start timer in continuous mode
    
    TA0CCR0 = 32768>>3;                     // 32 Hz tick timer
    TA0CCTL0 = CCIE;                        // TACCR0 interrupt enabled
  
}

// Timer0_A0 interrupt service routine
#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer0_A0_ISR (void)
{
  SET_TEST3
  TA0CCR0 += 32768>>5;       // 32 HZ Ȯ��
  if(Botton.bit.P_test)      //  port test 
  {
    if(READ_RETURN == 0) 
    {
      P_test_32hz_counter++;
      if(toggle_counter_0_5++ > 16 ) 
      {
        toggle_counter_0_5 = 0;
        if(Com2.bit.Key_5sec_Ok == 0)
        {
          if(FTM_mode_flag == 0)   // FTM : Factory Test Mode������ ���� ������ toggle �� ��
            S9_MEM ^= S9 ;   // �����Ǹ� toggle ���� 
        }
      }
      if( P_test_32hz_counter > (32*5) )
      {
        P_test_32hz_counter = ( 32*5 );
        if(Com2.bit.Five_Sec_Watting == 1)
        {
          if(Com2.bit.Key_5sec_Ok == 0)
          {
            Com2.bit.Key_5sec_Ok = 1;
            Botton.bit.Return ^= 1;
          }
        }
      }
    }
    else 
    {
      Com2.bit.Five_Sec_Watting = 0;
      Com2.bit.Key_5sec_Ok      = 0;  
      if(P_test_32hz_counter < 16)_NOP();       // 0.5�� �̸�
      else if( P_test_32hz_counter > ( 32*5 ) ) // 5�� �̻�
      {
        //Botton.bit.Return ^= 1;
      }
      else
      {
        Com1.bit.Button_Com  = 1;
        OK_Counter = 0;                            // OK�� �޴� counter.
        if(Com2.bit.Comm_Doning) 
        {
          Com2.bit.Watting_COM = 1;                 // ��� �߿� ��� �Ѵ�.
        }
        else 
        {
          Com.bit.On_Module     = 1;                 // main���� ��� ����!
          Nb_Retry_count = 0;
          T_data.Basic.Mem.Seq.mem.Recount = 0;
        }
        //Com1.bit.Button_Com  = 1;                 // ��ŵ����͸� ������ �ø���
        if(Botton.bit.Unused_test) S9_MEM |= S9 ;
        else
        {
          if(FTM_mode_flag == 0)   // FTM : Factory Test Mode������ ���� ������ toggle �� ��
            S9_MEM &= ~S9 ;
        }
      }
      Botton.bit.P_test = 0;
      P_test_32hz_counter =0;      
    }
  }
  else ;
  if(Pressure.Delay_on)
  {
    Pressure.Counter++;
    if( Pressure.Counter > 5)
    {
      Pressure.Delay_on = 0;
      UCB0IE |= UCRXIE | UCNACKIE | UCBCNTIE;
      while (UCB0CTL1 & UCTXSTP);             // Ensure stop condition got sent
      UCB0CTL1 |= UCTXSTT;                    // I2C start condition
      Pressure.Counter = 0;         
    }
  }else;
  if(Battery.ADC_en)
  {
    if(Battery.Counter++ > 4) // 66ms
    {
      Battery.Counter   = 0;
      Battery.ADC_en    = 0;
      
      Battery.ADC_on    = 1;
      
      __bic_SR_register_on_exit(LPM3_bits);      
    }
  }else; 
  if(Guard.bit.Sec10_Lcd_Init)
  {
    if((Botton.bit.Unused_test == 0)&&(Botton.bit.Error_State == 0))
    {
      if(LCD_Init_Counter++ > (32*10))   // 10�� �̻�
      {
          Guard.bit.Sec10_Lcd_Init = 0;
          DI1_MEM = LCD_Tab_Center[0];
      } 
    }
  }else;
//--------------------------------------  
  if(Com1.bit.AT_COPS_Xsec_Watting)
  {
    Cop_watting_Counter++;
    if(Cop_watting_Counter > 32*2)// cops �������� delay..
    {
      Com1.bit.AT_COPS_Xsec_Watting = 0;
      Com1.bit.At_Tx_start = 1;
    }
  }else;
  if(Com1.bit.Creg1_5_Watting)
  {
    Creg1_5_watting_Counter++;
    if(Creg1_5_watting_Counter > 32*( 30 - 1 ))
    {
      Com1.bit.Creg1_5_Watting = 0;
      Reboot_Counter++;
      if( Reboot_Counter >= 2)// 1���� ū ��� �׳� �����н� 
      {   
          Nb_old_AT_case = AT_case;
          AT_case        = _AT_END_NUM;	//reset�� �ص� �ȵǸ� ���� �ֱ�� �ѱ�...
          Nb_Retry_count = 0;
      }
      else  // ���� ��� ... �̻������� page2��  ����
      {
        if( Com2.bit.SendingDataSequence) // ���ſ��� �°�� setp3
        {
          Com2.bit.SendingDataSequence = 0;//  �̷��� STEP2�� ���� �����ϴ�....
          Com1.bit.Nb_Need_Step2 = 1;      //  �̷��� STEP2�� ���� �����ϴ�....
          Com2.bit.Return_Step_3 = 1;
		  Com3.bit.RetransmisstionAfterReset = 1;
        } 
        Nb_old_AT_case   = AT_case ;
        AT_case = _AT_NRB_NUM;
        Com1.bit.At_Tx_start = 1;
        Nb_Retry_count = 0;
      }        
    }
  }else;
  if(Com2.bit.Module_Reinit)
  {
    ReInit_counter++;
    if(ReInit_counter > 32*1)
    {
      Com2.bit.Module_Reinit = 0 ;
      SET_MODEM_RESET;
      ReInit_counter = 0;
      Com2.bit.Re_start      = 1;
    }
  }else; 
  if(Com2.bit.Re_start)
  {  
    ReInit_counter++;
    if(ReInit_counter > 32*5)
    {    
      Com2.bit.Re_start = 0;
      ReInit_counter    = 0;
      AT_case  = _AT_Q_CEREG_NUM ;
      Com1.bit.Nb_Need_Step2 =1;
      Com2.bit.Module_Fail   = 0;
	  Com3.bit.RetransmisstionAfterReset= 1;
	   Com1.bit.At_Tx_start = 1;
    }
  }else;
  if(Com3.bit.Iligal_Watting )
  {
    Return_Ilegal_counter++;
    if( Return_Ilegal_counter > 32 * 9)
    {
      Com3.bit.Iligal_Watting = 0;
    }
  }
//-----------------------------------------  
  if(Guard.bit.Tx_Icon_On)
  {
    Tx_icon_on_Counter--;
    if(Tx_icon_on_Counter <= 1)
    {
      Guard.bit.Tx_Icon_On = 0;
      S10_MEM   &=~ S10;
      S11_MEM   &=~ S11;
    }
  }else;
  if(Guard.bit.Rx_Icon_On)
  {
    Rx_icon_on_Counter--;
    if(Rx_icon_on_Counter <= 1)
    {
      Guard.bit.Rx_Icon_On = 0;
      S1TO8_MEM &=~ S6;
    }
  }else;  
  if(Guard.bit.Power_ON)
  {
    Power_On_Counter++;
    if(  Power_On_Counter > (32 * 5) )
    {
      Power_On_Counter = 400;
      Guard.bit.Power_ON = 0;
    }
  }else;
  if(Guard.bit.RF_Module)
  {
    RF_Module_Counter++;
    if(  RF_Module_Counter > (32 * 15) ) // 32 * �� �ð�.....max 65563 / 35 
    {
      S10_MEM   &=~ S10;
      S11_MEM   &=~ S11;
      RF_Module_Counter      = 400;
      Guard.bit.RF_Module    = 0;
      Com1.bit.At_Init_done  = 1;   // �̷� ���� ������ �ð��� ������.      
    }
  }else;
  if(Guard.bit.Sequence)
  {
    Sequence_Counter++;
    if(  Sequence_Counter > (32 * 90) )
    {
      Guard.bit.Sequence           = 0;
      Sequence_Counter             = 0;
      Com2.bit.Data_tx_ready_Ok    = 0;
      Com2.bit.Comm_Doning         = 0;
    }
  }else;
  if(Com3.bit.WaitPreDeregRsp)
 {
 	 WattingDereg_Counter++;
	 if(WattingDereg_Counter > (32 * 7))
	 {	
		 Com3.bit.WaitPreDeregRsp = 0;
		 Nb_old_AT_case = AT_case;
		 AT_case				= _AT_MLWREG_REQ;
		 Com2.bit.SendingDataSequence = 1;		 
		 Com1.bit.At_Tx_start = 1; 
		 Nb_Retry_count = 0; 
	}
 }
  if(Com3.bit.DelayedPostDereg)
 {
 	 DelayedPostDeregReqCounter++;
	 if(DelayedPostDeregReqCounter > (32 * 3))
	 {	
		 Com3.bit.DelayedPostDereg = 0;
		 Nb_old_AT_case = AT_case;
		 AT_case				= _AT_MLWPOST_DEREG_REQ;
		 Com2.bit.SendingDataSequence = 1;
		 Sequence_Counter = 0;
		 Com1.bit.At_Tx_start = 1; 
		 Nb_Retry_count = 0;
	}
 }	
  __bic_SR_register_on_exit(LPM3_bits);
  CLR_TEST3
}

// Timer0_A1 Interrupt Vector (TAIV) handler
#pragma vector=TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{
  SET_TEST3
  switch(__even_in_range(TA0IV, TA0IV_TAIFG))
  {
    case TA0IV_NONE:   break;               // No interrupt
    case TA0IV_TACCR1:                      // used Buzzer Interval 0.5 Sec
      TA0CCR1 += 32768>>1;                  // ���Ӱ����? LED + ������ 0.5 �� ON �ϰ� 
                                            // 1.5 �� OFF �ϴ� ���� 1 �ֱ�� ���� ��� �ݺ��ϴ� ���� ���Ѵ�.
      Stflag.bit.Buzzer_Set ^=1;
      if(Stflag.bit.Buzzer_Set == 0)
      {
        TA0CCR1 +=32768;
      }
      
      if( Stflag.bit.Conti_Buzzer == 0)
      {
        Buzzer_05s_counter++;
        if(Buzzer_05s_counter >=( Buzzer_Sec_counter * 2))
        { // stop Condition
          CLR_LED;
          CLR_BUZZER;
          Stflag.bit.Buzzer_Doing = 0;
          TA2CCTL0 = 0;
          TA0CCTL1 = 0;
        }
      }
      break;               
    case TA0IV_TACCR2: 
      break;               // CCR2 not used
    case TA0IV_3:      break;               // reserved
    case TA0IV_4:      break;               // reserved
    case TA0IV_5:      break;               // reserved
    case TA0IV_6:      break;               // reserved
    case TA0IV_TAIFG:                       // overflow
      P1OUT ^= BIT0;
      break;
    default: break;
  }
  CLR_TEST3
}

// Timer2_A0 interrupt service routine
#pragma vector = TIMER1_A0_VECTOR
__interrupt void Timer1_A0_ISR (void)
{
  SET_TEST3;
  TA1CCR0       = TA1R + 3;
  if(Stflag.bit.Pulse_H_Capture)
  {
    if(READ_PULSE_IN)
    {
      Capture_D_Counter++;
      if(Capture_D_Counter>5)
      {
        Stflag.bit.Pulse_H_Stable = 1;
        TA1CCTL0        = 0;        // stop timer
      }
    }
    else
    {
      Capture_D_Counter = 0;
      TA1CCTL0        = 0;
    }        
  }
  if(Stflag.bit.Pulse_L_Capture)
  {
    if(READ_PULSE_IN == 0)
    {
      Capture_D_Counter++;
      if(Capture_D_Counter>5)
      {
        Stflag.bit.Pulse_L_Stable = 1;
        TA1CCTL0        = 0;            // stop timer
        if(Stflag.bit.Pulse_H_Stable)
        {
          Stflag.bit.Pulse_H_Stable = 0;
          Stflag.bit.Inc_Pulse_Counter = 1;
          {
            St4_Unuse_1min_counter       = 0; // �̻�� �Ǵܿ� ����ϴ� �� COUNTER �ʱ�ȭ , �޽��� ��� ������ �̻�� �ƴϴ�.

            Input_Pulse_Counter++;            // 250CC COUNTER
           
            if(Input_Pulse_Counter >= L_PLUSE_COUNTER ) // �޽��� ���� 1L�� �����ߴ�.
            {
              SET_TEST1
              Input_Pulse_Counter = 0;
      //        Stflag.bit.LCD_display = 1; // for Reflash ������ ���� ���� �ʴ´�. �׷��Ƿ� ������� �ʴ´�.
              // Hex ���� ��ƾ 
              Hex_Counter_L++   ;           
              if( __get_SR_register() & 1 ) // get carry bit ,Set if there is a carry from the MSB of the result, reset otherwise
              {                             // CARRY BIT�� OVERFLOW���� �߻� �Ѵ�.
                  Hex_Counter_H++;//00000.000 
              }
              else ;
              // BCD ���� ��ƾ---------
              asm("   SETC  "); 
              asm("   DADC.W  &Dec_Counter_L"); // Dec_inc meter count   0x0000 ~ 0x9999
              if(Dec_Counter_L == 0 ) 
              {
                  asm("   SETC  "); 
                  asm("   DADC.W  &Dec_Counter_H");
                  if(Dec_Counter_H == 0)
                  {
                      Dec_Counter_L = 1;

                      Hex_Counter_H = 0;
                      Hex_Counter_L = 0; // 10CC * 100 = 1000 CC = 1L
                      Hex_Counter_025 = 0;
                  }
              }// BDC ��ƾ ���� --------
              CLR_TEST1
            }     
            U250_counter++;       // max 65535 * 0.25L = 262,140 L , 262.140 m3
            Sum_Q_Per10Sec++;     // ���� ���� ��꿡 ��� 10�ʴ� ���� �޽� 
          }         

          __bic_SR_register_on_exit(LPM3_bits);

        }            
      }
    }
    else
    {
      Capture_D_Counter = 0;
      TA1CCTL0          = 0;
    }        
  }
  CLR_TEST3  
}

// Timer2_A0 interrupt service routine
#pragma vector = TIMER2_A0_VECTOR
__interrupt void Timer2_A0_ISR (void)
{
  SET_TEST3
  TA2CCR0 = TA2R+110;
  //SET_TEST2;
  if(Stflag.bit.Buzzer_Set)
  {
    XOR_BUZZER;
    //XOR_TEST1;
    if(FTM_mode_flag == 0)   // FTM : Factory Test Mode������ Buzzer �︱ �� LED ���� �� ��
      SET_LED;
  }
  else 
  {
    CLR_BUZZER;
    CLR_LED;
  }
  CLR_TEST3
}

// Timer0_B3 CC1-4, TB Interrupt Handler

#pragma vector = TIMER0_B1_VECTOR
__interrupt void TIMER0_B1_ISR(void)
{
  SET_TEST3;
  SET_TEST2;
  switch (__even_in_range(TB0IV, TB0IV_TBIFG)) {
    case TB0IV_TB0CCR1:      
      break;
    case TB0IV_TB0CCR2:
      Capture_D_Counter = 0;      
      if(READ_PULSE_IN)
      {
        //PosEdge_Counter = TB0CCR2;
        Stflag.bit.Pulse_H_Capture = 1;
        Stflag.bit.Pulse_H_Stable = 0;
        Stflag.bit.Pulse_L_Capture = 0;
      }
      else
      {
        NegEdge_Counter = TB0CCR2;        
        Stflag.bit.Pulse_L_Capture = 1;
        Stflag.bit.Pulse_L_Stable = 0;
        Stflag.bit.Pulse_H_Capture = 0;    
      }     
      TA1CCR0         = 10 + TA1R ; 
      TA1CCTL0        = CCIE;

      break;
    case TB0IV_TB0IFG:
      break;
    default:
      break;
  }
  CLR_TEST2
  CLR_TEST3
}

// Timer0_A3 interrupt service routine
#pragma vector = TIMER3_A0_VECTOR
__interrupt void Timer3_A0_ISR (void)
{
  SET_TEST3;
  TA3CCTL0 =0 ;
  //uint8 temp_T2A0;
  //temp_T2A0 = Uart_counter ;
  Com1.bit.DPLC_COM = 0;
  Uart_counter++;
  /*
  if( temp_T2A0 >= Defult_retry_count )
    Com1.bit.DPLC_COM = 0;
  else 
  {
    Uart_counter++;
    switch( T_data.Basic.Mem.Command)
    {
      case P_COM_READ :
        Make_same_Frame(P_COM_LENGH ,P_COM_READ) ;        
        break;
       case P_NORMAL_READ :
        Make_same_Frame(P_COM_LENGH ,P_COM_READ) ;        
        break;       
      case P_MODIFY_SUM :      
        Make_same_Frame(P_MODIFY_SUM_LENGH ,P_MODIFY_SUM) ;
        break;
      case P_TIME_SYNC: 
        Make_same_Frame(P_TIME_SYNC_LENGH ,P_TIME_SYNC) ; 
        break;
      case P_COM_INERVAL_SET:
        Make_same_Frame(P_COM_INERVAL_SET_LENGH ,P_COM_INERVAL_SET) ;
        break;
      case P_READ_SAVE_INTVAL_SET:
        Make_same_Frame(P_READ_SAVE_INTVAL_SET_LENGH ,P_READ_SAVE_INTVAL_SET) ; 
        break;
      case P_PRESSURE_INTVAL_SET:
        Make_same_Frame(P_PRESSURE_INTVAL_SET_LENGH ,P_PRESSURE_INTVAL_SET) ; 
        break;
      case P_REQ_RETRY_TIME:
        Make_same_Frame(P_REQ_RETRY_TIME_LENGH ,P_REQ_RETRY_TIME) ; 
        break;
      case P_MODEM_B_SET_DAY:
        Make_same_Frame(P_MODEM_B_SET_DAY_LENGH ,P_MODEM_B_SET_DAY) ;
        break;
      case P_METER_SETUP_R:
        Make_same_Frame(P_METER_SETUP_R_LENGH ,P_METER_SETUP_R) ; 
        break;
      case P_METER_SETUP_W:
        Make_same_Frame(P_METER_SETUP_W_LENGH ,P_METER_SETUP_W);
        break;    
    }
  }
  */
  CLR_TEST3
}

#pragma vector = TIMER3_A1_VECTOR
__interrupt void TIMER3_A1_ISR(void)
{
  SET_TEST3
  uint8 temp_T3A2;  
  switch (__even_in_range(TA3IV, TA3IV_TAIFG))
  {
    case TA3IV_TACCR1:
        TA3CCR1  += ( 12288 ); // 3��
        if(--Valve_working_Sec  == 0 )
        {
        TA3CCTL1 = 0 ; 
        CLR_DRV_OUT   // 
        } 
      break;
    case TA3IV_TACCR2:  //retry-timer
        TA3CCR2  += 4096; // offset 1 sec
        RetrySec_counter--;
        if( RetrySec_counter <=1 )
        {
          TA3CCTL2 = 0 ;
          if(Nb_Retry_count == 0)
          T_data.Basic.Mem.Seq.mem.Recount = 0;
          else ;          
//          Nb_Retry_count++;
          temp_T3A2 = Nb_Retry_count;
          if( temp_T3A2 >= Defult_retry_count )
          {
            if(Com1.bit.At_Init_done)
            {
              // ACK�� ���� �ؼ� �� �޾Ƽ� 
              // restart Module.
              Com2.bit.Comm_Doning = 0;
              //Guard.bit.Sequence   = 0;
              T_data.Basic.Mem.Seq.mem.no--;  // retry�� �� ���� ������ �� ���� �Ŵ�.
              if(OK_Counter == 0 )/// �ѹ��̶� ������ �ö� ����. �ٵ� ok ���� ���� ��¼��....
              {
                HW_Reboot_counter++;
                if(HW_Reboot_counter>=1)
                {
                 Com2.bit.Reboot = 1;
                 TA3CCTL2 = 0;
                }
                else;
              }
            }
            else
            {
            Nb_Retry_count = 0;
            //Com1.bit.At_Init_done = 1;            
            S10_MEM &=~S10;
            S11_MEM &=~S11; 
            }
			if(	AT_case == _AT_MLWDATA_SENDING) //Data�� ������ ��쿡��...
			{
				Com3.bit.DelayedPostDereg =1;
				DelayedPostDeregReqCounter = 0;
			}
			Sequence_Counter = 3000;   // Di-Reg �ؼ� �����.

          }
          else
          {
            Com1.bit.At_Tx_start =1;
            if(Com1.bit.At_Init_done )
            {
              Com.bit.On_Module = 1;
              Com2.bit.Data_tx_ready_Ok = 1;
              T_data.Basic.Mem.Seq.mem.Recount++;
            }
            // retry_coutnt�� �ǵ����� �ʴ´�.
          }
          Nb_Retry_count++;
//          temp_T3A2 = Nb_Retry_count;
        }
        else ;      
      break;
    case TA3IV_TACCR3: // rx-end timer
        TA3CCTL3 = 0;
        Com1.bit.At_Rx_end   = 1; 
        __bic_SR_register_on_exit(LPM3_bits); // Exit LPM3 on reti
      break; 
    case TA3IV_TACCR4:
        {
          
        }
      break;       
    case TA3IV_TAIFG:
      break;
    default:
      break;
  }
  CLR_TEST3  
}

