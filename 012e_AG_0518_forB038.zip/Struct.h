#include "typedef_SM.h"
//#include "Protocol.h"


//  �� ���� �ð� ���� 
typedef struct {
  uint8 Write           : 1;  
  uint8 Read            : 1;  
  uint8 Sec5             : 1;  
  uint8 Sec10            : 1;
  
  uint8 Sec20            : 1;
  uint8 Min1             : 1;
  uint8 Min10            : 1;
  uint8 Min60            : 1;   

}Rtc_mem;

typedef union rtC
{
  uint8     all;
  Rtc_mem   bit ;  
}rtC;

// ������ ���ۿ� �ʿ��� ���� Ȯ�ο�

typedef struct {
  uint8 Buzzer_Start           : 1;  
  uint8 Buzzer_Doing           : 1;
  uint8 Buzzer_Set             : 1;
  
  uint8 Pulse_H_Capture        : 1; 
  uint8 Pulse_L_Capture        : 1;
  
  uint8 Pulse_H_Stable         : 1;
  uint8 Pulse_L_Stable         : 1;
  uint8 Inc_Pulse_Counter      : 1;
  //---------------------------------------
  uint8 LCD_display            : 1;
  uint8 Unused                 : 1;
  uint8 liter_cal              : 1;
  uint8 Conti_Buzzer           : 1;
  
  uint8 Entered_Unused         : 1;
  uint8 SMclk_Active           : 1;
  uint8 Save_mem               : 1;
  uint8 Wait_For_Emc           : 1;

}st_flag_mem;



typedef union def_st_flag
{
  uint16        all;
  st_flag_mem   bit ;  
}def_st_flag;

//---------------Guard_bit for stable working---------
typedef struct {
  uint8 I2C_Pressure             : 1;  
  uint8 Sec10_Lcd_Init           : 1;
  //uint8 Com_TX_Ico_Off           : 1;
  uint8 Power_ON                 : 1;
//  
  uint8 RF_Module                : 1; 
  uint8 Sequence                 : 1;
  uint8 ACK_Guard                : 1;
  uint8 Tx_Icon_On               : 1;
//  
  uint8 Rx_Icon_On               : 1;
//  uint8 RF_Tx_data            : 1; 
//  uint8 ID_ok                 : 1;
//  uint8 A1_Bcc_Ready          : 1;
//  
//  uint8 A1_Receive_ACK        : 1;
//  uint8 Battery_set           : 1;  
//  uint8 Tx_normal_set         : 1; 
//  uint8 Intrtval_tx           : 1;  
  
}st_guard_mem;

typedef union def_guard_flag
{
  uint16        all;
  st_guard_mem    bit ;  
}def_guard_flag;

// --------------��ſ� ����ϴ� ���� --------------------

typedef struct {
  uint8 Ready_EMC             : 1;  
  uint8 Illegal               : 1;
  uint8 Unused                : 1;
  uint8 On_Module             : 1;
  
  uint8 A1_Rx_STX             : 1;
  uint8 A1_Rx_One_byte        : 1;
  uint8 A1_Bcc1               : 1;
  uint8 A1_Bcc2               : 1;
  
  uint8 A1_data               : 1;
  uint8 RF_Tx_data            : 1; 
  uint8 ID_ok                 : 1;
  uint8 A1_Bcc_Ready          : 1;
  
  uint8 A1_Receive_ACK        : 1;
  uint8 Battery_set           : 1;  
  uint8 Tx_normal_set         : 1; 
  uint8 Intrtval_tx           : 1;  
  
}st_com_mem;

typedef union def_Comm_flag
{
  uint16        all;
  st_com_mem    bit ;  
}def_Comm_flag;

typedef struct {
  uint8 Waitting_Ack             : 1;  
  uint8 At_Rx_start              : 1;
  uint8 At_Rx_end                : 1;  
  uint8 At_Tx_start              : 1;
  
  uint8 At_Init_done             : 1;  
  uint8 At_data_invalid          : 1;
  uint8 At_Module_ready          : 1;  
  uint8 At_End                   : 1;
  
  uint8 DPLC_COM                 : 1;  
  uint8 Button_Com               : 1;
  uint8 Battery_Low              : 1;  
  uint8 Com_Ready                : 1;
  
  uint8 AT_COPS_Xsec_Watting     : 1;
  uint8 Creg1_5_Watting          : 1;
  uint8 Nb_Need_Step2            : 1;  
  uint8 RF_com                   : 1; 
  
}st_com_mem1;

typedef union def_Comm_flag1
{
  uint16        all;
  st_com_mem1    bit ;  
}def_Comm_flag1;

typedef struct {
    uint8 SendingDataSequence      : 1;  
    uint8 Data_tx_ready_Ok         : 1;
    uint8 Return_Step_3            : 1;  
    uint8 Reboot                   : 1;
//  
    uint8 Module_Reinit            : 1; 
    uint8 Module_Fail              : 1;
    uint8 At_Module_ready          : 1;  
    uint8 Comm_Doning              : 1;
//  
    uint8 Watting_COM              : 1;  
    uint8 Rssi_Interval_SET        : 1;
    uint8 Test_Bench               : 1;  
    uint8 S9_Old_State             : 1;
//  
    uint8 Five_Sec_Watting         : 1;
    uint8 Key_5sec_Ok              : 1;
    uint8 CSQ_Ok                   : 1;  
    uint8 Re_start                   : 1; 
  
}st_com_mem2;

typedef union def_Comm_flag2
{
  uint16        all;
  st_com_mem2    bit ;  
}def_Comm_flag2;

typedef struct {
  
    uint8 Iligal_Watting      : 1;  
	uint8 RetransmisstionAfterReset : 1;
	uint8 WaitPreDeregRsp 	:1;
	uint8 DelayedPostDereg 	:1;
		
//    uint8 Return_Step_3            : 1;  
//    uint8 Reboot                   : 1;
////  
//    uint8 Module_Reinit            : 1; 
//    uint8 Module_Fail              : 1;
//    uint8 At_Module_ready          : 1;  
//    uint8 Comm_Doning              : 1;
////  
//    uint8 Watting_COM              : 1;  
//    uint8 Rssi_Interval_SET        : 1;
//    uint8 Test_Bench               : 1;  
//    uint8 S9_Old_State             : 1;
////  
//    uint8 Five_Sec_Watting         : 1;
//    uint8 Key_5sec_Ok              : 1;
//    uint8 CSQ_Ok                   : 1;  
//    uint8 Re_start                   : 1; 

}st_com_mem3;

typedef union def_Comm_flag3
{
  uint16        all;
  st_com_mem3    bit ;  
}def_Comm_flag3;

//    ------- 32 �ʴ��� ���� ��꿡 ���

//typedef struct {
//  uint8  temp_counter       : 5;  // 2^5 32
//  uint16 Mem[32]               ;
//  uint16 deff_32min            ;
//  float  Liter_per_hour        ;
//  uint16 Ing_counter           ;
//}st_mem;

//-----�������˿� �����跮�� �������� Flag----
typedef struct {
  //uint8 OverQ3                : 1; 
  uint8 Unsued_used           : 1;  //������ �������� ������ ��ư����
  //uint8 Used                  : 1;

}st_leak_test;

typedef union def_st_leak_test_flag
{
  uint16          all;
  st_leak_test    bit ;  
}def_st_leak_test_flag;
//----------Button_ ���� ���¿� 

typedef struct {
  uint8 Return                : 1; //Leak test mode �϶��� ����
  uint8 Unused_test           : 1; 
  uint8 P_test                : 1;
  uint8 Error_State           : 1;
}st_port_test;

typedef union def_st_port_test_flag
{
  uint16          all;
  st_port_test    bit ;  
}def_st_port_test_flag;


//-------pressure--------------------
typedef struct st_mem_Pressure {
  uint16        Counter ;
  uint16        Value                 ;
  uint8         L_Counter              ;
  uint8         H_Counter              ;
  uint8         Normal_Counter         ;
  uint8         Mem[2]                ;
  struct {
                uint8  Delay_on             : 1; 
                uint8  Done                 : 1;  //Leak test mode �϶��� ����
                uint8  Normal               : 1;
  };      

}st_mem_Pressure;

//---------- S1 Error Dispay-----------------
typedef struct {
  uint8 temp                       : 1;  
  uint8 ADC_display                : 1; 
  uint8 ADC_on_off                : 1; 
  uint8 ADC_dis_first             : 1; 

}st_lcd_error_mem;

typedef union def_lcd_error_flag
{
  uint16              all;
  st_lcd_error_mem    bit ;  
}def_lcd_error_flag;

//-------ADC --------------------
typedef struct st_mem_ADC {
  uint16        Raw_Counter     ;
  uint32        _1mV           ;  
  uint16         Counter         ;
  uint16         ADC_loop       ;
  struct {
                uint8  ADC_on             : 1; 
                uint8  load_En            : 1;  //Leak test mode �϶��� ����
                uint8  ADC_en             : 1;
                uint8  ADC_Start          : 1;
                uint8  ADC_Done           : 1;
                uint8  ADC_Doing          : 1;
  };      

}st_mem_ADC;

typedef union st_AT_R_status_mem{
  uint8 all;
  struct {
  uint8 OK                       : 1;  
  uint8 Error                    : 1; 
  uint8 Neul                     : 1; 
  uint8 Data                     : 1;
  uint8 Data_index               : 1;//: 2;
  uint8 DLdata                   : 1;//: 2;
  uint8 MLWDLdata                   : 1;//: 2;

  //uint8 OK_index                 : 1;
  };
}st_AT_R_status_mem;



//typedef struct st_com_etx_memory
//{
//  reQ_COM_INERVAL_SET                       ;//��-��-�� ��� ���� �ֱ� ����(0x51) ��û ������;
//  reQ_READ_SAVE_INTVAL_SET 
//  reQ_PRESSURE_INTVAL_SET;
//  uint8           *Data_ptr                 ;   
//
//}st_mem_memory;

typedef union _raw{
  uint8 all;
  struct
  {
    uint8 Raw_low_char  : 4;
    uint8 Raw_high_char : 4;
  };
}_raw;

typedef union _oneHex{
  uint8 Char;
  struct
  {
    uint8 Low_Nibble  : 4;
    uint8 High_Nibble : 4;    
  };  
}_OneHex;


//--------- FTM ----------
typedef struct {
  uint8 led             :1;
  uint8 buzzer          :1;
  uint8 lcd             :1;
  uint8 modem           :1;
  uint8 sim             :1;
  uint16 flow;
  uint8 cheat           :1;
  uint8 button          :1;
  uint8 batt             :1;
  uint8 bypass        :1;
}st_mem_func_test;

typedef struct{
  uint8           *FRAM_WR_ptr;
  uint8            FTM_mode_flag        :1;
}st_mem_ftm_memory;


typedef struct{
  uint16       Counter		:13;
  uint8         Reserved:3;
}st_log_save_counter_type;


//-----------------------
