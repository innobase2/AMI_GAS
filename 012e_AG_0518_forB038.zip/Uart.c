#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"
#include "Meter_Unit.h"
#include <string.h>
#include <stdlib.h>


void Init_Uart(void);
void Communication(void);
void DPLC_Rx_Process(void );
//void Meter_Modify(void);
extern uint16 Bcd2Hex( uint32 );
extern void Hex2Bcd32(uint16);
extern void FRAMReade(void);
extern void Read_Pressure_Sensor(void);
inline void DPLC_Data_Process(void );
inline void Make_same_Frame(uint16 ,uint8 );
//inline void Make_P_MODIFY_SUM(void );
inline void Make_Normal(void ); 
void Make_Emc_data(void);
void Tx_Normal(void);

void COM_request(void);
extern void Nb_tx_AT_MLWULDATA( uint16 real_length );
extern void Mad_string_make_step1(uint8 *Madptr);

//--------- FTM ----------
extern void FTM_Display(void);
extern void SendString(const unsigned char* st);

uint8 RxLen;
//-----------------------  

void Init_Uart(void)
{
//	34	P3.4/UCA1SIMO/UCA1TXD/TB0.0/S21	        TX_DPLC	uart
//	35	P3.5/UCA1SOMI/UCA1RXD/TB0.1/S20	        RX_DPLC	uart  
  UART1_DPLC_SEL ;
  // Configure USCI_A1 for UART DPLC mode
  UCA1CTLW0 |= UCSWRST;
  UCA1CTLW0 = UCSSEL__ACLK;                 // Set ACLK = 32768 as UCBRCLK 
  UCA1BR0 = 3;                              // 9600 baud
  UCA1MCTLW = 0x5300;                      // 32768/9600 - INT(32768/9600)=0.41
                                            // UCBRSx value = 0x53 (See UG)
  UCA1BR1 = 0;  
  UCA1CTLW0 &= ~UCSWRST;                     // release from reset
  UCA1IE |= UCRXIE; 
  
//	40	P2.1/UCA0RXD/TB0.5/S15	RX_MODEM
//	41	P2.0/UCA0TXD/TB0.6/S14	TX_MODEM
  UART0_MODEM_SEL ;
  // Configure USCI_A0 for UART mode
  UCA0CTLW0 = UCSWRST;                      // Put eUSCI in reset
  UCA0CTLW0 |= UCSSEL__ACLK;                // CLK = ACLK
  UCA0BR0 = 3;                              // 9600 baud
  UCA0MCTLW = 0x5300;                      // 32768/9600 - INT(32768/9600)=0.41
                                            // UCBRSx value = 0x53 (See UG)
  UCA0BR1 = 0;
  UCA0CTL1 &= ~UCSWRST;                     // Initialize eUSCI
  UCA0IE |= UCRXIE;                         // Enable USCI_A0 RX interrupt  
  
}

uint8 temp_uart_a0;

// --------------------- RF Modem InterFace UART------------------------------
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
  SET_TEST3
  uint8 temp_uart;
  switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG))
  {
    case USCI_NONE: break;
    case USCI_UART_UCRXIFG:
      
      temp_uart_a0 = UCA0RXBUF;
      Nb_Str_Rx[Str_Counter_at++] = temp_uart_a0 ;
      
//--------- FTM ----------
      if(Factory.bypass == 1)          
        UCA1TXBUF = temp_uart_a0;
//----------------------- 
      
      TA3CCTL3 = 0;
      TA3CCR3  = TA3R;
      TA3CCR3  += 9;  // 3ms
      TA3CCTL3 = CCIE;      
      
      //__bic_SR_register_on_exit(LPM3_bits); // Exit LPM3 on reti
      break;
    case USCI_UART_UCTXIFG:   // tx 
      
      if((*Ptr_at == 0)&&(CharEnd_counter <= 1) )  //
      {
        //SET_TEST1
        UCA0IE &= ~UCTXIE;
        Str_Counter_at = 0;
        
        TA3CCTL2 = 0;
        if( AT_case == _AT_NRB_NUM   )
        {
          RetrySec_counter =  1 + 6 ;  //  5�� ���ϴ� �ʽð�
        }
        else if( AT_case == _AT_CFUN1_NUM )
        {
          RetrySec_counter =  6;
        }
        else 
        {          
          RetrySec_counter = 1 + 3 ;
        }        
        TA3CCR2  = TA3R + 4096;//(uint16)(8192 * 3); // offset 1 sec
        TA3CCTL2 = CCIE; 
        //CLR_TEST1
      }   
      else
      { 
        RetrySec_counter  = 0;
        if( Const_String_Counter > 0 )
        {
          UCA0TXBUF = *Ptr_at++;
          Const_String_Counter --;
          Mad_counter = 0;
        }
        else
        {
          UCA0IE &= ~UCTXIE;  
          
          if(CharEnd_counter > 3 )
          {
            if(!Mad_counter)
            {
              
              Mad_counter++;
              Mad_string_make_step1(Ptr_at);
              Ptr_at++;
              temp_uart = Mad_str[0];
            }
            else
            {                  
              Mad_counter = 0;    
              temp_uart = Mad_str[1];
              CharEnd_counter--;
            }
          }
          else 
          {
            CharEnd_counter--;
            temp_uart = *Ptr_at++;
          }
          
          UCA0TXBUF = temp_uart;
          UCA0IE |=  UCTXIE;          
        }       
      }
      break;     
    case USCI_UART_UCSTTIFG: break;
    case USCI_UART_UCTXCPTIFG: break;
  }
  CLR_TEST3
}
  
//---------------- DPLC Interface UART-----------------------------------------
uint8 temp_uart_a1;
#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)
{
  SET_TEST3
  uint8 A1_temp;
  
  switch(__even_in_range(UCA1IV,USCI_UART_UCTXCPTIFG))
  {
    case USCI_NONE: break;
    case USCI_UART_UCRXIFG:
      {
        if(FTM_mode_flag == 0) // FTM : FTM_mode_flag�� 0�̸� Normal Mode ���� ��
        {
          temp_uart_a1 = UCA1RXBUF;                   // Read buffer
          
          if(Com1.bit.Waitting_Ack == 1 )
          {
            //T_data.Basic.Mem.Seq.mem.no = 0;
            Com1.bit.Waitting_Ack = 0;
            if(temp_uart_a1 == ACK )
            {
              TA3CCTL0 = 0;
              if(T_data.Basic.Mem.Command == P_NORMAL_READ )
              {
                T_data.Basic.Mem.Command = 0;
                Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;            
              }      
            }
            else if( temp_uart_a1 == NACK )
            {
              if(T_data.Basic.Mem.Command == P_NORMAL_READ)
              {
                TA3CCTL0 = 0;
              } 
              else  // 0x81 �ƴϴ�.
              {
                TA3CCTL0 = CCIE;            
              }
            }
            if(temp_uart_a1 == STX )
            {
              TA3CCTL0 = 0;          
              if(T_data.Basic.Mem.Command == P_NORMAL_READ )
              {
                T_data.Basic.Mem.Command = 0;
                Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;          
              }           
              Com.bit.A1_Rx_One_byte = 1;
            }        
          }      
          else
          {
            Com.bit.A1_Rx_One_byte = 1;
          }
        }
//--------- FTM ----------
        else
        {  
          ftm_uart_a1_rx[RxLen] = UCA1RXBUF;                   // Read buffer

          if(ftm_uart_a1_rx[0] != FTM) 
            RxLen = 0;          
          else if(ftm_uart_a1_rx[RxLen] == 0x0A)
          {
            uart_rx_done_flag = 1;
            RxLen = 0;
          }   
          else
            RxLen++;
        }
//-----------------------       
        __bic_SR_register_on_exit(LPM3_bits); // Exit LPM3 on reti
      }
      break;
    case USCI_UART_UCTXIFG:
      if(FTM_mode_flag == 0) // FTM : FTM_mode_flag�� 0�̸� Normal Mode ���� ��
      {
        if(Com.bit.A1_Bcc_Ready == 0)
        {        
          TX_counter--;
          if( TX_counter == 0  )
          {
            if(Com.bit.A1_Bcc_Ready == 0)
            {
              Com.bit.A1_Bcc_Ready =1;
              UCA1TXBUF = XOR_Bcc1;
            }              
          }
          else
          {        
            A1_temp = *TX_A1_pointer++;
            XOR_Bcc1 ^= A1_temp;
            SUM_Bcc2 += A1_temp;
            UCA1TXBUF = A1_temp; 
          } 
        }
        else
        {
          UCA1TXBUF = SUM_Bcc2;
          UCA1IE &= ~UCTXIE;
          TA3CCR0  = TA3R + 12288; // offset 3 sec;
          TA3CCTL0 = CCIE;
          Com2.bit.Comm_Doning  = 0;
        }
      }
      break;
    case USCI_UART_UCSTTIFG: break;
    case USCI_UART_UCTXCPTIFG: break;
  }
  CLR_TEST3
}

void DPLC_Rx_Process(void)
{
  uint8 loop_counter;
  
  if(Com.bit.A1_Rx_One_byte)
  {
    Com.bit.A1_Rx_One_byte = 0;
    
    if((Com.bit.A1_Bcc1 == 0 ) && (Com.bit.A1_Bcc2 == 0 ))
    {    
      XOR_Bcc1 ^= temp_uart_a1;
      SUM_Bcc2 += temp_uart_a1; 
    }
    if(Com.bit.A1_Bcc2)
    {
      Com.bit.A1_Bcc2  = 0;
      R_Bcc2 = temp_uart_a1;
      Com.bit.ID_ok = 1;
      for(loop_counter = 0 ; loop_counter < 8 ; loop_counter++)
      {
        if(MeterID[loop_counter] == R_data.Basic.Mem.MeterID[loop_counter]);
        else 
        {
          Com.bit.ID_ok = 0; 
          loop_counter  = 9;
        }
      }      
      if((XOR_Bcc1 ==R_Bcc1) && (SUM_Bcc2 == R_Bcc2))// && (Com.bit.ID_ok))
      {
        Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        DPLC_Data_Process( );  // ���������� ��� ������ �¾� DPLC RX�� ���� ���� �̴�.
      }
      else; 
    }
    if(Com.bit.A1_Bcc1)
    {
      Com.bit.A1_Bcc1  = 0;
      Com.bit.A1_Bcc2  = 1; 
      R_Bcc1 = temp_uart_a1; 
    }
    if(Com.bit.A1_data)
    {
      R_data.Data.Raw[Data_Lenght] = temp_uart_a1 ;
      Data_Lenght++;
      if(Data_Lenght == Temp_Lenght)
      {
        Com.bit.A1_data = 0;
        Com.bit.A1_Bcc1 = 1;
      }      
    }
    if(Com.bit.A1_Rx_STX == 1)
    {
      Com1.bit.Waitting_Ack = 0;
      R_data.Basic.Raw[Temp_Lenght] = temp_uart_a1 ;
      Temp_Lenght++;
      if(Temp_Lenght == 14 )
      { 
        Temp_Lenght = R_data.Basic.Mem.Lenght ;
        Temp_Lenght = __swap_bytes(Temp_Lenght);
        Com.bit.A1_Rx_STX = 0;
        if(Temp_Lenght == 0 ) 
        {
          Com.bit.A1_Bcc1 = 1;
        }
        else
        {
          Com.bit.A1_data = 1;
          Data_Lenght = 0;
        }
      }
    }
//--------- FTM ----------    
    if(A1_Rx_FTM)
    {
      ftm_uart_a1_rx[RxLen] = temp_uart_a1;
      if(ftm_uart_a1_rx[RxLen] == 0x0A)
      {
        A1_Rx_FTM = 0;
        if((ftm_uart_a1_rx[1] == 0x47) && (ftm_uart_a1_rx[2] == 0x2B))
        {
          if(ftm_uart_a1_rx[3] == 0x45)
          {
            refresh_ftm_display = 1;
            FTM_mode_flag = 1;
            FTM_Display();
            SendString(string_ok);
          }
        }
        RxLen = 0;
      }
      else
        RxLen++;
    }
//-----------------------    
    if( temp_uart_a1 == STX )
    {
      XOR_Bcc1 = SUM_Bcc2 = STX;
      Com.bit.A1_Bcc1  = 0;
      Com.bit.A1_Bcc2  = 0;        
      Com.bit.A1_Rx_STX = 1;
      Temp_Lenght = 0;
    }
//--------- FTM ----------    
    else if(temp_uart_a1 == FTM)
    {
      RxLen++;
      A1_Rx_FTM = 1;
    }
//----------------------    
  }
}

// ���������� ���� DATA�� ������ ����� ó�� tX�� �Ѵ�.
inline void DPLC_Data_Process(void)  
{
  uint8 temp_01;
  
  TA3CCTL0 = 0;
  
  OK_Counter = 0; // OK�� �޴� counter, ���������� ���.
  
  if(T_data.Basic.Mem.Command == P_NORMAL_READ )
  {
    Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;          
  }   
  
  switch( R_data.Basic.Mem.Command)
  {
  case Q_NORMAL_READ :
//      if(Com.bit.Intrtval_tx)
//      {
//        Com.bit.Intrtval_tx = 0;
//        Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;          
//      }
      Make_Normal(); 
      Uart_counter = 0;
    break;
// Special case --------------------    
  case Q_VALVE_STOP :
     //Read_Pressure_Sensor();
     EMC_command = Q_VALVE_STOP;
     CLR_CW
     SET_CCW  
     SET_DRV_OUT
     Valve_working_Sec = 11 ;  //11 ��
     TA3CCR1  = TA3R + (4095 ) ; 
     TA3CCTL1 = CCIE;
     Uart_counter = 0;
    break;
  case Q_VALVE_RETURN :
     //Read_Pressure_Sensor();
     EMC_command = Q_VALVE_RETURN;
     SET_CW
     CLR_CCW  
     SET_DRV_OUT
     Valve_working_Sec = 11 ;  //11 ��  
     TA3CCR1  = TA3R + (4095 ) ; //11 ��
     TA3CCTL1 = CCIE;
     Uart_counter = 0;
    break; 
// Special case --------------------     
  case Q_MODIFY_SUM : 
    
      Dec_Counter_L = ( __swap_bytes(R_data.Data.Modify_Sum.Mofify_Flow_F) );// menory�� �������� ����. MSB <> LSB
      Dec_Counter_H = ( __swap_bytes(R_data.Data.Modify_Sum.Mofify_Flow_I) );// menory�� �������� ����. MSB <> LSB  

      T_data.Data.Modify_Sum.Mofify_Flow_I= R_data.Data.Modify_Sum.Mofify_Flow_I;
      T_data.Data.Modify_Sum.Mofify_Flow_F= R_data.Data.Modify_Sum.Mofify_Flow_F;
      
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else; 
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no =  1;
      
      Make_same_Frame(P_MODIFY_SUM_LENGH ,P_MODIFY_SUM) ;
      Uart_counter = 0;

    break;
  case Q_TIME_SYNC:
    
      while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready
      RTCYEAR = (0xFF00 & RTCYEAR ) | R_data.Data.SYNC_Time.ymdhms.Year;  // Year = 0x2017
      RTCMON = R_data.Data.SYNC_Time.ymdhms.Month;                        // Month = 0x03 = Mar
      RTCDAY = R_data.Data.SYNC_Time.ymdhms.Day;                          // Day = 0x01 = 1th
      RTCHOUR= R_data.Data.SYNC_Time.ymdhms.Hours;                        // Hour = 0x10
      RTCMIN = R_data.Data.SYNC_Time.ymdhms.Min;                          // Minute = 0x32
      RTCSEC = R_data.Data.SYNC_Time.ymdhms.Sec;                          // Seconds = 0x45      
           
      T_data.Data.SYNC_Time.ymdhms.Year   = R_data.Data.SYNC_Time.ymdhms.Year ;
      T_data.Data.SYNC_Time.ymdhms.Month  = R_data.Data.SYNC_Time.ymdhms.Month;
      T_data.Data.SYNC_Time.ymdhms.Day  = R_data.Data.SYNC_Time.ymdhms.Day;
      T_data.Data.SYNC_Time.ymdhms.Hours  = R_data.Data.SYNC_Time.ymdhms.Hours;
      T_data.Data.SYNC_Time.ymdhms.Min  = R_data.Data.SYNC_Time.ymdhms.Min;
      T_data.Data.SYNC_Time.ymdhms.Sec  = R_data.Data.SYNC_Time.ymdhms.Sec; 
      
      Reset_Reboot_Day  = RTCDAY;
      HW_Reboot_counter = 0;
      
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else; 
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no =  1;
      
      Make_same_Frame(P_TIME_SYNC_LENGH ,P_TIME_SYNC) ;
      Uart_counter = 0;
    
    break;
  case Q_COM_INERVAL_SET:
    
      TX_A1_pointer = &(R_data.Data.Interval.min_H);
      for(temp_01 = 0 ; temp_01 < 3 ; temp_01++)
      {
        if(*TX_A1_pointer++ == 0);
        else temp_01 = 77;
      }
      if(temp_01 != 78 )  // 0 �̸� ���� �ֱ� ����
      {
        asm_temp = Com_inertval_MIN;
        
        Hex2Bcd32( asm_temp );
        Test_0 = asm_temp_12;
        T_data.Data.Interval.min_L = (Test_0 & 0xFF);
        Test_0>>= 8;
        T_data.Data.Interval.min_M = (Test_0 & 0xFF);
        Test_0>>= 8;
        T_data.Data.Interval.min_H = (Test_0 & 0xFF);        
        
      }
      else
      {
        Test_0  = R_data.Data.Interval.min_H ;
        Test_0<<=8;
        Test_0  |= R_data.Data.Interval.min_M ;
        Test_0<<=8;
        Test_0  |= R_data.Data.Interval.min_L ;
        
        Com_inertval_MIN = (uint16)(Bcd2Hex( Test_0 )); 
        
        
        U16_ptr = (uint16 *)(COM_INTTERVAL);
        *U16_ptr = Com_inertval_MIN;
        
        T_data.Data.Interval.min_H = R_data.Data.Interval.min_H ;
        T_data.Data.Interval.min_M = R_data.Data.Interval.min_M ;
        T_data.Data.Interval.min_L = R_data.Data.Interval.min_L ;       
      }
      
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else;  
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no =  1;

      Make_same_Frame(P_COM_INERVAL_SET_LENGH ,P_COM_INERVAL_SET) ;
      Uart_counter = 0;
    break;
  case Q_READ_SAVE_INTVAL_SET:
      TX_A1_pointer = &(R_data.Data.ReadSave_Interval.min_H);
      for(temp_01 = 0 ; temp_01 < 2 ; temp_01++)
      {
        if(*TX_A1_pointer++ == 0);
        else temp_01 = 77;
      }
      if(temp_01 != 78 )  // 0 �̸� ���� �ֱ� ����
      {
        asm_temp = Read_Save_Interval_MIN;
        
        Hex2Bcd32( asm_temp );
        Test_0 = asm_temp_12;
        T_data.Data.ReadSave_Interval.min_L = (Test_0 & 0xFF);
        Test_0>>= 8;
        T_data.Data.ReadSave_Interval.min_H = (Test_0 & 0xFF);        
        
      }
      else
      {
        Test_0  = R_data.Data.ReadSave_Interval.min_H ;
        Test_0<<=8;
        Test_0  |= R_data.Data.ReadSave_Interval.min_L ;
        
        Read_Save_Interval_MIN = (uint16)(Bcd2Hex( Test_0 )); 
        
        U16_ptr = (uint16 *)(READ_INTTERVAL);
        *U16_ptr = Read_Save_Interval_MIN;
        
        T_data.Data.ReadSave_Interval.min_H = R_data.Data.ReadSave_Interval.min_H ;
        T_data.Data.ReadSave_Interval.min_L = R_data.Data.ReadSave_Interval.min_L ;       
      } 
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else;  
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no =  1;

      Make_same_Frame(P_READ_SAVE_INTVAL_SET_LENGH ,P_READ_SAVE_INTVAL_SET) ; 
      Uart_counter = 0;
    break;
  case Q_PRESSURE_INTVAL_SET:
      TX_A1_pointer = &(R_data.Data.Pressure_Interval.min_H);
      for(temp_01 = 0 ; temp_01 < 2 ; temp_01++)
      {
        if(*TX_A1_pointer++ == 0);
        else temp_01 = 77;
      }
      if(temp_01 != 78 )  // 0 �̸� ���� �ֱ� ����
      {
        asm_temp = Pressure_inteval_MIN;
        
        Hex2Bcd32( asm_temp );
        Test_0 = asm_temp_12;
        T_data.Data.Pressure_Interval.min_L = (Test_0 & 0xFF);
        Test_0>>= 8;
        T_data.Data.Pressure_Interval.min_H = (Test_0 & 0xFF);        
        
      }
      else
      {
        Test_0  = R_data.Data.Pressure_Interval.min_H ;
        Test_0<<=8;
        Test_0  |= R_data.Data.Pressure_Interval.min_L ;
        
        Pressure_inteval_MIN = (uint16)(Bcd2Hex( Test_0 ));  

        U16_ptr = (uint16 *)(PRESS_INTTERVAL);
        *U16_ptr = Pressure_inteval_MIN;  
        
        T_data.Data.Pressure_Interval.min_H = R_data.Data.Pressure_Interval.min_H ;
        T_data.Data.Pressure_Interval.min_L = R_data.Data.Pressure_Interval.min_L ;       
      } 
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else;  
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no   = 1;

      Make_same_Frame(P_PRESSURE_INTVAL_SET_LENGH ,P_PRESSURE_INTVAL_SET) ;
      Uart_counter = 0;
    break;
  case Q_REQ_RETRY_TIME:
    
      T_data.Data.Raw[0] = 0;
      if(R_data.Data.Retry.Recount == 0)
      {
        asm_temp = Defult_retry_count;
        
        Hex2Bcd32( asm_temp );
        Test_0 = asm_temp_12;
        T_data.Data.Retry.Recount = (Test_0 & 0xFF);     
      }
      else
      {
        Defult_retry_count = R_data.Data.Retry.Recount;
        
        U8_ptr = (uint8 *)(RETRY_COUNTER);
        *U8_ptr = Defult_retry_count;         
        T_data.Data.Retry.Recount = Defult_retry_count ;
      } 
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else;  
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no   = 1;

      Make_same_Frame(P_REQ_RETRY_TIME_LENGH ,P_REQ_RETRY_TIME) ; 
      Uart_counter = 0;
    break;
  case Q_MODEM_B_SET_DAY:
      if(Com.bit.Battery_set == 0)
      {
        while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready
        T_data.Data.B_Set.Year  = (0xFF & RTCYEAR ) ;
        T_data.Data.B_Set.Month = RTCMON;
        T_data.Data.B_Set.Day   = RTCDAY;  
        
        Com.bit.Battery_set     = 1;
        Battery_Set_yy = T_data.Data.B_Set.Year  ;
        Battery_Set_mm = T_data.Data.B_Set.Month ;
        Battery_Set_dd = T_data.Data.B_Set.Day   ;         
      }
      else
      {
        T_data.Data.B_Set.Year  = Battery_Set_yy;
        T_data.Data.B_Set.Month = Battery_Set_mm;
        T_data.Data.B_Set.Day   = Battery_Set_dd;
      }
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else; 
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no   = 1;
      
      Make_same_Frame(P_MODEM_B_SET_DAY_LENGH ,P_MODEM_B_SET_DAY) ;       
      Uart_counter = 0;
    break;
  case Q_METER_SETUP_R:
      T_data.Data.Setup_R.Meter_Jong = Meter_Jong;
      T_data.Data.Setup_R.Meter_Type = Meter_Type;
      
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else;  
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no   = 1;
      
      Make_same_Frame(P_METER_SETUP_R_LENGH ,P_METER_SETUP_R) ;       
      Uart_counter = 0;
    break;
  case Q_METER_SETUP_W:
      if(R_data.Data.Setup_W.WritePassWord == WRITE_PASSWORD)
      {
         Meter_Jong = R_data.Data.Setup_W.Meter_Jong ;
         Meter_Type = R_data.Data.Setup_W.Meter_Type ; 
         switch(Meter_Type)
         {
         case G16_GAS : OverQ3_Per_5sec_Value = G16_Q3_1_PER_5SEC_250;
                        LeakQ3_Per_1min_Value = G16_Q3_PER_MIN_250;
                        LeakQ1_Per_1min_Value = G16_Q1_PER_MIN_250;
           break;
         case G25_GAS : OverQ3_Per_5sec_Value = G25_Q3_1_PER_5SEC_250;
                        LeakQ3_Per_1min_Value = G25_Q3_PER_MIN_250;
                        LeakQ1_Per_1min_Value = G25_Q1_PER_MIN_250;
           break;
         case G40_GAS : OverQ3_Per_5sec_Value = G40_Q3_1_PER_5SEC_250;
                        LeakQ3_Per_1min_Value = G40_Q3_PER_MIN_250;
                        LeakQ1_Per_1min_Value = G40_Q1_PER_MIN_250;
           break;            
         }
         T_data.Data.Setup_W.Result = 1;
         
          U8_ptr = (uint8 *)(METER_JONG);
          *U8_ptr = Meter_Jong;
          
          U8_ptr = (uint8 *)(METER_TYPE);
          *U8_ptr = Meter_Type;         
      }
      else 
      {
        T_data.Data.Setup_W.Result = 0;
      }
      T_data.Basic.Mem.Seq.mem.Recount = 0;
      if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
        T_data.Basic.Mem.Seq.mem.no++;
      else;  
      T_data.Basic.Mem.Packet.mem.Next = 0;
      T_data.Basic.Mem.Packet.mem.no   = 1;
      
       Make_same_Frame(P_METER_SETUP_W_LENGH ,P_METER_SETUP_W);
       Uart_counter = 0;
    break;
  case Q_TEST_BENCH:
      Com2.bit.Test_Bench = 1;
      if(Com2.bit.Comm_Doning) 
      {
        Com2.bit.Watting_COM = 1;                 // ��� �߿� ��� �Ѵ�.
      }
      else 
      {
        Com.bit.On_Module     = 1;                 // main���� ��� ����!
        Nb_Retry_count = 0;
        T_data.Basic.Mem.Seq.mem.Recount = 0;
      }
      Uart_counter = 0;
    break;
  }  
}

inline void Make_same_Frame(uint16 count,uint8 command)
{
    uint16 temp0;
    
    for(temp0 = 0 ; temp0 < 8 ; temp0++)
    {
      T_data.Basic.Mem.MeterID[temp0] = MeterID[temp0];
    } 
    T_data.Basic.Mem.DeviceID = DeviceID;
    
    T_data.Basic.Mem.Command = command ;
    T_data.Basic.Mem.Lenght  = __swap_bytes(count); // menory�� �������� ����. MSB <> LSB
    
    XOR_Bcc1 = STX;
    SUM_Bcc2 = STX;
    TX_counter = BASIC_LENGH + count ;
    Com.bit.A1_Bcc_Ready = 0;
    Com1.bit.Waitting_Ack = 1; 
    TX_A1_pointer = &(T_data.Basic.Raw[0]);     

    if(Com1.bit.DPLC_COM == 0)
    {
      T_data_number = count;
      
      memcpy( TX_data_Temp,&(T_data.Basic.Raw[0]),50);
      
      if(Com2.bit.Data_tx_ready_Ok == 0) // data�� ���� �غ� �̹� �Ǿ���? ó���� 0�̴�.
      {      
        if(Guard.bit.Sequence == 0 )  // ó���� ������ 0�̴�
        {
          Guard.bit.Sequence = 1;     // Ÿ�̸ӿ��� �����ð� �Ǹ� Guard.bit.Sequence =1�� �����.
          Sequence_Counter   = 0;

          Com2.bit.SendingDataSequence = 1;// data�� ���� �� �ֳ� Ȯ�� ����.
          Com1.bit.At_Tx_start = 1;
          AT_case              = _AT_NUM;          
        }
        else 
        {
          Sequence_Counter   = 0;
		  if(MLW_Event == 3 || MLW_Event == 5)	// Regi �����̰ų�.. Fota init ���� �� ��쿡�� ������..
			Com2.bit.Data_tx_ready_Ok = 1;
        }
      }
      else //// �غ� �� ���¸� 1�̴� �� ���¿��� data�� ��� ���� �� �ִ�.
      {
        Sequence_Counter   = 0;
        //Com1.bit.At_Tx_start = 1;
        //Com.bit.On_Module = 1;
        //Com2.bit.Data_tx_ready_Ok = 1;
      }
    }
    else;
    
    if(( Com1.bit.DPLC_COM  )||(T_data.Basic.Mem.Command ==P_EMC_READ) || (T_data.Basic.Mem.Command == P_COM_READ))
    {       
        UCA1TXBUF = STX;
        UCA1IE |= UCTXIE;
        Com1.bit.DPLC_COM = 0;
    }
    else;
}
/*
void Meter_Modify(void)
{
  uint8 temp;
  
  if(Com.bit.A1_Receive_ACK)
  {
    Com.bit.A1_Receive_ACK = 0;
    TA3CCTL0 = 0;
    switch( R_data.Basic.Mem.Command)
      {
      case Q_NORMAL_READ :
          Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;         
        
        break;
      case Q_MODIFY_SUM :      
          
          Dec_Counter_L = Bcd2Hex( __swap_bytes(R_data.Data.Modify_Sum.Mofify_Flow_F) );// menory�� �������� ����. MSB <> LSB
          Dec_Counter_H = Bcd2Hex( __swap_bytes(R_data.Data.Modify_Sum.Mofify_Flow_I) );// menory�� �������� ����. MSB <> LSB
          
        break;
      case Q_TIME_SYNC:
          while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready
          RTCYEAR = (0xFF00 & RTCYEAR ) | R_data.Data.SYNC_Time.ymdhms.Year;  // Year = 0x2017
          RTCMON = R_data.Data.SYNC_Time.ymdhms.Month;                        // Month = 0x03 = Mar
          RTCDAY = R_data.Data.SYNC_Time.ymdhms.Day;                          // Day = 0x01 = 1th
          RTCHOUR= R_data.Data.SYNC_Time.ymdhms.Hours;                        // Hour = 0x10
          RTCMIN = R_data.Data.SYNC_Time.ymdhms.Min;                          // Minute = 0x32
          RTCSEC = R_data.Data.SYNC_Time.ymdhms.Sec;                          // Seconds = 0x45         
        break;
      case Q_COM_INERVAL_SET:
          TX_A1_pointer = &(R_data.Data.Interval.min_H);
          for(temp = 0 ; temp < 3; temp++)
          {
            if(*TX_A1_pointer++ == 0);
            else temp = 77;// 0 �̸� ���� �ֱ�
          }
          if(temp != 77 ) ;  
          else
          {
            Test_0  = R_data.Data.Interval.min_H ;
            Test_0<<=8;
            Test_0  |= R_data.Data.Interval.min_M ;
            Test_0<<=8;
            Test_0  |= R_data.Data.Interval.min_L ;
            
            Com_inertval_MIN = (uint16)(Bcd2Hex( Test_0 ));        
            
          }          
        break;
      case Q_READ_SAVE_INTVAL_SET:
          TX_A1_pointer = &(R_data.Data.ReadSave_Interval.min_H);
          for(temp = 0 ; temp < 2 ; temp++)
          {
            if(*TX_A1_pointer++ != 0);
            else temp = 77;// 0 �̸� ���� �ֱ� 
          }
          if(temp == 77 ) ; 
          else
          {
            Test_0  = R_data.Data.ReadSave_Interval.min_H ;
            Test_0<<=8;
            Test_0  |= R_data.Data.ReadSave_Interval.min_L ;
            
            Read_Save_Interval_MIN = (uint16)(Bcd2Hex( Test_0 ));              
          }        
        break;
      case Q_PRESSURE_INTVAL_SET:
          TX_A1_pointer = &(R_data.Data.Pressure_Interval.min_H);
          for(temp = 0 ; temp < 2 ; temp++)
          {
            if(*TX_A1_pointer++ != 0);
            else temp = 77;// 0 �̸� ���� �ֱ� 
          }
          if(temp == 77 ) ; 
          else
          {
            Test_0  = R_data.Data.Pressure_Interval.min_H ;
            Test_0<<=8;
            Test_0  |= R_data.Data.Pressure_Interval.min_L ;
            
            Pressure_inteval_MIN = (uint16)(Bcd2Hex( Test_0 ));              
          }          
        break;
      case Q_REQ_RETRY_TIME:
          Defult_retry_count = R_data.Data.Retry.Recount;
        break;
      case Q_MODEM_B_SET_DAY:
          if(Com.bit.Battery_set == 0)
          {
            Com.bit.Battery_set     = 1;
            Battery_Set_yy = T_data.Data.B_Set.Year  ;
            Battery_Set_mm = T_data.Data.B_Set.Month ;
            Battery_Set_dd = T_data.Data.B_Set.Day   ;        
          }       
        break;
      case Q_METER_SETUP_R:
        break;
      case Q_METER_SETUP_W:

        
        break;    
      }    
  }  
}
*/
void Tx_Normal(void)
{  
  if((Com.bit.Tx_normal_set)&&(Battery.ADC_Doing==0))
  {
    Nb_Retry_count = 0;
    Com.bit.Tx_normal_set = 0;
    Com.bit.Intrtval_tx = 1;
    Make_Normal();
  }  
}

inline void Make_Normal(void )
{  
  uint16 temp  ;
  uint16 temp_1;

  Length_temp_Normal = 0;
  temp_1 = Memory.Save_Counter - Memory.Trsmmi_Counter ;  // �󸶳� ���� �ֳ� Ȯ��
  
  Memory.Tx_temp_Counter = Memory.Trsmmi_Counter;         // ������ �ּ� ī����  
  
  
  if( 10 <= temp_1 )  // 20 �Ѵ� ��� --> 24 0411 ���� ����
  {
    T_data.Basic.Mem.Packet.mem.Next = 1;  // 20�� ������ ������ �� �ִ�.
//    Memory.Tx_temp_Counter = Memory.Tx_temp_Counter - 1;  
//    for(temp_1 = 0 ; 20 > temp_1 ; temp_1++ )
//    {
//       Memory.Data_ptr    = (uint8 *)(SAVE_START + ( Memory.Tx_temp_Counter++ * 20)) ;
//       Memory.FRAM_WR_ptr = &(T_data.Data.Normal[temp_1].ymdhms.Year);
//       FRAMReade();
//       Length_temp_Normal +=20;   // datadml byte �� ����.
//       T_data.Basic.Mem.Packet.mem.no = temp++;
//    }
      for(temp = 0 ; temp < 10  ; temp++ )
      {
         Memory.Data_ptr    = (uint8 *)(SAVE_START + ( Memory.Tx_temp_Counter++ * 20)) ;         
         Memory.FRAM_WR_ptr = &(T_data.Data.Normal[temp].ymdhms.Year);
         FRAMReade();
         Length_temp_Normal +=20; 
         T_data.Basic.Mem.Packet.mem.no = (temp+1);
      }     
  }
  else        // 24���� ������ �� ���´�.
  {
    T_data.Basic.Mem.Packet.mem.Next = 0;
    
    if(Memory.Save_Counter == 0);

    else if(Memory.Tx_temp_Counter == Memory.Save_Counter)
    {
       Memory.Tx_temp_Counter = Memory.Tx_temp_Counter - 1;
       Memory.Data_ptr    = (uint8 *)(SAVE_START + ((Memory.Tx_temp_Counter++) * 20)) ;
       Memory.FRAM_WR_ptr = &(T_data.Data.Normal[0].ymdhms.Year);
       FRAMReade();
       Length_temp_Normal +=20; 
       T_data.Basic.Mem.Packet.mem.no = 1;      
    }
    else 
    {  
      for(temp = 0 ; temp < temp_1  ; temp++ )
      {
         Memory.Data_ptr    = (uint8 *)(SAVE_START + ( Memory.Tx_temp_Counter++ * 20)) ;         
         Memory.FRAM_WR_ptr = &(T_data.Data.Normal[temp].ymdhms.Year);
         FRAMReade();
         Length_temp_Normal +=20; 
         T_data.Basic.Mem.Packet.mem.no = (temp+1);
      }      
    }
  }
  T_data.Basic.Mem.Seq.mem.Recount = 0;
  if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
    T_data.Basic.Mem.Seq.mem.no++;
  else; 
  T_data.Basic.Mem.Command = P_NORMAL_READ; 
  
  //Com1.bit.DPLC_COM = 0;
  
  Make_same_Frame( Length_temp_Normal ,P_NORMAL_READ) ;
  
  Com1.bit.Waitting_Ack = 1;   
}

void Make_Emc_data(void)
{
    uint16 temp;
    
    while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready
    
    T_data.Data.Normal[0].ymdhms.Year  = (0xFF & RTCYEAR );
    T_data.Data.Normal[0].ymdhms.Month = RTCMON;
    T_data.Data.Normal[0].ymdhms.Day   = RTCDAY;
    T_data.Data.Normal[0].ymdhms.Hours = RTCHOUR;
    T_data.Data.Normal[0].ymdhms.Min   = RTCMIN;
    T_data.Data.Normal[0].ymdhms.Sec   = RTCSEC;
    
    T_data.Data.Normal[0].Rssi         = __swap_bytes(Rssi_Val);
    
    T_data.Data.Normal[0].AddupFlow_H  = __swap_bytes(Dec_Counter_H);
    T_data.Data.Normal[0].AddupFlow_L  = __swap_bytes(Dec_Counter_L);
    
    T_data.Data.Normal[0].InstanFlow_00 = 0;
    
    asm_temp = Instant_Q  ; // ���� ����
    Hex2Bcd32(asm_temp);
    temp = asm_temp_12;
    
    T_data.Data.Normal[0].InstanFlow_L = __swap_bytes(temp);
    
    temp = Pressure.Value / 1000 ;
    temp = __swap_bytes(temp);  
    T_data.Data.Normal[0].PressDigit_I = temp & 0xff;
    temp >>=8;
    T_data.Data.Normal[0].PressDigit_F = temp & 0xff;
    T_data.Data.Normal[0].St1.all      = St1.all;
    T_data.Data.Normal[0].St2.all      = St2.all; 
    T_data.Data.Normal[0].St3.all      = St3.all; 
    
    T_data.Basic.Mem.Seq.mem.Recount = 0;    
    Uart_counter = 0;
}

void COM_request(void)
{
  
    if(Com2.bit.Comm_Doning == 0) // ���� �ϴ� ����� ������.
    {
      if(Com2.bit.Watting_COM)    // ��� ���� ����� �ִ�.
      {
        Com2.bit.Watting_COM = 0;
        Nb_Retry_count       = 0;
        Com.bit.On_Module    = 1;
        OK_Counter           = 0;
        Guard.bit.Sequence   = 1;
        Com2.bit.Data_tx_ready_Ok        = 1;
        T_data.Basic.Mem.Seq.mem.Recount = 0;
      }
    }    
    if( Com.bit.On_Module )
    {
      Com.bit.On_Module            = 0;
      Com2.bit.Comm_Doning         = 1;
      

      if(T_data.Basic.Mem.Seq.mem.Recount == 0)
      {
        if(Com1.bit.DPLC_COM == 0)//Com1.bit.DPLC_COM = 1; // DPLC�� ���� data �̹Ƿ� DPLC�� ������.
          T_data.Basic.Mem.Seq.mem.no++;
        else;
      }
      else;
      
      if(T_data.Basic.Mem.Command != P_NORMAL_READ)
      {
        T_data.Basic.Mem.Packet.mem.Next = 0;
        T_data.Basic.Mem.Packet.mem.no   = 1;
      }      
 
      if((Com.bit.Ready_EMC)&&(Com2.bit.Watting_COM==0))
      {
        Com.bit.Ready_EMC = 0; 
        Make_Emc_data();
        Nb_Retry_count           = 0;
        T_data.Basic.Mem.Command = P_EMC_READ;
      }
      else if(( Com1.bit.Button_Com )&&(Com2.bit.Watting_COM==0))
      {
        Com1.bit.Button_Com      = 0;
        Make_Emc_data();
        Nb_Retry_count           = 0;
        T_data.Basic.Mem.Command = P_COM_READ;  
      }
      else if(( Com2.bit.Test_Bench )&&(Com2.bit.Watting_COM==0))
      {
        Com2.bit.Test_Bench = 0;
        Make_Emc_data();
        Nb_Retry_count           = 0;
        T_data.Basic.Mem.Command = P_COM_READ;         
      }
      else ;
      
      switch( T_data.Basic.Mem.Command)
      {        
        case P_COM_READ :
          Make_same_Frame(P_COM_LENGH ,P_COM_READ) ;        
          break;
        case P_EMC_READ :
          Make_same_Frame(P_EMC_LENGH ,P_EMC_READ) ;        
          break;              
         case P_NORMAL_READ :
          Make_same_Frame(Length_temp_Normal ,P_NORMAL_READ) ;        
          break;       
        case P_MODIFY_SUM :      
          Make_same_Frame(P_MODIFY_SUM_LENGH ,P_MODIFY_SUM) ;
          break;
        case P_TIME_SYNC: 
          Make_same_Frame(P_TIME_SYNC_LENGH ,P_TIME_SYNC) ; 
          break;
        case P_COM_INERVAL_SET:
          Make_same_Frame(P_COM_INERVAL_SET_LENGH ,P_COM_INERVAL_SET) ;
          break;
        case P_READ_SAVE_INTVAL_SET:
          Make_same_Frame(P_READ_SAVE_INTVAL_SET_LENGH ,P_READ_SAVE_INTVAL_SET) ; 
          break;
        case P_PRESSURE_INTVAL_SET:
          Make_same_Frame(P_PRESSURE_INTVAL_SET_LENGH ,P_PRESSURE_INTVAL_SET) ; 
          break;
        case P_REQ_RETRY_TIME:
          Make_same_Frame(P_REQ_RETRY_TIME_LENGH ,P_REQ_RETRY_TIME) ; 
          break;
        case P_MODEM_B_SET_DAY:
          Make_same_Frame(P_MODEM_B_SET_DAY_LENGH ,P_MODEM_B_SET_DAY) ;
          break; 
      }           
    }// end if( Com.bit.On_Module )....
}


