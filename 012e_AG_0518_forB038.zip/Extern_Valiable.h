#include "Struct.h"
#include "Lcd.h"
#include "Protocol.h"

extern union rtC                        Rtc;
extern union def_st_flag                Stflag;
extern union def_Comm_flag              Com;
extern union def_Comm_flag1             Com1;
extern union def_Comm_flag2             Com2;
extern union def_Comm_flag3             Com3;
extern union def_st_leak_test_flag      leak;
extern union def_st_port_test_flag      Botton;
extern union def_lcd_error_flag         LED_error;
extern union def_guard_flag             Guard;


//extern st_mem                  Stack;
extern st_mem_Pressure         Pressure ;
extern st_mem_ADC              Battery;
extern st_mem_memory           Memory;

extern const char       LCD_Tab[11];
extern const char       LCD_Tab_Center[14];
extern const char       LCD_ICON[14];
extern const char       IOCN_MAP[11];
extern const char       LCD_ROLL[7];


extern uint8           Roll;

extern uint32          Test_0;
extern uint16          test;

extern uint8           Bcc1_Xor;
extern uint8           Bcc2_Sum;
extern uint8           Buzzer_05s_counter;
extern uint8           Buzzer_Sec_counter;

extern uint16          PosEdge_Counter;
extern uint16          NegEdge_Counter;
extern uint16          Capture_D_Counter;
extern uint8           Input_Pulse_Counter;

extern uint16          Dec_Counter_H;
extern uint16          Dec_Counter_L;

extern uint16          Hex_Counter_H;
extern uint16          Hex_Counter_L;

extern uint32           Hex_Counter_025;

extern uint16          Instant_Q;
extern uint16          Sum_Q_Per10Sec;

extern uint8           Sec5_counter;
extern uint8           Sec10_counter;
extern uint8           Sec20_counter;
extern uint8           Min01_counter;
extern uint8           Min60_counter;

extern uint16          LowBatteryHour_counter;

extern uint16          U250_counter;

extern uint16          St2_Leak_Old_C;
extern uint16          St2_Leak_Min_counter;

extern uint16          St3_Over_Old_Q3_1;
extern uint16          St3_Over_Q3_1_counter;

extern uint16          St5_Unused;
extern uint16          St5_Unused_counter;

extern uint16          St4_Unuse_1min_counter;

extern uint16          Dec_Pulse_Counter;

extern uint16          OverQ3_Per_5sec_Value;
extern uint16          LeakQ3_Per_1min_Value;
extern uint16          LeakQ1_Per_1min_Value;
extern uint16          Leak_Per_1min_Counter;

extern uint8           Button_temp ;
extern uint8           StartTimetemp;
//extern uint16          CurrentMInStep[10];

extern uint8           Relese_Unused_counter;
extern uint8           Relese_Unused_test_on;
extern uint8           Relese_Unused_test_sec;

extern uint16          P_test_32hz_counter ;

extern  union sT1 St1;
extern  union sT2 St2;
extern  union sT3 St3;

extern union  Rx_Frame R_data;
extern union  Tx_Frame T_data;

//extern uint8  MeterID[8];
extern uint8  DeviceID;
extern uint16 TX_counter;
extern uint8  *TX_A1_pointer;
extern uint16 *U16_ptr;
extern uint8  *U8_ptr;
extern uint16 Temp_Lenght;
extern uint16 Data_Lenght;
extern uint8  XOR_Bcc1;
extern uint8  SUM_Bcc2;
extern uint8  R_Bcc1;
extern uint8  R_Bcc2;

extern uint8  Defult_retry_count;
extern uint8  Battery_Set_yy ;
extern uint8  Battery_Set_mm ;
extern uint8  Battery_Set_dd ;

extern uint16 Com_inertval_MIN  ;
extern uint16 Com_inertval_MIN_Counter;

extern uint16 Read_Save_Interval_MIN ;
extern uint16 Read_Save_Interval_MIN_Counter;

extern uint16 Pressure_inteval_MIN  ;
extern uint16 Pressure_inteval_MIN_Counter;

extern uint16 Battery_inteval_MIN  ;
extern uint16 Com_Battery_MIN_Counter;

extern uint16 Rssi_Val;
extern uint8  Meter_Jong;
extern uint8  Meter_Type;

extern uint8  EMC_command;
extern uint8  Valve_working_Sec;

extern uint16 LCD_Init_Counter;

extern uint16          Guard_Counter0;
extern uint16          Guard_Counter1;
extern uint16          Guard_Counter2;
extern uint16          Guard_Counter3;
extern uint16          Guard_Counter4;
extern uint16          Guard_Counter5;
extern uint16          Guard_Counter6;

extern uint8           Under_20L;
extern uint8           Min3_counter;
extern uint16          Min3_Per_Pulse;
extern uint16          Min3_Old_Pulse;
extern uint16          Under_20L_Current;

extern reQ_METER_SETUP_W Save;

extern reP_NORMAL_READ   Woking;
extern uint16      asm_temp;   // only asm
extern uint16      asm_temp_15;
extern uint16      asm_temp_14;
extern uint16      asm_temp_13;
extern uint16      asm_temp_12;  

extern uint16 toggle_counter_0_5;
extern uint16 ADC_test_32hz_counter;
extern uint16 Length_temp_Normal;

extern uint8   AT_case;
extern uint8   AT_Sub_case;
extern uint8   *Ptr_at;
extern uint16  Str_Counter_at;
extern char    Nb_Str_Rx[150]; 
extern char    Nb_Str_Rx_temp[150];
//extern char    arg[3][64];
extern uint8   _index;
extern uint8   Nb_Retry_count;   
extern uint8   Nb_old_AT_case; 
extern uint8   Char_Length;
extern uint8   Char_Order;

extern uint16  MLWDLDataLen; 

/* Place following variables in segment NBIOT_RAM" */
#pragma default_variable_attributes = @ "NBIOT_RAM"
extern char   Nb_Str_Tx[];
extern char   Nb_CGSN[];  // Ȯ�� �� ���� 123456789012339 15���� ���´�.
extern char   Nb_CIMI[];  
extern char   Nb_MUICCIDD[]; 
extern char   Nb_NCDP[];
extern char   CIMI_Temp[];
extern char   MUICCIDD_Temp[];
extern uint8  MeterID[];
extern uint8  Cgsn;
extern  uint8 Data_index               ;
extern  uint8 OK_index ;    

extern union _oneHex Onehex;
extern union _oneHex Step1hex;
extern uint8  Mad_str[];
extern uint8  Mad_counter;
extern uint8  *Mad_Ptr;
extern uint8  Const_String_Counter;
extern uint16 CharEnd_counter;
extern uint16 MadNum; 
extern char TX_data_Temp[];
extern uint8  CTN_temp[];

/* Stop placing variables into NBIOT_RAM */
#pragma default_variable_attributes =

extern uint8 Lcd_Off_Counter;
extern uint8 Half_Detect;
extern uint16 Power_On_Counter; 
extern uint16 RF_Module_Counter;
extern uint16 Cop_watting_Counter;
extern uint16 Creg1_5_watting_Counter;
extern uint8  Creg_state;
extern uint8  Reboot_Counter;
extern uint16 Sequence_Counter;
extern uint16 T_data_number;
extern uint8  HW_Reboot_counter;
extern uint8  Reset_Reboot_Day;
extern uint16  ReInit_counter;
extern uint8  RetrySec_counter;
extern uint8  OK_Counter;  // ok�� �޾��� ��� ����. 
extern uint8  Tx_icon_on_Counter;  // ok�� �޾��� ��� ����.
extern uint8  Rx_icon_on_Counter;  // ok�� �޾��� ��� ����.
extern uint8  Illegal_Counter;     // �ڼ��� ���� �Ǿ��� ��� ����.. 
extern uint8  Uart_counter;
extern uint16 Return_Ilegal_counter;  
extern uint8  RegRetry;
extern uint8  MLW_Event;  //�ʱ� ���� deregi   0:reg 1:dereg 3:observe 5:fota observe
extern uint16  WattingReg_Counter;
extern uint8  WattingDereg_Counter;	//�ִ� 3�� �̹Ƿ�..96 ��.. 255 �Ѿ�� ����...
extern uint8  DelayedPostDeregReqCounter;	//�ִ� 3�� �̹Ƿ�..96 ��.. 255 �Ѿ�� ����...
//--------- FTM ----------
extern const unsigned char string_ok[];

extern st_mem_func_test   Factory;
extern st_mem_ftm_memory  Factory_Memory;

extern uint8 ftm_uart_a1_rx[50];
extern uint8 sw_version[3]; 
extern uint8 refresh_ftm_display;
extern uint8 refresh_normal_display;

extern uint8 FTM_mode_flag;
extern uint8 uart_rx_done_flag;
extern uint8 A1_Rx_FTM;
//-----------------------
extern st_log_save_counter_type	Logo;