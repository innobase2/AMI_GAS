#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"

void RTC_Init(void);
void RTC_SETTING(void);
void  RTC_Read(void);
void  RTC_Write(void);
//The prescale dividers, RT0PS and RT1PS, are automatically configured to provide a 1-second clock
//interval for the RTC_C. 

void RTC_Init(void)
{
   // Configure RTC_C
    RTCCTL0_H = RTCKEY_H;                   // Unlock RTC
    RTCCTL0_L = RTCTEVIE | RTCRDYIE;        // enable RTC read ready interrupt
                                            // enable RTC time event interrupt

    RTCCTL1 = RTCBCD | RTCHOLD | RTCMODE;   // RTC enable, BCD mode, RTC hold
    while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready
    RTCYEAR = 0x2017;                       // Year = 0x2017
    RTCMON = 0x3;                           // Month = 0x03 = Mar
    RTCDAY = 0x01;                          // Day = 0x01 = 1th
    RTCDOW = 0x03;                          // Day of week = 0x01 = Monday
    RTCHOUR = 0x12;                         // Hour = 0x10
    RTCMIN = 0x00;                          // Minute = 0x32
    RTCSEC = 0x00;                          // Seconds = 0x45

    RTCCTL1 &= ~(RTCHOLD);                  // Start RTC   
}

void RTC_Read(void)
{
  if(Rtc.bit.Read)
  {
    Rtc.bit.Read = 0;
    // 
  }
}
void RTC_Write(void)
{
  if(Rtc.bit.Write)
  {
    Rtc.bit.Write = 0;
    RTCYEAR = 0x2017;                       // Year = 0x2017
    RTCMON = 0x3;                           // Month = 0x03 = Mar
    RTCDAY = 0x01;                          // Day = 0x01 = 1th
    RTCDOW = 0x03;                          // Day of week = 0x01 = Monday
    RTCHOUR = 0x12;                         // Hour = 0x10
    RTCMIN = 0x00;                          // Minute = 0x32
    RTCSEC = 0x00;                          // Seconds = 0x45    
  }  
}

uint8 temp_uart_data;

#pragma vector=RTC_VECTOR
__interrupt void RTC_ISR(void)
{
  SET_TEST3
    switch(__even_in_range(RTCIV, RTCIV_RT1PSIFG))
    {
        case RTCIV_NONE:      break;        // No interrupts
        case RTCIV_RTCOFIFG:  break;        // RTCOFIFG
        case RTCIV_RTCRDYIFG:               // RTCRDYIFG
          
             RTC_Write();
             RTC_Read();
             
//             while(!(UCA1IFG&UCTXIFG));
//             UCA1TXBUF = temp_uart_data++;              
             
             
             Sec5_counter++;
             if(Sec5_counter>=5){ Sec5_counter = 0;Rtc.bit.Sec5 = 1 ;} 
             else;
             
             Sec10_counter++;
             if(Sec10_counter>=10){ Sec10_counter = 0;Rtc.bit.Sec10 = 1; }
             
             Sec20_counter++;
             if(Sec20_counter>=20){ Sec20_counter = 0;Rtc.bit.Sec20 = 1; }              
            
            //Stflag.bit.LCD_display = 1;
            __bic_SR_register_on_exit(LPM3_bits);
            //XOR_LED
            break;
        case RTCIV_RTCTEVIFG:               // RTCEVIFG
             Rtc.bit.Min1 = 1;             
             Min60_counter++;
             if(Min60_counter>=60){ Min60_counter = 0;Rtc.bit.Min60 = 1; Reboot_Counter = 0; }             
             if( Reset_Reboot_Day != RTCDAY)
             {
               HW_Reboot_counter = 0;
               Reset_Reboot_Day  = RTCDAY;
             }
            
            __no_operation();               // Interrupts every minute
            break;
        case RTCIV_RTCAIFG:   break;        // RTCAIFG
        case RTCIV_RT0PSIFG:  break;        // RT0PSIFG
        case RTCIV_RT1PSIFG:  break;        // RT1PSIFG
        default: break;
    }
  CLR_TEST3
}
