#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"

void GPIO_Setting(void);
void Retutn_SW(void);
void Magnet_CHK(void);

void GPIO_Setting(void)
{
  
  LFT_XTAL_SEL //lF Crystal
  //ALL_PORT_LOW
  //ALL_PORT_OUT
    
  //input pullup  
  P2DIR &= ~BIT1;  
  P2REN |= BIT1;
  P2OUT |= BIT1;
    
  IN_DIR_INT0EARTH
   
  IN_DIR_BATT_TEMPER // 16
  H2L_EDGE_SEL_BATT_TEMPER
  FLGA_CLR_BATT_TEMPER
  EINT_PORT_BATT_TEMPER  
    
  IN_DIR_INT1EARTH

  IN_DIR_P_TEST
  H2L_EDGE_SEL_P_TEST
  FLGA_CLR_P_TEST
  EINT_PORT_P_TEST

  CLR_BUZZER  
  OUT_DIR_BUZZER
  CLR_TEST1  
  OUT_DIR_TEST1  
  CLR_TEST2  
  OUT_DIR_TEST2
  CLR_TEST3  
  OUT_DIR_TEST3 
  CLR_LED  
  OUT_DIR_LED
    
  IN_DIR_D_CHK  // Test battery Open PORT
  H2L_EDGE_SEL_D_CHK 
  FLAG_CLR_D_CHK  
  EINT_PORT_D_CHK
    
  IN_DIR_PULSE_IN
    PULSE_IN_TB0CCI2A_SEL
  IN_DIR_CO2_SENSOR  
  IN_DIR_GAS_SENSOR
  SET_SV_OUT          // on LDO 
  CLR_SV_OUT          // off LDO      
  OUT_DIR_SV_OUT 
    
  IN_DIR_RETURN
    
  H2L_EDGE_SEL_RETURN
  FLGA_CLR_RETURN
  EINT_PORT_RETURN   
  
  /*
    IN_DIR_INC_BUTTON
    H2L_EDGE_SEL_INC_BUTTON
    FLGA_CLR_INC_BUTTON
    EINT_PORT_INC_BUTTON

    IN_DIR_DIG_BUTTON
    H2L_EDGE_SEL_DIG_BUTTON
    FLGA_CLR_DIG_BUTTON
    EINT_PORT_DIG_BUTTON 

    IN_DIR_PRO_BUTTON 
    H2L_EDGE_SEL_PRO_BUTTON
    FLGA_CLR_PRO_BUTTON
    EINT_PORT_PRO_BUTTON 
*/
    OUT_DIR_INC_BUTTON
    CLR_INC_BUTTON
        
    OUT_DIR_DIG_BUTTON 
    CLR_DIG_BUTTON      
            
    OUT_DIR_PRO_BUTTON
    CLR_PRO_BUTTON 

    
  CLR_CW  
  OUT_DIR_CW
  CLR_CCW  
  OUT_DIR_CCW
  CLR_DRV_OUT  
  OUT_DIR_DRV_OUT  
  CLR_TEST4
  OUT_DIR_TEST4
  CLR_INITIAL_SETTING
  IN_DIR_INITIAL_SETTING 
  CLR_PULSE_OUT  
  OUT_DIR_PULSE_OUT
  LOW_BATT_ADC_SEL  
  CLR_LOW_BATT_1_EN  
  OUT_DIR_LOW_BATT_1_EN  
  CLR_MODEM_RESET    // RESET LOW  
  //SET_MODEM_RESET  
  OUT_DIR_MODEM_RESET
  CLR_LOW_BATT_1_LOAD
  OUT_DIR_LOW_BATT_1_LOAD
  IN_DIR_MAGNET_CHK    

       

  // Disable the GPIO power-on default high-impedance mode to activate
  // previously configured port settings
  PM5CTL0 &= ~LOCKLPM5;
}



void Retutn_SW(void)
{
  if(Botton.bit.Return)                       // gpio.c���� 
  {
    Botton.bit.Return   = 0;
    Botton.bit.P_test   = 0;
    if(Botton.bit.Error_State)                // �ܺ� ��� ���� �̴�.
    {
      Botton.bit.Error_State = 0;
      LCDM17 = LCDM2 = LCDM3 = LCDM6 = LCDM7 = LCDM13 = LCDM14 = LCDM4 = LCDM5 = 0x0;
      
      DI1_MEM = LCD_Tab_Center[0];
      T12_D12_MEM |= T1;
      T12_D12_MEM |= T2;
      T3_MEM |= T3;
      T4_MEM |= T4;
      
      St1.all = 0;
      St2.all = 0;
      St3.all = 0;
      
      Under_20L_Current = 0;
      Stflag.bit.Conti_Buzzer = 0;
      Buzzer_Sec_counter      = 0;
    }
    else 
    {
      if(Botton.bit.Unused_test)
      {
        Botton.bit.Unused_test = 0;
        toggle_counter_0_5  = 0;
        S9_MEM &= ~S9 ;    
      }
      else 
      {
        Botton.bit.Unused_test = 1;
        toggle_counter_0_5     = 1;
        Half_Detect = Stflag.bit.Pulse_H_Stable;
        S9_MEM |= S9 ; //  �����Ǹ� ���� on
      }
    }
  }
  if((Com2.bit.Key_5sec_Ok)&&(READ_RETURN))
    Com2.bit.Five_Sec_Watting = 0;
    
  
}

// Port 1 interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
  //SET_TEST3
    if(READ_INC_BUTTON == 0)
    {
      Button_temp |= INC_BUTTON; 
    }
    if(READ_PRO_BUTTON == 0)
    {
      Button_temp |= PRO_BUTTON;
    }    
    if(READ_DIG_BUTTON == 0)
    {
      Button_temp |= DIG_BUTTON;
    } 
    if(READ_RETURN == 0)
    {
      if(Com2.bit.Five_Sec_Watting == 0)
      {
        P_test_32hz_counter = 0;  // ���� icon 0.5 blinking.
        Botton.bit.P_test   = 1;
        toggle_counter_0_5  = 0;
        Com2.bit.Five_Sec_Watting = 1;
        Com2.bit.Key_5sec_Ok = 0;
        if(S9_MEM & S9) Com2.bit.S9_Old_State = 1;
        else            Com2.bit.S9_Old_State = 0;
      }

    }  
    P1IFG = 0;
  //CLR_TEST3
}

// Port 2 interrupt service routine
#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void)
{
//SET_TEST3
    if(READ_BATT_TEMPER == 0)
    {
      Stflag.bit.Save_mem = 1;
    }  

    P2IFG = 0;
    __bic_SR_register_on_exit(LPM3_bits); 
//CLR_TEST3
}    
  
// Port 3 interrupt service routine
#pragma vector=PORT3_VECTOR
__interrupt void Port_3(void)
{
//SET_TEST3
    if(READ_P_TEST == 0)
    {
      P_test_32hz_counter = 0;
      Botton.bit.P_test   = 1;
    }  
    if(READ_D_CHK == 0)
    {
      P_test_32hz_counter = 0;
      Botton.bit.P_test   = 1;
    }
    else; 

    P3IFG = 0;
//CLR_TEST3
}    


