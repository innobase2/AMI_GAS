#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"
#include <string.h>
#include <stdlib.h>
#include "UUID_generate\uuid.h"

//char * strcpy ( char * destination, const char * source ); //source�� destination�� �����Ѵ�.
//char * strcat ( char * destination, const char * source ); //source�� destination�ڿ� ���δ�.
//char * strtok ( char * str, const char * delimiters );     //str1�� delimiters�� ���ڵ�� �и��Ѵ�.
//int strcmp ( const char * str1, const char * str2 );       //str1�� str2�� ���Ѵ�.
//void * memset ( void * ptr, int value, size_t num );       //ptr�� ����Ű�� �޸��� ó�� num����Ʈ�� value��(����)���� ä���.

void Mad_string_make_step1(uint8  *OneHex);
void Mad_string_make_step2(uint8  *Mptr1);
void Mad_make( uint8  *Mptr2 );
uint8 DeCoding_Mad_data( uint8 *mad);
void Nuel_Data_com(void);

uint8 Onebyte_char_2_NibbleHex(uint8 Onechar);
void Uart_tx_Str(const uint8* p, uint8 n);
void NBiot_Module_Init(void);
void NBiot_Module_Rx(void);
void NBiot_Module_Tx(void);
void NBiot_Module_Rx_while(void);
void NBiot_Module_Tx_while(void);

void Nb_Tx_ComProcess(const uint8 *Tx_temp_ptr);
void Nb_Rx_ComProcess(void);

void Nb_tx_AT_MLWEPNS(void);
void Nb_tx_AT_MLWMBSPS(void);

void Nb_tx_AT_MLWULDATA( uint16 real_length );
void String_fined(void);
int cus_strcmp(char *ptr1, const uint8 *ptr2);

extern inline void DPLC_Data_Process(void );

union st_AT_R_status_mem R_Staus;
char  *Data_ptr[8];
int   DataPtr_cnt=0;


char uuid[26];
static const uint8 _OK[] = {"OK"};
static const uint8 _ERROR[] = {"ERROR"};
//static const uint8 _CEREG[] = {"+CEREG:"};
const uint8 _AT_CSQ[] = {"AT+CSQ\r\n"};
//static const uint8 _Uatr_Task[] = {"Uart Task!!"};
//static const uint8 _Neul[] = {"Neul "};
//static const uint8 _REBOOT[] = {"REBOOTING"};
//static const uint8 _REBOOT_CAUSE[] = {"REBOOT_CAUSE_"};
//static const uint8 _DATA_ACK[] = {"1,06"};// ACK

static const uint8 _DEVMODEL[]                ={"Summer"};

static const uint8 _AT_NBAND[]                ={"AT+NBAND=5\r\n"};
static const uint8 _AT[]                      ={"AT\r\n"};                              //Protocol Stack Reset
static const uint8 _AT_CGATT0[]                      ={"AT+CGATT=0\r\n"};                              //Protocol Stack Reset

static const uint8 _AT_CFUN1[]                ={"AT+CFUN=1\r\n"};                       //Protocol Stack Reset
static const uint8 _AT_CFUN0[]                ={"AT+CFUN=0\r\n"};                       //Protocol Stack Reset
static const uint8 _AT_NCONFIG_AUTOCONNECT[]  ={"AT+NCONFIG=AUTOCONNECT,FALSE\r\n"};    //���� �ڵ� ���� ����
static const uint8 _AT_NCONFIG_NEWSCRAMBLING[]={"AT+NCONFIG=NEWSCRAMBLING,FALSE\r\n"};  //���� �ڵ� ���� ����
static const uint8 _AT_NCONFIG_AUTOCONNET_TRUE[]  ={"AT+NCONFIG=AUTOCONNECT,TRUE\r\n"};    //���� �ڵ� ���� 
static const uint8 _AT_NCONFIG_NEWSCRAMBLING_TRUE[]={"AT+NCONFIG=NEWSCRAMBLING,TRUE\r\n"};  //���� �ڵ� ���� 
static const uint8 _AT_NBR[]                  ={"AT+NRB\r\n"};                          //SW Reset    // 
static const uint8 _AT_CGSN[]                 ={"AT+CGSN=1\r\n"};                       // IMEI �б� EndPoint �Ķ���ͷ� ����
static const uint8 _AT_COPS[]                 ={"AT+COPS=1,2,\"45006\"\r\n"}; 
static const uint8 _AT_CIMI[]                 ={"AT+CIMI\r\n"};                         //IMSI �б� Device ID�� ����
static const uint8 _AT_MUICCIDD[]             ={"AT+MUICCID?\r\n"};                    //USIM�� ICCID �б� EndPoint �Ķ���ͷ� ����
static const uint8 _AT_NCDP[]                 ={"AT+NCDP=106.103.233.155,5783\r\n"};   //���� IP �� ��Ʈ ����, ���� ���� ���� ���.
//static const uint8 _AT_NCDP[]                 ={"AT+NCDP=123.143.211.27,5783\r\n"};   //���� IP �� ��Ʈ ����, ���� ���� ���� ���.
//static const uint8 _AT_NCDP[]                 ={"AT+NCDP=106.103.230.36,5783\r\n"};   //���� IP �� ��Ʈ ����  -- �˼���
static const uint8 _AT_SET_CEREG[]            ={"AT+CEREG=1\r\n"};
static const uint8 _AT_Q_CEREG[]              ={"AT+CEREG?\r\n"}; 
static const uint8 _AT_MLWEPNS[]              ={"AT+MLWEPNS="};                        //EndPoint ����
//static const uint8 _AT_MLWMBSPS[]={"AT+MLWMBSPS=serviceCode=GAMR|deviceSerialNo=1234567|ctn=01022332212|iccId=35823F|deviceModel=Summer|mac=\r\n"};  // -- �˼���
static const uint8 _AT_MLWMBSPS[]={"AT+MLWMBSPS=serviceCode=GAMR|deviceSerialNo=1234567|ctn=01022335078|iccid=17313F|deviceModel=Summer|mac=\r\n"};
//                                               hardcoding fix                    ....            ctn          iccid             hardcoding fix
//static const uint8 _AT_MLWMBSPS[]={"AT+MLWMBSPS=serviceCode=GAMR|deviceSerialNo=1234567|ctn=01222990845|iccId=17313F|deviceModel=Summer|mac=\r\n"}; // ���� ����
static const uint8 _AT_MBOOTSTRAPMODE[]       ={"AT+MBOOTSTRAPMODE=1\r\n"};              //BootStrap ��� ����
static const uint8 _AT_MLWULDATA[]            ={"AT+MLWULDATA="};
static const uint8 _AT_MLWGOBOOTSTRAP[]       ={"AT+MLWGOBOOTSTRAP=1\r\n"};
static const uint8 _AT_MLWSREGIND_CLR[]       ={"AT+MLWSREGIND=0\r\n"};
static const uint8 _AT_MLWSREGIND_SET[]       ={"AT+MLWSREGIND=1\r\n"};
static const uint8 _AT_FOTA_EVENT_ENABLE_STR[]       ={"AT+MLWFOTAIND=1\r\n"};
static const uint8 _AT_FOTA_DONWLOAD_RSP_STR[]       ={"AT+MLWFOTAIND=2\r\n"};
static const uint8 _AT_FOTA_UPDATE_RSP_STR[]       ={"AT+MLWFOTAIND=4\r\n"};


void NBiot_Module_Init(void)
{
  __delay_cycles(8000000); //
  UCA0IFG = 0;
  UCA0IE |= UCRXIE;
  
  Com1.bit.At_Init_done = 0;
  AT_case               = _AT_NUM;
  Com1.bit.At_Tx_start  = 1;
  
  Nb_Retry_count        = 0;
  Nb_old_AT_case        = 0;
  Guard.bit.RF_Module   = 1;
  RF_Module_Counter     = 0;
  
  S10_MEM |= S10;
  S11_MEM |= S11;  
  S1TO8_MEM |= S6;
  Com2.bit.Module_Fail  = 1;
  while( Com1.bit.At_Init_done == 0)
  {
    NBiot_Module_Tx();
    NBiot_Module_Rx();  
  }
}
void NBiot_Module_Tx(void)
{
  if(Com1.bit.At_Tx_start)
  {
    Com1.bit.At_Tx_start = 0;      
    if(_AT_NUM != AT_case )  __delay_cycles(100000);  //���� ���� �ð� ������ �ʿ��ϸ� ���ش�...
    switch(AT_case)
    {
      case _AT_NUM                        :  Nb_Tx_ComProcess(_AT );           break;
	  case _AT_CGATT_0				 :  Nb_Tx_ComProcess(_AT_CGATT0 );           break;
      case _AT_CFUN1_NUM                  :  Nb_Tx_ComProcess(_AT_CFUN1);      break;
      case _AT_CIMI_NUM                   :  Nb_Tx_ComProcess(_AT_CIMI);       break;  
      case _AT_MUICCIDD_NUM               :  Nb_Tx_ComProcess(_AT_MUICCIDD);   break; 
      case _AT_CGSN_NUM                   :  Nb_Tx_ComProcess(_AT_CGSN);       break; 
      case _AT_CFUN0_NUM                  :  Nb_Tx_ComProcess(_AT_CFUN0);      break;      
      case _AT_NCONFIG_AUTOCONNECT_NUM    :  Nb_Tx_ComProcess(_AT_NCONFIG_AUTOCONNECT);      break; 
      case _AT_NCONFIG_NEWSCRAMBLI_NUM    :  Nb_Tx_ComProcess(_AT_NCONFIG_NEWSCRAMBLING);    break; 
      case _AT_NCDP_NUM                   :  Nb_Tx_ComProcess(_AT_NCDP);       break;
      case _AT_MLWEPNS_NUM                :  Nb_tx_AT_MLWEPNS();               break;
      case _AT_MLWMBSPS_NUM               :  Nb_tx_AT_MLWMBSPS();   break;
      case _AT_NCONFIG_AUTOCONNET_TRUE_NUM    :  Nb_Tx_ComProcess(_AT_NCONFIG_AUTOCONNET_TRUE);       break; 
      case _AT_NCONFIG_NEWSCRAMBLING_TRUE_NUM :  Nb_Tx_ComProcess(_AT_NCONFIG_NEWSCRAMBLING_TRUE);    break;      
      case _AT_NRB_NUM                    :  Nb_Tx_ComProcess(_AT_NBR);        break;
      case _AT_NBAND5_NUM                 :  Nb_Tx_ComProcess(_AT_NBAND);      break;
//      case _AT_MBOOTSTRAPMODE_NUM         :  Nb_Tx_ComProcess(_AT_MLWGOBOOTSTRAP);   break;
//      case _AT_CEREG_NUM                  :  Nb_Tx_ComProcess(_AT_CEREG);            break;
//      case _AT_COPS_NUM                   :  Nb_Tx_ComProcess(_AT_COPS);             break;
    }
    R_Staus.all = 0; // ���� 0415 -- �߰�
  }
  else ;  
}
void NBiot_Module_Rx(void)
{
  uint16 loop;
  uint8  *St_ptr;
  uint8  temp_num;  
   
  if(Com1.bit.At_Rx_end)
  {
    Com1.bit.At_Rx_end = 0;    
    String_fined();    
    if(R_Staus.OK == 1 )
    { 
      TA3CCTL2 = 0;
      RetrySec_counter = 0;
 	   Nb_Retry_count				= 0;
      switch(AT_case)
      {
        case _AT_NUM :{
          AT_case           = _AT_CGATT_0 ;
          Nb_old_AT_case    = _AT_NUM; 
		  Com1.bit.At_Tx_start = 1;
        }
        break; 
		case _AT_CGATT_0 :{
          AT_case           = _AT_MUICCIDD_NUM ;
          Nb_old_AT_case    = _AT_CGATT_0; 
		  Com1.bit.At_Tx_start = 1;
        }
        break; 		
        case _AT_MUICCIDD_NUM :{
          strcpy(MUICCIDD_Temp, (Data_ptr[0]+9)); 
          MUICCIDD_Temp[19] = 'F';
          MUICCIDD_Temp[20] = 0;
          //////////////////////////////For Testing.....//////////////////////////////
          //strcpy(MUICCIDD_Temp,"8982068520044335823F");// -- �˼���
          //strcpy(MUICCIDD_Temp,"8982068597002917313F"); 
          //strcpy(MUICCIDD_Temp,"8982068597002917313F");// -- ���� ���� ��ħ -- 0845��
          //////////////////////////////For Testing.....//////////////////////////////
          AT_case           =   _AT_CIMI_NUM ; 
          Nb_old_AT_case    = _AT_MUICCIDD_NUM;    
		Com1.bit.At_Tx_start = 1;
        }
        break;        
        case _AT_CFUN1_NUM:{          
        if(Nb_old_AT_case  == _AT_NUM )   AT_case  = _AT_CIMI_NUM;            
        else  AT_case  = _AT_NRB_NUM; 
        Nb_old_AT_case = _AT_CFUN1_NUM;  
		Com1.bit.At_Tx_start = 1;
        }
        break;   // ���� 0415 -- �߰�
        case _AT_CIMI_NUM :{
          if(R_Staus.Data)
          {		
            *(Data_ptr[0]+4) = '0'; 
            strcpy(CIMI_Temp, Data_ptr[0]+4);        
            //St_ptr = &(CIMI_Temp[1]); 
            
            strcpy(Nb_Str_Tx, CIMI_Temp);
            strcat(Nb_Str_Tx, MUICCIDD_Temp);
            
            simple_uuid_create_md5_from_name(uuid, &Nb_Str_Tx[0], 31);
            //        CIMI�� ������ METER ID�� �����.          
            strcpy(CIMI_Temp, Data_ptr[0]+4);
            St_ptr = &(CIMI_Temp[1]); 
			memcpy(CTN_temp, CIMI_Temp, 11);
            temp_num = *St_ptr++;
            CIMI_Temp[0] = Onebyte_char_2_NibbleHex(temp_num); 
            
            for(loop = 1; loop < 6 ; loop++)
            {
              temp_num = *St_ptr++;
              CIMI_Temp[loop] = Onebyte_char_2_NibbleHex(temp_num);              
              CIMI_Temp[loop] <<= 4;              
              temp_num = *St_ptr++;
              CIMI_Temp[loop] |= Onebyte_char_2_NibbleHex(temp_num);
            }
            CIMI_Temp[6]=0; 
            CIMI_Temp[7]=0;           
            
#ifdef IMSI_ICCID_CHECK_BOOT
            if( cus_strncmp((char const*)(CIMI_Temp),(char const*)(MeterID), 8 ))  // ������ 0���� �´�.
            {
              if( cus_strncmp((char const*)(MUICCIDD_Temp),(char const*)(Nb_MUICCIDD), 20 ))  // ���� data�� MUCCID ��
              {
                AT_case =_AT_NRB_NUM;
              }
              else AT_case =_AT_CGSN_NUM; 
            }
            else  AT_case =_AT_CGSN_NUM;    
 #else					 
            AT_case =_AT_CGSN_NUM;
 #endif           
            Nb_old_AT_case    = _AT_CIMI_NUM;
            Com1.bit.At_Tx_start = 1;
          }
        }
        break;        
        case _AT_CGSN_NUM :{
          if(R_Staus.Data)
          {
            Nb_old_AT_case      = _AT_CGSN_NUM;
            AT_case             = _AT_CFUN0_NUM;
            strcpy(Nb_CGSN, Data_ptr[0]+6);  // ���� 5->6 0415
		    Com1.bit.At_Tx_start = 1;
            }
          }
        break;        
        case _AT_CFUN0_NUM :{      
          Nb_old_AT_case    = _AT_CFUN0_NUM;  
          AT_case           = _AT_NBAND5_NUM;
  		  Com1.bit.At_Tx_start = 1;
          }
          break;
          case _AT_NBAND5_NUM :{
          AT_case           = _AT_NCDP_NUM ;
          Nb_old_AT_case    = _AT_NBAND5_NUM; 
		  Com1.bit.At_Tx_start = 1;
          }
        break;          
        case _AT_NCONFIG_AUTOCONNECT_NUM :{
          Nb_old_AT_case    = _AT_NCONFIG_AUTOCONNECT_NUM;
          AT_case  = _AT_NCONFIG_NEWSCRAMBLI_NUM;          //,FALSE 
		  Com1.bit.At_Tx_start = 1;
          }
        break;  
        case _AT_NCONFIG_NEWSCRAMBLI_NUM :{
          Nb_old_AT_case    = _AT_NCONFIG_NEWSCRAMBLI_NUM;
          AT_case  = _AT_NRB_NUM;
          
          strcpy(Nb_CIMI,CIMI_Temp);
          strcpy(Nb_MUICCIDD,MUICCIDD_Temp);
          
		   Com1.bit.At_Tx_start = 1;
          }
        break;  
        case _AT_NRB_NUM :{
          if(       Nb_old_AT_case   == _AT_MLWMBSPS_NUM )
          {
          AT_case  = _AT_Q_CEREG_NUM ;
          Com1.bit.Nb_Need_Step2 = 1;
          Com2.bit.Module_Fail   = 0;
          S1TO8_MEM &= ~S6;
          while(Com1.bit.At_Init_done == 0 );
          }          
          else if( Nb_old_AT_case   == _AT_NCONFIG_NEWSCRAMBLI_NUM ) 
          AT_case  = _AT_NCDP_NUM ;
          else if( Nb_old_AT_case   == _AT_CIMI_NUM )  // MUCCID�� CIMI�� ��� ���� ��� 
          {            
          AT_case  = _AT_Q_CEREG_NUM ;  
          Com1.bit.Nb_Need_Step2 =1;                 // STEP1 END
          Com2.bit.Module_Fail   = 0;
          S1TO8_MEM &= ~S6;
          while(Com1.bit.At_Init_done == 0 );
          }
          else;
          
		  Com1.bit.At_Tx_start = 1;
          Nb_old_AT_case    = _AT_NRB_NUM;  
          }
        break;
        case _AT_NCDP_NUM:{
          Nb_old_AT_case    = _AT_NCDP_NUM;
          AT_case           = _AT_MLWEPNS_NUM;
		  Com1.bit.At_Tx_start = 1;
        }
        break;
       case _AT_MLWEPNS_NUM:{
           Nb_old_AT_case    = _AT_MLWEPNS_NUM;        
           AT_case  = _AT_MLWMBSPS_NUM;
		   Com1.bit.At_Tx_start = 1;
           }
        break;      
        case _AT_MLWMBSPS_NUM:{
          Nb_old_AT_case    = _AT_MLWMBSPS_NUM; 
          
          strcpy(Nb_CIMI,CIMI_Temp);           // ���� 0502
          strcpy(Nb_MUICCIDD,MUICCIDD_Temp);   // ���� 0502       
          
          AT_case           = _AT_NRB_NUM;
		  Com1.bit.At_Tx_start = 1;
          }
        break;
          case _AT_NCONFIG_AUTOCONNET_TRUE_NUM:{
          Nb_old_AT_case    = _AT_NCONFIG_AUTOCONNET_TRUE_NUM;
          AT_case  = _AT_NCONFIG_NEWSCRAMBLING_TRUE_NUM;
		  Com1.bit.At_Tx_start = 1;
          }
        break; 
          case _AT_NCONFIG_NEWSCRAMBLING_TRUE_NUM:{
          Nb_old_AT_case = _AT_NCONFIG_NEWSCRAMBLING_TRUE_NUM;  
          AT_case  = _AT_NRB_NUM;          
		  Com1.bit.At_Tx_start = 1;
          }
        break;      
      } // end switch(AT_case)
     // memset(Nb_Str_Rx_temp, 0x00, 150);
      R_Staus.all = 0;
    }   
  }        
}
void NBiot_Module_Tx_while(void)
{
  if(Com1.bit.At_Tx_start)
  {
    Com1.bit.At_Tx_start = 0;      
    switch(AT_case)
    {
      case _AT_NUM                        :  Nb_Tx_ComProcess(_AT );            break;
      case _AT_NRB_NUM                    :  Nb_Tx_ComProcess(_AT_NBR );        break;
      case _AT_SET_CREG_NUM               :  Nb_Tx_ComProcess(_AT_SET_CEREG);     break;
      case _AT_MBOOTSTRAPMODE_NUM         :  Nb_Tx_ComProcess(_AT_MBOOTSTRAPMODE);   break;
      case _AT_MLWGOBOOTSTRAP_NUM         :  Nb_Tx_ComProcess(_AT_MLWGOBOOTSTRAP);   break;
      case _AT_Q_CEREG_NUM                :  Nb_Tx_ComProcess(_AT_Q_CEREG);            break;
      case _AT_COPS_NUM                   :  Nb_Tx_ComProcess(_AT_COPS);             break;
      case _AT_CSQ_NUM                    :  Nb_Tx_ComProcess(_AT_CSQ);             break;
      case _AT_MLWREG_REQ         :  Nb_Tx_ComProcess(_AT_MLWSREGIND_CLR);             break; 
	  case _AT_MLWPOST_DEREG_REQ:		if(MLW_Event == 5 || Com2.bit.Watting_COM) Nb_Tx_ComProcess(_AT ); 
		                                                        else Nb_Tx_ComProcess(_AT_MLWSREGIND_SET);   break;
      case _AT_MLWPRE_DEREG_REQ :		Nb_Tx_ComProcess(_AT_MLWSREGIND_SET);     break; 
    	case _AT_FOTA_EVENT_ENABLE : 	Nb_Tx_ComProcess(_AT_FOTA_EVENT_ENABLE_STR); 		break; 
    	case _AT_FOTA_DONWLOAD_RSP : 	Nb_Tx_ComProcess(_AT_FOTA_DONWLOAD_RSP_STR); 		break; 
    	case _AT_FOTA_UPDATE_RSP : 	Nb_Tx_ComProcess(_AT_FOTA_UPDATE_RSP_STR); 		break; 
		default: break;
    }
    R_Staus.all = 0; // ���� 0415 -- �߰�
  }
  else ;  
}
void NBiot_Module_Rx_while(void)
{
  //uint16 loop;
  //uint8  *St_ptr;
  uint8  temp_num;
  uint16 CsqTemp;
  if(Com1.bit.At_Rx_end)
  {
    Com1.bit.At_Rx_end = 0;    
    String_fined();    
    if(R_Staus.OK == 1 )
    {
      TA3CCTL2 = 0;	//Retry Stop
      RetrySec_counter = 0;
      switch(AT_case)
      {
        case _AT_NRB_NUM :{
          AT_case  = _AT_Q_CEREG_NUM ; 
		 Com1.bit.At_Tx_start = 1;
          Nb_old_AT_case    = _AT_NRB_NUM;
          }
        break;
        case _AT_CSQ_NUM :{          
          if(cus_strncmp( Data_ptr[0] ,"+CSQ:",5))
          {
			if(*(Data_ptr[0]+6) == ',')
				CsqTemp = (*(Data_ptr[0]+5)-'0');
			else
			{	
				CsqTemp = (*(Data_ptr[0]+5)-'0')*10;
				CsqTemp += (*(Data_ptr[0]+6)-'0');
			}
            if( CsqTemp == 99 ) Rssi_Val = 115;
            else 
            {
              if(CsqTemp < 32)
                Rssi_Val = 113-2*CsqTemp;
              else Rssi_Val = 0; 
              asm_temp = Rssi_Val  ; // 
              Hex2Bcd32(asm_temp);
              Rssi_Val = asm_temp_12; // hex--> ��� BCD          
            }        
          } 
		 Com2.bit.CSQ_Ok 						 = 1;
          if(Com1.bit.Nb_Need_Step2)
 		  		Com1.bit.Nb_Need_Step2       = 0;  // step2�� ��ģ��. 
 		  else //Data Sending �����̴�..
             Com2.bit.Data_tx_ready_Ok    = 1;

          if( Com3.bit.RetransmisstionAfterReset)
          {
          	Com3.bit.RetransmisstionAfterReset = 0;
          	Guard.bit.Sequence = 1;     // Ÿ�̸ӿ��� �����ð� �Ǹ� Guard.bit.Sequence =1�� �����.
          	Sequence_Counter   = 0;
          
          	Com2.bit.SendingDataSequence = 1;// data�� ���� �� �ֳ� Ȯ�� ����.
          	Com1.bit.At_Tx_start = 1;
          	AT_case              = _AT_NUM;   
          }
          else
          {	
          	Com2.bit.SendingDataSequence = 0;
			if(	Com2.bit.Data_tx_ready_Ok)
          		AT_case = _AT_MLWDATA_SENDING;	//Data�� ������ ���� csq �� ��� 
			else
				AT_case 	= _AT_END_NUM; 	//step2�� csq �� ���
          }
		   Nb_old_AT_case = _AT_CSQ_NUM;
        }
        break;        
        case _AT_SET_CREG_NUM :{
          
          Nb_old_AT_case = _AT_SET_CREG_NUM;
          //          if(Creg_state == 1) AT_case  = _AT_MBOOTSTRAPMODE_NUM;
          //          else  AT_case  = _AT_COPS_NUM;   
          if(Creg_state ==1 )
          {
            AT_case  = _AT_MBOOTSTRAPMODE_NUM;
            Com1.bit.At_Tx_start         = 1;
            Com1.bit.Creg1_5_Watting     = 0;
          }
          else
		 {
			Com1.bit.Creg1_5_Watting = 1;
			Creg1_5_watting_Counter  = 0;
		  }
        }
        break;
        case _AT_Q_CEREG_NUM :{   // Step 1���� �Ѿ�� ����
          if(cus_strncmp( Data_ptr[0] ,"+CEREG:",7))
          {
            if(*(Data_ptr[0]+9) == '1')
              Creg_state = 1;
            else
              Creg_state = 0; 
          }
          Nb_old_AT_case = _AT_Q_CEREG_NUM;
          AT_case  = _AT_SET_CREG_NUM;
		  Com1.bit.At_Tx_start = 1;
          }
        break;        
        case _AT_COPS_NUM :{          
          AT_case  = _AT_MBOOTSTRAPMODE_NUM;
          Nb_old_AT_case = _AT_COPS_NUM;
          //Creg_state = 0;// --------------------���۽� ������ ���� ���� ���� �ȵ� ����
		Com1.bit.At_Tx_start = 1;
          }          
        break;
        case _AT_MBOOTSTRAPMODE_NUM :{          
          AT_case  = _AT_MLWGOBOOTSTRAP_NUM;
          Nb_old_AT_case = _AT_MBOOTSTRAPMODE_NUM;
          Com1.bit.At_Tx_start = 1;
          }          
        break;        
        case _AT_MLWGOBOOTSTRAP_NUM:{
           Nb_old_AT_case = _AT_MLWGOBOOTSTRAP_NUM;
           if(MLW_Event == 4)
           {
             AT_case  = _AT_CSQ_NUM;
             Com1.bit.At_Tx_start = 1;
             Com1.bit.Creg1_5_Watting =0;
           }
           else
           {
             Com1.bit.Creg1_5_Watting =1;
             Creg1_5_watting_Counter =0;
           }
        }          
        break;
        case _AT_NUM :{
            if(Creg_state) // ���ſ� ���� ���� ���
            {
              Nb_old_AT_case = _AT_NUM;
              //AT_case        = _AT_MBOOTSTRAPMODE_NUM;
              if(MLW_Event ==1 || MLW_Event ==4) // 0: reg 1:dereg 3:overve 4:bootstrap 5:foata quary 6:download_quary 7:update_quary
              	AT_case        = _AT_MLWREG_REQ;
    		  else 
    		      AT_case 			 = _AT_MLWPRE_DEREG_REQ;
              Com1.bit.At_Tx_start = 1;            
            }
            else  
            {
				AT_case	= _AT_Q_CEREG_NUM ; 
				Com1.bit.At_Tx_start = 1;
            }
            Nb_old_AT_case =_AT_NUM ;
        }          
        break;
        case _AT_MLWREG_REQ :{
          Nb_old_AT_case = _AT_MLWREG_REQ;
          if(MLW_Event == 3 )
          {
            AT_case  = _AT_CSQ_NUM;
            Com1.bit.Creg1_5_Watting     = 0;           
            Com2.bit.CSQ_Ok              = 0;
			Com1.bit.At_Tx_start = 1; 					 
          }
          else
         {
				Com1.bit.Creg1_5_Watting = 1;
				Creg1_5_watting_Counter  = 0;
          }
        }
        break;
        case _AT_MLWPOST_DEREG_REQ :{
          Nb_old_AT_case = _AT_MLWPOST_DEREG_REQ;
		if(MLW_Event == 5)//fota init �����̸� fota event�� enable ��Ű��..
		{
			AT_case = _AT_FOTA_EVENT_ENABLE;
			Com1.bit.At_Tx_start = 1; 
			Sequence_Counter = 0;
		}
		 else // fota init ���°� �ƴϸ� ����...
		 {	
			AT_case = _AT_END_NUM;;
  		   Com2.bit.SendingDataSequence = 0;
		 }
          break;          
        }
         case _AT_FOTA_EVENT_ENABLE :{
			Nb_old_AT_case = _AT_FOTA_EVENT_ENABLE;
			if(MLW_Event == 6) // download quary �����̸�.. download �϶�� ������...
			{
				AT_case = _AT_FOTA_DONWLOAD_RSP;
				Com1.bit.At_Tx_start = 1;
				Sequence_Counter = 0;
			}
			break;					
		}
				
          case _AT_FOTA_DONWLOAD_RSP :{
			Nb_old_AT_case = _AT_FOTA_DONWLOAD_RSP;
			if(MLW_Event == 7) //update quary �����̸� .. update �϶�� ������...
			{
				AT_case = _AT_FOTA_UPDATE_RSP;
				Com1.bit.At_Tx_start = 1; 
				Sequence_Counter = 0;
			}
			break;        
		}		
          case _AT_FOTA_UPDATE_RSP :{
            Nb_old_AT_case = _AT_FOTA_UPDATE_RSP;
  		   AT_case = _AT_END_NUM; //update �϶�� ������ ������ �����Ѵ�...
 		   Com2.bit.SendingDataSequence = 0;
          break;          
        }
        case _AT_MLWPRE_DEREG_REQ :{
          if(MLW_Event == 1 ) // Dereg�� �Ϸ� �Ǿ���..
          { 					
            Nb_old_AT_case = _AT_MLWPRE_DEREG_REQ;
			AT_case 			 = _AT_MLWREG_REQ;
 			Com3.bit.WaitPreDeregRsp = 0;
			Com1.bit.At_Tx_start = 1; 
		  }
		  else //dereg�� ������ ���� dereg�� �ȵ�...
		  {	
			  Com3.bit.WaitPreDeregRsp =1;
			  WattingDereg_Counter =0;
		   }
            break; 				 
        }
		default: 
			break;		
      }
    }
    R_Staus.all = 0;
  }
}

void Nb_Tx_ComProcess(const uint8 *Tx_temp_ptr)
{
    Ptr_at = (uint8 *)Tx_temp_ptr;
    Const_String_Counter = 254;   // Hard Coding Sting�ϋ��� 254..
    CharEnd_counter = 0;          // Hard Coding Sting�ϋ��� 0..
#ifdef FEATURE_LOG_SAVE
    Logo_Save(Ptr_at);
#endif
    R_Staus.all = 0;
    Com1.bit.At_Rx_end = 0;
    UCA0TXBUF = *Ptr_at++;
    UCA0IE |=  UCTXIE;  
}
void Nb_tx_AT_MLWMBSPS(void)
{
	//uint8 				CTN[8];// Meter ID
	//uint8 	ICCID_END[6];// ICCID END  iccId=17313F MUICCIDD_Temp

	memcpy(Nb_Str_Tx,"AT+MLWMBSPS=serviceCode=GAMR|deviceSerialNo=",44);
	memcpy(Nb_Str_Tx+44,(uint8*)(FTM_SN_SAVE),6);
	memcpy(Nb_Str_Tx+44+6,"|ctn=",5);
	memcpy(Nb_Str_Tx+44+6+5,CTN_temp,11);
	memcpy(Nb_Str_Tx+44+6+5+11,"|iccId=",7);
	memcpy(Nb_Str_Tx+44+6+5+11+7,&(MUICCIDD_Temp[14]),6);
	memcpy(Nb_Str_Tx+44+6+5+11+7+6,"|deviceModel=Summer|mac=\r\n\0",27);

	Const_String_Counter = 254; 	// Hard Coding Sting�ϋ��� 254..
	CharEnd_counter = 0;	// tn00
	Ptr_at =(uint8 *)(Nb_Str_Tx);
	R_Staus.all = 0;
	Com1.bit.At_Rx_end = 0;

#ifdef FEATURE_LOG_SAVE
	Logo_Save(Ptr_at);
#endif

	UCA0TXBUF = *Ptr_at++;
	UCA0IE |=  UCTXIE;	 
}

void Nb_tx_AT_MLWEPNS(void)
{ 
    memcpy(MeterID  , CIMI_Temp,8 );    
    
//    strcpy(Nb_Str_Tx, CIMI_Temp2);
//    strcat(Nb_Str_Tx, MUICCIDD_Temp);
//    
//    simple_uuid_create_md5_from_name(uuid, &Nb_Str_Tx[0], 31);
    
    Ptr_at = (uint8 *)(_AT_MLWEPNS);
    strcpy(Nb_Str_Tx, _AT_MLWEPNS);
    strcat(Nb_Str_Tx, uuid);
    strcat(Nb_Str_Tx, "\r\n"); 
    CharEnd_counter = 0;  // tn
    Ptr_at =(uint8 *)(Nb_Str_Tx);

#ifdef FEATURE_LOG_SAVE
	Logo_Save(Ptr_at);
#endif
		
    UCA0TXBUF = *Ptr_at++;
    UCA0IE |=  UCTXIE;  
}
void Nb_tx_AT_MLWULDATA( uint16 real_length )
{
    uint16 loop;
    uint8  temp_Bcc[5];
    uint8  temp_str[6]; 

    temp_Bcc[0] = temp_Bcc[1] = 0xF7 ;
    
    memcpy(&(T_data.Basic.Raw[0]),TX_data_Temp,50);
    for(loop = 0 ; loop < real_length -1 ; loop++) // 0xf7�� �����ؼ� �ϳ��� ����.
    {
      temp_Bcc[0]   ^=T_data.Basic.Raw[loop];
      temp_Bcc[1]   +=T_data.Basic.Raw[loop];
    }
    temp_Bcc[2] = '\r';
    temp_Bcc[3] = '\n';
    temp_Bcc[4] = 0;// ������ uart�� �ȳ�����. ����!
    
    loop  = (real_length + 2);
    CharEnd_counter =( real_length + 3 ) + 2  ; // (data * 2) + Bcc+Bcc + margine
    temp_str[0]= (loop/100) + '0';    
    temp_str[1]= (loop/10) - ((loop/100) * 10)  + '0';
    temp_str[2]= (loop%10) + '0';
    temp_str[3]= ',';
    temp_str[4]= 0xf7;  // STX���� ���� �ϱ� ����
    temp_str[5]= 0;     // ������ �̻��ϰ� �ٴ´�. 
    
    memcpy( Nb_Str_Tx, _AT_MLWULDATA, strlen(_AT_MLWULDATA) ); // ����
    memcpy( Nb_Str_Tx + strlen(_AT_MLWULDATA), temp_str, strlen(temp_str) ); // ����
    memcpy( Nb_Str_Tx + strlen(_AT_MLWULDATA)+strlen(temp_str), T_data.Basic.Raw, real_length - 1 ); // data stx�� �̸� �ٿ� ���Ҵ�. �׷��� -1   
    memcpy( Nb_Str_Tx + strlen(_AT_MLWULDATA)+strlen(temp_str) + real_length - 1, temp_Bcc, 5 ); // BCC + END 
    
    Ptr_at = (uint8 *)(Nb_Str_Tx);
    
    Const_String_Counter =  17; // Nb_Str_Tx[16]���� 0xF7�� ����

#ifdef FEATURE_LOG_SAVE
	Logo_Save(Ptr_at);
#endif

    UCA0IFG = 0;
    UCA0IE |=UCRXIE;  //   
    
    UCA0TXBUF = *Ptr_at++;
    UCA0IE |=  UCTXIE;
    Const_String_Counter--;
}
void String_fined(void)
{
  char *devide_ptr;
  uint16 length;
  uint16* srcptr;
  uint16* tgtptr;
  uint8 index;
  
  _index = 0;
  Data_index = 0;
  OK_index   = 0;
  
  memcpy(Nb_Str_Rx_temp,Nb_Str_Rx,Str_Counter_at);
  Nb_Str_Rx_temp[Str_Counter_at] = 0;    	
  Str_Counter_at = 0;  
  DataPtr_cnt = 0;
  //memset(Nb_Str_Rx, 0x00, sizeof(Nb_Str_Rx));    
  //    for(_index=0;_index < Str_Counter_at;_index++)
  //    {
  //      if(Nb_Str_Rx_temp[_index]==0x00)
  //        Nb_Str_Rx_temp[_index]=0x20;
  //    }    
#ifdef DATA_FORMAT_HEX
  devide_ptr = strstr(Nb_Str_Rx_temp,"AT+MLWDLDATA=")
  if(devide_ptr)
  {
     devide_ptr = strstr(Nb_Str_Rx_temp+13,",");
	 if(devide_ptr)
	 {
		 *devide_ptr = 0;
		 MLWDLDataLen = strtol(Nb_Str_Rx_temp+13, NULL, 10)
        Data_ptr[0] = devide_ptr+1;
		R_Staus.MLWDLdata =0;
      }
   }
#else
  devide_ptr = strtok(Nb_Str_Rx_temp, "\r\n");
  if(devide_ptr)
  {
    if( cus_strcmp ( devide_ptr, _OK) )  
      R_Staus.OK = 1; 
    else if( cus_strcmp ( devide_ptr, _ERROR)) 
      R_Staus.Error = 1;
    else if((cus_strncmp( devide_ptr ,"AT+MLWEVTIND=",13) ))
    {
      MLW_Event = *(devide_ptr+13)-'0';
	  if(MLW_Event == 1 || MLW_Event== 3 || MLW_Event== 6 || MLW_Event== 7) // 0: reg 1:dereg 3:overve 4:bootstrap 5:foata quary 6:download_quary 7:update_quary
	  	R_Staus.OK = 1;
    }
    else if((cus_strncmp( devide_ptr ,"+CEREG:",7)))
    {
      if( *(devide_ptr+8) == NULL )//|| ( *(Data_ptr[0]+9) == '5' ))
      {
        if( *(devide_ptr+7) == '1' )
          Creg_state = 1;
        else
          Creg_state = 0;
     	R_Staus.OK = 1;
        }          
      }
    else
    {
      R_Staus.Data = 1; 
      Data_ptr[DataPtr_cnt++]= devide_ptr; 
    }
  } 
  while(devide_ptr != NULL)
  {
    devide_ptr = strtok(NULL,"\r\n");
    if(devide_ptr)
    {
      if( cus_strcmp ( devide_ptr, _OK) )  
      R_Staus.OK = 1; 
      else if( cus_strcmp ( devide_ptr, _ERROR)) 
      R_Staus.Error = 1;
      else if((cus_strncmp( devide_ptr ,"AT+MLWEVTIND=",13) ))
      {
        MLW_Event = *(devide_ptr+13)-'0';
	  if(MLW_Event == 1 || MLW_Event== 3 || MLW_Event== 6 || MLW_Event== 7) // 0: reg 1:dereg 3:overve 4:bootstrap 5:foata quary 6:download_quary 7:update_quary
		R_Staus.OK = 1;
       }
      else if((cus_strncmp( devide_ptr ,"+CEREG:",7) ))
      {
        if( *(devide_ptr+8) == NULL )//|| ( *(Data_ptr[0]+9) == '5' ))
        {
          if( *(devide_ptr+7) == '1' )
            Creg_state = 1;
          else
            Creg_state = 0;
          R_Staus.OK = 1;					
        } 				 
      }
      else
      {
        R_Staus.Data = 1; 
        Data_ptr[DataPtr_cnt++]= devide_ptr; 
      }
    }
  }
#endif

}
int cus_strcmp(char *ptr1, const uint8  *ptr2)
{
    int i;
 	if(strlen((char*)ptr1) != strlen((char*)ptr2))
		return 0;	
    for(i=0; i< strlen((char*)ptr1); ++i){
        if(ptr1[i]!=ptr2[i])
            return 0;
    }
    return 1;
}

int cus_strncmp(char *ptr1, const uint8  *ptr2, int len)
{
    int i;
    for(i=0; i<len; ++i){
        if(ptr1[i]!=ptr2[i])
            return 0;
    }
    return 1;
}

uint8 Onebyte_char_2_NibbleHex(uint8 Onechar)
{
  uint8 Nibble;

  if( Onechar >='0' && Onechar <='9')
    Nibble = Onechar -'0';
  else if( Onechar >='A' && Onechar <='F')
    Nibble = Onechar -'A' + 10;
  else return 0;
  return Nibble;
}
void Mad_string_make_step1(uint8 *OneHex)
{
    Onehex.Char = *OneHex;
    Mad_str[0]  = Onehex.High_Nibble;    // 0x0f
    Mad_make( &Mad_str[0]); // 0x46;
    
    Mad_str[1]  = Onehex.Low_Nibble;
    Mad_make( &Mad_str[1]); // 0x46;
}
void Mad_string_make_step2(uint8  *Mptr1)
{
    Step1hex.Char = *Mptr1;
    *Mptr1 = Step1hex.High_Nibble;
     Mad_make( Mptr1);
     Mptr1++;
    *Mptr1 = Step1hex.Low_Nibble;
     Mad_make( Mptr1);
}
void Mad_make( uint8  *Mptr2 )
{  
  if(( *Mptr2 >= 0 )&( *Mptr2 <= 9 ))
  {
    *Mptr2 = *Mptr2 + 0x30;
  }
  else if((*Mptr2 >= 0x0A )&( *Mptr2 <= 0x0F ))
  {
     *Mptr2 = *Mptr2 + 0x40 - 9;
  } 
}
uint8 DeCoding_Mad_data( uint8 *mad)
{
  uint8 loop;
  uint8 *_Raw;
  
  union _raw Ori[4];
  union _raw Real_data;
  
  _Raw = (uint8 *)Ori;
  
  for(loop = 0 ; loop < 4 ; loop++)
  {
      *_Raw = *mad++;
      _Raw++;
  } 
  Ori[0].Raw_high_char   =  Ori[0].Raw_low_char ;
  
  loop = (Ori[0].all & 0xf0) + Ori[1].Raw_low_char;
  
  Real_data.Raw_high_char = Onebyte_char_2_NibbleHex(loop);
  
  Ori[2].Raw_high_char   =  Ori[2].Raw_low_char ;
  
  loop = (Ori[2].all & 0xf0) + Ori[3].Raw_low_char;   
  
  Real_data.Raw_low_char |= Onebyte_char_2_NibbleHex(loop);  
  
  return Real_data.all;
}
//const uint8  test_batt_init_rx[] = {"\r\nAT+MLWDLDATA=20,F70102233221200000023901610003170417B862\r\n"};
void Nuel_Data_com(void)
{ 
  uint8   temp;
  uint8   temp_num;
  uint8   X_bcc = 0;
  uint8   S_bcc = 0;
  uint8   *temp_ptr;
  uint16  loop=0;
  uint8   Rx_Bcc1;
  uint8   Rx_Bcc2;
  uint16  BCCTemp;   

  //if(Com1.bit.At_Rx_end)
  {
    Com1.bit.At_Rx_end = 0;    
    String_fined(); 
#if 0
    if(R_Staus.MLWDLdata)
    {
      if(*(Data_ptr[0]) == 0x06)
      {
			Nb_Retry_count = 0;
			TA3CCTL2	 = 0; 				 

			S10_MEM 	&=~ S10;
			S11_MEM 	&=~ S11;

			S1TO8_MEM |= S6;
			Guard.bit.Rx_Icon_On	 = 1;
			Rx_icon_on_Counter		 = 16;

			Com2.bit.Comm_Doning = 0;

			Com3.bit.DelayedPostDereg =1;
			DelayedPostDeregReqCounter = 0;
			
			Sequence_Counter = 3000; 	// Di-Reg �ؼ� �����.
      }
      else if(*(Data_ptr[0]) == 0x15)
	{
		Nb_Retry_count = 0;
		TA3CCTL2 	= 0;	
		Com2.bit.Data_tx_ready_Ok = 0;

		S10_MEM	 &=~ S10;
		S11_MEM	 &=~ S11;

		S1TO8_MEM |= S6;
		Guard.bit.Rx_Icon_On 	= 1;
		Rx_icon_on_Counter 		= 16; 				 

		Com2.bit.Comm_Doning = 0;

		Com3.bit.DelayedPostDereg =1;
		DelayedPostDeregReqCounter = 0;

		Sequence_Counter = 3000; 	// Di-Reg �ؼ� �����.
		if(T_data.Basic.Mem.Command == P_NORMAL_READ )
		{
			T_data.Basic.Mem.Command = 0;
			Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;					
		}		
	}
      else
      {
        MLWDLDataLen
        X_bcc = Data_ptr[0][0];
        S_bcc = Data_ptr[0][0];
      
        for(loop = 1 ;  loop< MLWDLDataLen-3 ; loop++) //except F7 BCC1 BCCC2 = 3
        {
          X_bcc ^= Data_ptr[0][loop];
          S_bcc += Data_ptr[0][loop];
          R_data.Raw[loop] = Data_ptr[0][loop];
        }
        Rx_Bcc1 = Data_ptr[0][MLWDLDataLen-2];
        Rx_Bcc2 = Data_ptr[0][MLWDLDataLen-1];
      }
      Com.bit.ID_ok = 1;
      for(loop = 0 ; loop < 8 ; loop++)
      {
        if(MeterID[loop] == R_data.Basic.Mem.MeterID[loop]);
        else 
        {
  	      Com.bit.ID_ok = 0; 
  	      break;
        }
      }
      if(( X_bcc == Rx_Bcc1) && ( S_bcc == Rx_Bcc2) && (Com.bit.ID_ok) )
      {
  		Nb_Retry_count = 0;
  		if(T_data.Basic.Mem.Command == P_NORMAL_READ )
  		{
	  		T_data.Basic.Mem.Command = 0;
	  		Memory.Trsmmi_Counter = Memory.Tx_temp_Counter; 					 
  		}
  		S1TO8_MEM |= S6;
  		Guard.bit.Rx_Icon_On	 = 1;
  		Rx_icon_on_Counter		 = 16;						
  		DPLC_Data_Process( ); 				 
      }
    }
#endif		
    if(R_Staus.Data)
    {
      if( cus_strncmp( Data_ptr[0] ,"AT+MLWDLDATA=",13)  )  // ���ٸ�...
      {
        if(cus_strncmp( Data_ptr[0]+13,"1,15",4)) // NACK
        {//AT+MLWDLDATA=1,15
          Nb_Retry_count = 0;
          TA3CCTL2   = 0;          
          S10_MEM   &=~ S10;
          S11_MEM   &=~ S11;
          
          S1TO8_MEM |= S6;
          Guard.bit.Rx_Icon_On   = 1;
          Rx_icon_on_Counter     = 16;
          
          Com2.bit.Comm_Doning = 0;

		Com3.bit.DelayedPostDereg =1;
		DelayedPostDeregReqCounter = 0;
				
         Sequence_Counter = 3000;   // Di-Reg �ؼ� �����.
        }
        else if(cus_strncmp( Data_ptr[0]+13,"1,06",4))//  ACK
        { // ACK�� Reset �뵵 , OK�� restart�� �뵵.       
          Nb_Retry_count = 0;
          TA3CCTL2   = 0;  
          
          S10_MEM   &=~ S10;
          S11_MEM   &=~ S11;
          
          S1TO8_MEM |= S6;
          Guard.bit.Rx_Icon_On   = 1;
          Rx_icon_on_Counter     = 16;          
          
          Com2.bit.Comm_Doning = 0;

		 Com3.bit.DelayedPostDereg =1;
		 DelayedPostDeregReqCounter = 0;

          Sequence_Counter = 3000;   // Di-Reg �ؼ� �����.
          
          if(T_data.Basic.Mem.Command == P_NORMAL_READ )
          {
            T_data.Basic.Mem.Command = 0;
            Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;          
          }         
        }
        else 
        {
         // if(Data_ptr[0][15] == ',')
         //	 Data_ptr[0][15]=0x00;   //
         // temp = strtol(Data_ptr[0]+13,NULL,10);
		  temp = (*(Data_ptr[0]+13) -'0')*10;
		  temp += *(Data_ptr[0]+14)-'0';
				
          temp_ptr = &(Data_ptr[0][16]);        
          {
            char temp_data;
            temp_num = *temp_ptr++;
            temp_data = (Onebyte_char_2_NibbleHex(temp_num) <<4);          
        
            temp_num = *temp_ptr++;
            temp_data |= Onebyte_char_2_NibbleHex(temp_num);
            
            X_bcc ^= temp_data;
            S_bcc += temp_data;
          }          
        
          for(loop = 0 ;  loop< temp-3 ; loop++) //F7 BCC1 BCCC2 = 3
          {
            temp_num = *temp_ptr++;
            R_data.Raw[loop] = Onebyte_char_2_NibbleHex(temp_num);
            
            R_data.Raw[loop] <<= 4;
            
            temp_num = *temp_ptr++;
            R_data.Raw[loop] |= Onebyte_char_2_NibbleHex(temp_num);
            
            X_bcc ^= R_data.Raw[loop];
            S_bcc += R_data.Raw[loop];
          } 

		temp_num = *temp_ptr++;
		Rx_Bcc1 = Onebyte_char_2_NibbleHex(temp_num);
		Rx_Bcc1 <<= 4;
		temp_num = *temp_ptr++;
		Rx_Bcc1 |= Onebyte_char_2_NibbleHex(temp_num);

		temp_num = *temp_ptr++;
		Rx_Bcc2 = Onebyte_char_2_NibbleHex(temp_num);
		Rx_Bcc2 <<= 4;
		temp_num = *temp_ptr++;
		Rx_Bcc2 |= Onebyte_char_2_NibbleHex(temp_num);

          Com.bit.ID_ok = 1;
          for(loop = 0 ; loop < 8 ; loop++)
          {
            if(MeterID[loop] == R_data.Basic.Mem.MeterID[loop]);
            else 
            {
              Com.bit.ID_ok = 0; 
              loop  = 9;
            }
          }        
          if(( X_bcc == Rx_Bcc1) && ( S_bcc == Rx_Bcc2) && (Com.bit.ID_ok) )
          {
            Nb_Retry_count = 0;
            if(T_data.Basic.Mem.Command == P_NORMAL_READ )
            {
              T_data.Basic.Mem.Command = 0;
              Memory.Trsmmi_Counter = Memory.Tx_temp_Counter;            
            }
            S1TO8_MEM |= S6;
            Guard.bit.Rx_Icon_On   = 1;
            Rx_icon_on_Counter     = 16;            
            DPLC_Data_Process( );          
          }
        }
      }
      else if(cus_strncmp( Data_ptr[0] ,"+CSQ:",5))
      {
        Com2.bit.CSQ_Ok              = 1;
        if( *Data_ptr[0]+6 >= 0x30)
        {
          BCCTemp = (((*(Data_ptr[0]+5) - '0')<<4) + (*(Data_ptr[0]+6) - '0'));                      
        }
        else BCCTemp = *(Data_ptr[0]+5) - '0';
        
        if( BCCTemp == 0x99 ) Rssi_Val = 0;
        else 
        {
          if(BCCTemp < 0x32)
          {
            Rssi_Val  = ((BCCTemp & 0xf0) >> 4) * 10 ;
            Rssi_Val += (BCCTemp & 0xf);
            Rssi_Val = (0xffff-113+1) + (Rssi_Val * 2); // ���� �׻� ���� �̴�.
            Rssi_Val = (0xffff - Rssi_Val) +1;          // ����� ��ȯ.
          }
          else Rssi_Val = 0x32; 
          
          asm_temp = Rssi_Val  ; // 
          Hex2Bcd32(asm_temp);
          Rssi_Val = asm_temp_12; // hex--> ��� BCD          
        }        
      }
    }
    else if(R_Staus.OK)
    { // OK�� restart�� �뵵.
      OK_Counter++;
      if(Nb_Retry_count > 2) TA3CCTL2 = 0 ;  // OK�� �޾����� ACK�� �� ���� ���̴�.
    }
    else;
    R_Staus.all = 0;
  //  memset(Nb_Str_Rx_temp, 0x00, 150);
  }
}





