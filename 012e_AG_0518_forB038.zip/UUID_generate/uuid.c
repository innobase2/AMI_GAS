#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "uuid.h"
#include "md5.h"

///* various forward declarations */
//static void format_uuid_v3or5(uuid_t *uuid, unsigned char hash[16], int v);

char convert_binary_to_ascii(char bin)
{
    char ascii;
    if(0<=bin && bin<=9)
        ascii=bin+'0';
    else
        ascii=bin+0x57;//0x41-0x0A=0x37 or 0x61-0A=0x57
    return ascii;
}

/* uuid_create_md5_from_name -- create a version 3 (MD5) UUID using a
 "name" from a "name space" */
void uuid_create_md5_from_name(uuid_t *uuid, void *name, int namelen) {
	MD5_CTX c;
	unsigned char hash[16];

	MD5Init(&c);
	MD5Update(&c, name, namelen);
	MD5Final(hash, &c);

	/* the hash is in network byte order at this point */
	format_uuid_v3or5(uuid, hash, 3);
}

void simple_uuid_create_md5_from_name(char *output, void *name, int namelen) {
    MD5_CTX c;
    unsigned char hash[16];

    MD5Init(&c);
    MD5Update(&c, name, namelen);
    MD5Final(hash, &c);

    strncpy(&output[0],"ASN_CSE-D-",10);
    output[10] = convert_binary_to_ascii(hash[0]>>4);
    output[11] = convert_binary_to_ascii(hash[0]&0x0F);
    output[12] = convert_binary_to_ascii(hash[1]>>4);
    output[13] = convert_binary_to_ascii(hash[1]&0x0F);
    output[14] = convert_binary_to_ascii(hash[2]>>4);
    output[15] = convert_binary_to_ascii(hash[13]&0x0F);
    output[16] = convert_binary_to_ascii(hash[14]>>4);
    output[17] = convert_binary_to_ascii(hash[14]&0x0F);
    output[18] = convert_binary_to_ascii(hash[15]>>4);
    output[19] = convert_binary_to_ascii(hash[15]&0x0F);
    strncpy(&output[20],"-GAMR",5);
}

#ifndef SIMPLE_UUID

/* various forward declarations */
void format_uuid_v3or5(uuid_t *uuid, unsigned char hash[16], int v);

/* format_uuid_v3or5 -- make a UUID from a (pseudo)random 128-bit
   number */
void format_uuid_v3or5(uuid_t *uuid, unsigned char hash[16], int v)
{
    /* convert UUID to local byte order */
    memcpy(uuid, hash, sizeof *uuid);
#ifdef _WIN32
    uuid->time_low = ntohl(uuid->time_low);
    uuid->time_mid = ntohs(uuid->time_mid);
    uuid->time_hi_and_version = ntohs(uuid->time_hi_and_version);
#else
    uuid->time_low = ( (uuid->time_low  >> 24) & 0x000000FF ) | ( (uuid->time_low >> 8) & 0x0000FF00 ) | ( (uuid->time_low << 8) & 0x00FF0000 ) | ( (uuid->time_low << 24) & 0xFF000000);
    uuid->time_mid = ( (uuid->time_mid >> 8) & 0x00FF) | ( (uuid->time_mid << 8) & 0xFF00 );
    uuid->time_hi_and_version = ( (uuid->time_hi_and_version >> 8) & 0x00FF) | ( (uuid->time_hi_and_version << 8) & 0xFF00 );
#endif

    /* put in the variant and version bits */
    uuid->time_hi_and_version &= 0x0FFF;
    uuid->time_hi_and_version |= (v << 12);
    uuid->clock_seq_hi_and_reserved &= 0x3F;
    uuid->clock_seq_hi_and_reserved |= 0x80;
}
#endif
