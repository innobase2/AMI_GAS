#include <msp430.h>
#include "uuid.h"

#define enable()    __bis_SR_register(GIE)

void Timer0Handler(void);
volatile unsigned int m_TimeTick_1ms = 0;
int start_time = 0;
int end_time = 0;
int total_time = 0;
int i, j = 0;

void Timer0Handler(void)
{
    m_TimeTick_1ms++;
}

void Timer0init(void)
{
    TA0CCTL0 = CCIE;
    TA0CTL = TASSEL_2 + MC_2;
}

int main(void)
{
  char *pData;
  WDTCTL = WDTPW | WDTHOLD; // Stop watchdog timer

  // Startup clock system with max DCO setting ~8MHz
  CSCTL0_H = CSKEY >> 8;                    // Unlock clock registers
  CSCTL1 = DCOFSEL_0 | DCORSEL;             // Set DCO to 8MHz
  CSCTL2 = SELA__VLOCLK | SELS__DCOCLK | SELM__DCOCLK;
  CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1;     // Set all dividers
  CSCTL0_H = 0;                             // Lock CS registers


  Timer0init();
  enable();

  char uuid[26];
  while(1)
  {
    //  if (end_time == 0)
      {
          start_time = m_TimeTick_1ms;

         // uuid_create_md5_from_name(&uu.u, "010333355558982067512001135842F", 31);
          simple_uuid_create_md5_from_name(uuid, "010333355558982067512001135842F", 31);
       //   printf("uuid_create_md5_from_name(): "); puid(u);
          end_time = m_TimeTick_1ms;
          //uu.u = u;
          total_time = end_time - start_time;
      }
  }

}

//Timer A0 intterupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A(void)
{
    Timer0Handler();
    TA0CCR0 += 1000;
}

