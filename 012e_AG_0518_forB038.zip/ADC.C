#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"

void Init_ADC(void);
void Battery_Monitor(void);

// 330k : 100k,  V = 3 * 10 / 33; max 0.0909 V 

void Battery_Monitor(void)
{
  if(Battery.ADC_Start)
  {
    Battery.ADC_Start = 0;
    Init_ADC();
    //SET_LOW_BATT_1_LOAD
    Battery.Counter = 0;
    Battery.ADC_en = 1;
  }
  else ;
  if(Battery.ADC_en)
  {
      SET_LOW_BATT_1_EN 
      //Init_ADC();
      //Battery.Counter = 0;
      Battery.ADC_Doing = 1;
  }
  else ;
  if(Battery.ADC_on)
  {
      Battery.ADC_on = 0;
      ADC12CTL0 |= ADC12ENC | ADC12SC;    // Start sampling/conversion
  }
  else ;
  if(Battery.ADC_Done)
  { 
        Battery.ADC_Done  = 0;
        Battery.ADC_Doing = 0;
        CLR_LOW_BATT_1_LOAD;
        CLR_LOW_BATT_1_EN;
        ADC12CTL0 &=~ADC12ENC;
        ADC12CTL0 &=~ADC12ON; 
        REFCTL0    = 0;
        // V = ADC_count * 1.2 * 4.3 / 4095
        //   = ADC_count * 12 * 43 / 4095
        Battery._1mV = ((uint32)Battery.Raw_Counter * 1200 ) >> 12;
        if(LED_error.bit.ADC_on_off)
        {
//            Battery.ADC_loop = 1;
            LED_error.bit.ADC_display = 1;
        }        
  } 
}
void Init_ADC(void)
{
    // By default, REFMSTR=1 => REFCTL is used to configure the internal reference
    while(REFCTL0 & REFGENBUSY);              // If ref generator busy, WAIT
    REFCTL0 |= REFVSEL_0 | REFON;             // Select internal ref = 1.2V
 
                                            // Internal Reference ON
    LOW_BATT_ADC_SEL                        // P9.6/A14/C14
    // Configure ADC12
    ADC12CTL0 = ADC12SHT0_2 | ADC12ON;      // Sampling time, S&H=16, ADC12 on
    ADC12CTL1 = ADC12SHP;                   // Use sampling timer
    ADC12CTL2 |= ADC12RES_2;                // 12-bit conversion results
    ADC12MCTL0 |= ADC12INCH_14 | ADC12VRSEL_1; // A14 ADC input select; Vref=1.2V
    ADC12IER0 |= ADC12IE0;                  // Enable ADC conv complete interrupt
    REFCTL0 = 0;                            // off LDO
}

#pragma vector = ADC12_VECTOR
__interrupt void ADC12_ISR(void)
{
  SET_TEST3
    switch(__even_in_range(ADC12IV, ADC12IV_ADC12RDYIFG))
    {
        case ADC12IV_NONE:        break;    // Vector  0:  No interrupt
        case ADC12IV_ADC12OVIFG:  break;    // Vector  2:  ADC12MEMx Overflow
        case ADC12IV_ADC12TOVIFG: break;    // Vector  4:  Conversion time overflow
        case ADC12IV_ADC12HIIFG:  break;    // Vector  6:  ADC12BHI
        case ADC12IV_ADC12LOIFG:  break;    // Vector  8:  ADC12BLO
        case ADC12IV_ADC12INIFG:  break;    // Vector 10:  ADC12BIN
        case ADC12IV_ADC12IFG0:             // Vector 12:  ADC12MEM0 Interrupt
          
            Battery.Raw_Counter = ADC12MEM0;            
            Battery.ADC_Done = 1; 
            REFCTL0 = 0;;                   // Select internal ref = 0V            
            __bic_SR_register_on_exit(LPM3_bits);  
            break;
        case ADC12IV_ADC12IFG1:   break;    // Vector 14:  ADC12MEM1
        case ADC12IV_ADC12IFG2:   break;    // Vector 16:  ADC12MEM2
        case ADC12IV_ADC12IFG3:   break;    // Vector 18:  ADC12MEM3
        case ADC12IV_ADC12IFG4:   break;    // Vector 20:  ADC12MEM4
        case ADC12IV_ADC12IFG5:   break;    // Vector 22:  ADC12MEM5
        case ADC12IV_ADC12IFG6:   break;    // Vector 24:  ADC12MEM6
        case ADC12IV_ADC12IFG7:   break;    // Vector 26:  ADC12MEM7
        case ADC12IV_ADC12IFG8:   break;    // Vector 28:  ADC12MEM8
        case ADC12IV_ADC12IFG9:   break;    // Vector 30:  ADC12MEM9
        case ADC12IV_ADC12IFG10:  break;    // Vector 32:  ADC12MEM10
        case ADC12IV_ADC12IFG11:  break;    // Vector 34:  ADC12MEM11
        case ADC12IV_ADC12IFG12:  break;    // Vector 36:  ADC12MEM12
        case ADC12IV_ADC12IFG13:  break;    // Vector 38:  ADC12MEM13
        case ADC12IV_ADC12IFG14:  break;    // Vector 40:  ADC12MEM14
        case ADC12IV_ADC12IFG15:  break;    // Vector 42:  ADC12MEM15
        case ADC12IV_ADC12IFG16:  break;    // Vector 44:  ADC12MEM16
        case ADC12IV_ADC12IFG17:  break;    // Vector 46:  ADC12MEM17
        case ADC12IV_ADC12IFG18:  break;    // Vector 48:  ADC12MEM18
        case ADC12IV_ADC12IFG19:  break;    // Vector 50:  ADC12MEM19
        case ADC12IV_ADC12IFG20:  break;    // Vector 52:  ADC12MEM20
        case ADC12IV_ADC12IFG21:  break;    // Vector 54:  ADC12MEM21
        case ADC12IV_ADC12IFG22:  break;    // Vector 56:  ADC12MEM22
        case ADC12IV_ADC12IFG23:  break;    // Vector 58:  ADC12MEM23
        case ADC12IV_ADC12IFG24:  break;    // Vector 60:  ADC12MEM24
        case ADC12IV_ADC12IFG25:  break;    // Vector 62:  ADC12MEM25
        case ADC12IV_ADC12IFG26:  break;    // Vector 64:  ADC12MEM26
        case ADC12IV_ADC12IFG27:  break;    // Vector 66:  ADC12MEM27
        case ADC12IV_ADC12IFG28:  break;    // Vector 68:  ADC12MEM28
        case ADC12IV_ADC12IFG29:  break;    // Vector 70:  ADC12MEM29
        case ADC12IV_ADC12IFG30:  break;    // Vector 72:  ADC12MEM30
        case ADC12IV_ADC12IFG31:  break;    // Vector 74:  ADC12MEM31
        case ADC12IV_ADC12RDYIFG: break;    // Vector 76:  ADC12RDY
        default: break;
    }
  CLR_TEST3
}
