#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"
#include "Meter_Unit.h"

extern void GPIO_Setting(void);
extern void Clock_Setting(void);
extern void RTC_Init(void);
extern void Lcd_init(void);
extern void Lcd_test(void);
extern void Lcd_Display(void);
extern void Timer_Init(void);
extern void Init_Uart(void);
extern void Inc_meter_value(void);
extern void Init_meter_valiable(void);
extern void Init_I2C_Pressure(void);
extern void Communication(void);
extern void Init_ADC(void);
extern void Battery_Monitor(void);
extern void DPLC_Rx_Process(void);
extern void FRAMWrite(void);
//extern void Meter_Modify(void);
extern void Hex2Bcd32(uint32);
extern void Save_Mem_Data(void);
extern void Tx_Normal(void);
extern void Retutn_SW(void);
extern void Test_SJ_Illegal(void);
extern void ADC_Display(void);
extern void COM_request(void);
extern void NBiot_Module_Rx_while(void);
extern void NBiot_Module_Tx_while(void);
extern void Nb_tx_AT_MLWULDATA( uint16 real_length );
extern void Nb_Tx_ComProcess(const uint8 *Tx_temp_ptr);
extern const uint8 _AT_CSQ[];

void Buzzer_Start(void);
void Buzzer_Stop(void);
uint16 Bcd2Hex( uint32 );
extern void Pressure_Sensor(void );
extern inline void Make_same_Frame(uint16 Count,uint8 command);
extern void Make_Emc_data(void);
extern void Find_Last_Mem(void);
extern void NBiot_Module_Init(void);
extern void Nuel_Data_com(void);

//--------- FTM ----------
extern void Factory_Test_Mode(void);
//-----------------------
void TI_pre_setting(void);
void TI_After_setting(void);

void TI_pre_setting(void)
{
  ///1. PJSEL
    PJDIR |= (BIT4+BIT5);
    PJOUT &= ~(BIT4+BIT5);//PJ.4.5 OUTPUT LOW
    PJSEL0 |= BIT4;
    PJSEL1 &= ~BIT4;// for LFXIN crystal mode PJ.5 DON'T CARE
    PJREN =0;

    PJDIR |= (BIT6+BIT7);
    PJOUT &= ~(BIT6+BIT7);//PJ.6.7 OUTPUT LOW
    PJSEL0 &= ~(BIT6+BIT7);
    PJSEL1 &= ~(BIT6+BIT7);

    PJSEL0 &= ~(BIT0+BIT1+BIT2+BIT3);
    PJSEL1 &= ~(BIT0+BIT1+BIT2+BIT3);
    PJDIR |= (BIT0+BIT1+BIT2+BIT3);
    PJOUT &= ~(BIT0+BIT1+BIT2+BIT3);
    ////////UNCONFIGURED PINS
    P1DIR |=(BIT6+BIT7);
    P1OUT &=~(BIT6+BIT7);
    P1SEL0 &= ~(BIT6+BIT7);
    P1SEL1 &= ~(BIT6+BIT7);
    P1REN &= ~(BIT6+BIT7);

    P3DIR |=(BIT1+BIT2);
    P3OUT &=~(BIT1+BIT2);
    P3SEL0 &= ~(BIT1+BIT2);
    P3SEL1 &= ~(BIT1+BIT2);
    P3REN &= ~(BIT1+BIT2);
    ////NON-EXIST PINS
    P10DIR = 0XFF;
    P10OUT = 0;
    P10REN = 0;
    P10SEL0 = 0;
    P10SEL1 = 0;
    P7DIR |= BIT4;
    P7OUT &= ~BIT4;
    P7REN &= ~BIT4;
    P7SEL0 &= ~BIT4;
    P7SEL1 &= ~BIT4;

    ///MUX ONLY PINS P1.4,5 P2.0,1,4,5 P4014567 p7.0123 5,6 P3.4,5 P9.6
    P6DIR = 0XFF;
    P6OUT = 0;
    P6REN = 0;
    P6SEL0 = 0;
    P6SEL1 = 0;

    P1DIR |= (BIT4+BIT5);
    P1OUT &= ~(BIT4+BIT5);
    P1REN &= ~(BIT4+BIT5);
    P1SEL0 &= ~(BIT4+BIT5);
    P1SEL1 &= ~(BIT4+BIT5);

    P2DIR |= (BIT0+BIT1+BIT4+BIT5);
    P2OUT &= ~(BIT0+BIT1+BIT4+BIT5);
    P2REN &= ~(BIT0+BIT1+BIT4+BIT5);
    P2SEL0 &= ~(BIT0+BIT1+BIT4+BIT5);
    P2SEL1 &= ~(BIT0+BIT1+BIT4+BIT5);

    P3DIR |= (BIT4+BIT5);
    P3OUT &= ~(BIT4+BIT5);
    P3REN &= ~(BIT4+BIT5);
    P3SEL0 &= ~(BIT4+BIT5);
    P3SEL1 &= ~(BIT4+BIT5);

    P4DIR |= (BIT0+BIT1+BIT4+BIT5+BIT6+BIT7);
    P4OUT &= ~(BIT0+BIT1+BIT4+BIT5+BIT6+BIT7);
    P4REN &= ~(BIT0+BIT1+BIT4+BIT5+BIT6+BIT7);
    P4SEL0 &= ~(BIT0+BIT1+BIT4+BIT5+BIT6+BIT7);
    P4SEL1 &= ~(BIT0+BIT1+BIT4+BIT5+BIT6+BIT7);

    P7DIR |= (BIT0+BIT1+BIT2+BIT3+BIT5+BIT6);
    P7OUT &= ~(BIT0+BIT1+BIT2+BIT3+BIT5+BIT6);
    P7REN &= ~(BIT0+BIT1+BIT2+BIT3+BIT5+BIT6);
    P7SEL0 &= ~(BIT0+BIT1+BIT2+BIT3+BIT5+BIT6);
    P7SEL1 &= ~(BIT0+BIT1+BIT2+BIT3+BIT5+BIT6);

    P9DIR |= (BIT6);
    P9OUT &= ~(BIT6);
    P9REN &= ~(BIT6);
    P9SEL0 &= ~(BIT6);
    P9SEL1 &= ~(BIT6);

    ///////////////REN CLEAR

    P1REN = 0;
    P2REN = 0;
    P3REN = 0;
    P4REN = 0;
    P5REN = 0;
    P6REN = 0;
    P7REN = 0;
    P8REN = 0;
    P9REN = 0;
    P1REN = 0;
    PJREN = 0;
    ////////////IE CLEAR
    P1IE =0;
    P2IE =0;
    P3IE =0;
    P4IE =0;

    ///////////REST OF PINS
    P2DIR &= ~(BIT6);
    P2OUT &= ~(BIT6);
    P2REN &= ~(BIT6);
    P2SEL0 &= ~(BIT6);
    P2SEL1 &= ~(BIT6);

    P7DIR |= (BIT7);
    P7OUT &= ~(BIT7);
    P7REN &= ~(BIT7);
    P7SEL0 &= ~(BIT7);
    P7SEL1 &= ~(BIT7);

    P2DIR |= (BIT2);
    P2OUT &= ~(BIT2);
    P2REN &= ~(BIT2);
    P2SEL0 &= ~(BIT2);
    P2SEL1 &= ~(BIT2);

    P1DIR &= ~(BIT3);
    P1OUT &= ~(BIT3);
    P1REN &= ~(BIT3);
    P1SEL0 &= ~(BIT3);
    P1SEL1 &= ~(BIT3);

    P1DIR |= (BIT0+BIT1+BIT2);
    P1OUT &= ~(BIT0+BIT1+BIT2);
    P1REN &= ~(BIT0+BIT1+BIT2);
    P1SEL0 &= ~(BIT0+BIT1+BIT2);
    P1SEL1 &= ~(BIT0+BIT1+BIT2);

    P9DIR |= (BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT7);
    P9OUT &= ~(BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT7);
    P9REN &= ~(BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT7);
    P9SEL0 &= ~(BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT7);
    P9SEL1 &= ~(BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT7);

    P4DIR &= ~(BIT2);
    P4OUT &= ~(BIT2);
    P4REN &= ~(BIT2);
    P4SEL0 &= ~(BIT2);
    P4SEL1 &= ~(BIT2);
}
void TI_After_setting(void)
{
    P4DIR |= (BIT3);
    P4OUT &= ~(BIT3);
//    P4OUT |= (BIT3);
    P4REN &= ~(BIT3);
    P4SEL0 &= ~(BIT3);
    P4SEL1 &= ~(BIT3);
    P4IE &= ~(BIT3);

    P2DIR |= (BIT3+BIT7);
    P2OUT &= ~(BIT3+BIT7);
//    P2OUT |= (BIT3+BIT7);
    P2REN &= ~(BIT3+BIT7);
    P2SEL0 &= ~(BIT3+BIT7);
    P2SEL1 &= ~(BIT3+BIT7);
    P2IE &= ~(BIT3+BIT7);

    P3DIR |= (BIT3+BIT7);
    P3OUT &= ~(BIT3+BIT7);
//    P3OUT |= (BIT3+BIT7);
    P3REN &= ~(BIT3+BIT7);
    P3SEL0 &= ~(BIT3+BIT7);
    P3SEL1 &= ~(BIT3+BIT7);
    P3IE &= ~(BIT3+BIT7);

    ///////////  
}

void main(void)
{

    WDTCTL = WDTPW | WDTHOLD;                 // Stop Watchdog
//  WDTCTL = WDTPW | WDTTMSEL | WDTSSEL_2 | WDTIS_5; // VLOCLK, ~1s interrupts
//  SFRIE1 |= WDTIE;                          // Enable WDT interrupt
    //__delay_cycles(5000000); 
    TI_pre_setting();
    GPIO_Setting();  // Configure GPIO
    TI_After_setting();
    
    Clock_Setting(); // Clock System Setup
    uint8 led_cnt;

    for(led_cnt = 0; led_cnt < 5; led_cnt++)
    {
      XOR_LED;
      __delay_cycles(1000000);
    }
    CLR_LED;
    
//    GPIO_Setting();  // Configure GPIO
    SET_MODEM_RESET
    //Clock_Setting(); // Clock System Setup  ---> ���� �ʿ� �ڼ��� ����.
    RTC_Init();
    Lcd_init();   
    Lcd_test();
    Timer_Init();
    Init_Uart();
    Init_meter_valiable();
    //Init_I2C_Pressure(); 
    Init_ADC();
    Battery.ADC_Start = 1;
    Find_Last_Mem();

    _EINT(); 
    
    Guard.bit.RF_Module = 0;
    RF_Module_Counter   = 0;
    
    Com1.bit.Nb_Need_Step2 =0; // 1 page init�� ���������� ������ 1�� �ƴϸ� 0,
    NBiot_Module_Init(); // 30��
    //Com1.bit.At_Init_done = 1;/////////////////// for test
    
    Buzzer_Sec_counter = 1; 
    Buzzer_Start(); 
    
    Power_On_Counter   = 0 ;
    Guard.bit.Power_ON = 1 ;
    
    Stflag.bit.Save_mem = 1;    
    Save_Mem_Data(); 
    
    Com1.bit.Com_Ready = 0 ;// ���� data�� ���� �� ���� .. module �غ� �ʵ�.
    Reboot_Counter = 0;
    
    if(Com2.bit.Module_Fail)
    {
      S10_MEM   &=~ S10;
      S11_MEM   &=~ S11;
    }
    
      while(1)
      {
//--------- FTM ----------        
        if(FTM_mode_flag == 1)    // Factory_Memory.FTM_mode_flag�� 1�̸� Factory Test Mode ���� ��
        {
          //__low_power_mode_0();
          Fatory_Test_Mode();
        }
//-----------------------
        else
         {
          if((Stflag.bit.Buzzer_Doing) || (Battery.ADC_Doing) || (Stflag.bit.SMclk_Active) )
            __low_power_mode_0();
          else
          {    
            __low_power_mode_3();            
          }      
          SET_TEST3
//          if(Com2.bit.Rssi_Interval_SET)
//          {
//            Com2.bit.Rssi_Interval_SET = 0;
//            Nb_Tx_ComProcess(_AT_CSQ );
//          }
          Inc_meter_value();
          //Pressure_Sensor();
          Battery_Monitor();
          Lcd_Display();
          DPLC_Rx_Process();
          Save_Mem_Data();
          Tx_Normal();
          Retutn_SW();
          Test_SJ_Illegal();                      // ����ȭ(�Ƴ��α� + �������) �������˿� �跮�� ���� ǥ�� - ������� ����;
          
          COM_request();                          // ����� �ʿ��ϴ�, DPLC�� ���� ���� ���, R.F�� ���� Ȯ��.

          if(Com2.bit.Module_Fail  == 0)
          {            
            if(Com1.bit.Nb_Need_Step2)            // �ʱ�ȭ step2
            {
              NBiot_Module_Rx_while();
              NBiot_Module_Tx_while();
            }
            else if(Com2.bit.SendingDataSequence) // sensding sequence �غ� �Ϸ� Ȯ��.
            {
              NBiot_Module_Rx_while();
              NBiot_Module_Tx_while();            
            }
            else if(( Com2.bit.Data_tx_ready_Ok )&&(Com2.bit.CSQ_Ok == 1)) // �ʱ�ȭ setp1,step2,�׸��� sensding data�� �� �� �ִٴ� �غ� ������ ������ �Ѵ�. 
            {
              Com2.bit.Data_tx_ready_Ok = 0;
              
              //S1TO8_MEM |= S6;
              S10_MEM   |= S10;
              S11_MEM   |= S11;
              
              Guard.bit.Tx_Icon_On   = 1;
              Tx_icon_on_Counter     = 16;        // max 7      
              Nb_tx_AT_MLWULDATA(T_data_number + 15 ); 
            }
            else;
            
            if((Com1.bit.Nb_Need_Step2 == 0) &&(Com2.bit.SendingDataSequence == 0) && Com1.bit.At_Rx_end)
            {
              Nuel_Data_com(); //
            }
            
            if( Com2.bit.Reboot )
            {
              Com2.bit.Reboot                 = 0;
              //if(( AT_case  != _AT_NRB_NUM ) && ( HW_Reboot_counter < 2 ))  // NRB���� OK�� �� ������ ���� ����..���� �ݺ� �Ѵ�.
              if(( HW_Reboot_counter < 2 ))  // NRB���� OK�� �� ������ ���� ����..���� �ݺ� �Ѵ�.
              {
                Com2.bit.Watting_COM            = 0;
                Com2.bit.Module_Reinit          = 1;         
                CLR_MODEM_RESET
                ReInit_counter = 0;
              }
              Com2.bit.Data_tx_ready_Ok       = 0;//
              Com2.bit.SendingDataSequence    = 0;//
            }
          }
          else Nuel_Data_com(); //;          
          CLR_TEST3
          }  
        __no_operation();                        // For debugger
      }

}

void Buzzer_Start(void)
{
  Stflag.bit.Buzzer_Doing = 1;
  TA2CCR0 = TA2R + 50;
  TA2CCTL0 = CCIE;
  
  TA0CCR1 = TA0R + (32768>>1); // 0.5��
  TA0CCTL1 = CCIE;
  Stflag.bit.Buzzer_Set = 1;
  Buzzer_05s_counter = 0;    
}

void Buzzer_Stop(void)
{

    CLR_BUZZER;
    Stflag.bit.Buzzer_Doing = 0;
    TA2CCTL0 = 0;
    TA0CCTL1 = 0;
}

uint16 Bcd2Hex( uint32 bcd )
{
  uint16 Hex_temp = 0;

  Hex_temp += (bcd & 0x0f);
  bcd >>=4;
  Hex_temp += (bcd & 0x0f) * 10;
  bcd >>=4;
  Hex_temp += (bcd & 0x0f) * 100;
  bcd >>=4;  
  Hex_temp += (bcd & 0x0f) * 1000;
  bcd >>=4;
  Hex_temp += (bcd & 0x0f) * 10000;  
  
  return Hex_temp;  // max 65535
}

// Watchdog Timer interrupt service routine
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=WDT_VECTOR
__interrupt void WDT_ISR(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(WDT_VECTOR))) WDT_ISR (void)
#else
#error Compiler not supported!
#endif
{
  P1OUT ^= BIT0;                            // Toggle P1.0 (LED)
}
