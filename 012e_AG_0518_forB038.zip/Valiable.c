#include "Struct.h"
#include "Lcd.h"
#include "Protocol.h"

union rtC                       Rtc;
union def_st_flag               Stflag;
union def_Comm_flag             Com;
union def_Comm_flag1            Com1;
union def_Comm_flag2            Com2;
union def_Comm_flag3            Com3;
union def_st_leak_test_flag     leak;
union def_st_port_test_flag     Botton;
union def_lcd_error_flag        LED_error;
union def_guard_flag            Guard;

//st_mem                  Stack;
st_mem_Pressure         Pressure ;
st_mem_ADC              Battery;
st_mem_memory           Memory;

const char  LCD_Tab[11]=
{
CHAR_0,// displays "0"
CHAR_1,// displays "1"
CHAR_2,// displays "2"
CHAR_3,// displays "3"
CHAR_4,// displays "4"
CHAR_5,// displays "5"
CHAR_6,// displays "6"
CHAR_7,// displays "7"
CHAR_8,// displays "8"
CHAR_9,// displays "9"
GG     // " - "
 
};

const char  LCD_Tab_Center[14]=
{
CHAR1_0,// displays "0"
CHAR1_1,// displays "1"
CHAR1_2,// displays "2"
CHAR1_3,// displays "3"
CHAR1_4,// displays "4"
CHAR1_5,// displays "5"
CHAR1_6,// displays "6"
CHAR1_7,// displays "7"
CHAR1_8,// displays "8"
CHAR1_9,// displays "9"
CHAR1_A,// " A "
CHAR1_b,// " b "
CHAR1_n,// " n "
CHAR1_r // " r "
};

const char  LCD_ICON[14]=
{
0,
ICON_S1,// displays "����"
ICON_S2,// displays "���"
ICON_S3,// displays "����"
ICON_S4,// displays "�ܺ�"
ICON_S5,// displays "�з�"
ICON_S6,// displays "���"
ICON_S7,// displays "����"
ICON_S8,// displays "�ð�"
ICON_S9,// displays "����"
ICON_S10,// displays "<<>>"
ICON_S11 // displays "ant"
};

const char IOCN_MAP[11] =
{
16,16,16,16,16,16,16,16,1,6,12  
};
  
const char  LCD_ROLL[7]=
{
0,
ROLL_A,// displays "����"
ROLL_B,// displays "���"
ROLL_C,// displays "����"
ROLL_D,// displays "�ܺ�"
ROLL_E,// displays "�з�"
ROLL_F,// displays "���"
};
uint8           Roll;

uint32          Test_0;
uint16          test;

uint8           Bcc1_Xor;
uint8           Bcc2_Sum;
uint8           Buzzer_05s_counter;
uint8           Buzzer_Sec_counter;

uint16          PosEdge_Counter;
uint16          NegEdge_Counter;
uint16          Capture_D_Counter;
uint8           Input_Pulse_Counter;

uint16          Dec_Counter_H;  // 10t  unit  9999 * 10    =  99990 m3
uint16          Dec_Counter_L;  // 1L   unit  9999 L       =  9.999 m3

uint16          Hex_Counter_H;  //
uint16          Hex_Counter_L;  // 10cc unit

uint32          Hex_Counter_025; // 250cc unit max 9999,9999 * 4 = < 32bit Num 

uint16          Instant_Q;
uint16          Sum_Q_Per10Sec;

uint8           Sec5_counter;
uint8           Sec10_counter;
uint8           Sec20_counter;

uint8           Min60_counter;

uint16          LowBatteryHour_counter;

uint16          U250_counter;

uint16          St2_Leak_Old_C;
uint16          St2_Leak_Min_counter;

uint16          St3_Over_Old_Q3_1;
uint16          St3_Over_Q3_1_counter;

uint16          St5_Unused;
uint16          St5_Unused_counter;

uint16          St4_Unuse_1min_counter;

uint16          Dec_Pulse_Counter;

uint16          OverQ3_Per_5sec_Value;
uint16          LeakQ3_Per_1min_Value;
uint16          LeakQ1_Per_1min_Value;
uint16          Leak_Per_1min_Counter;

uint8           Button_temp;
uint8           StartTimetemp ;
//uint16          CurrentMInStep[10];

uint8           Relese_Unused_counter;
uint8           Relese_Unused_test_on;
uint8           Relese_Unused_test_sec;

uint16          P_test_32hz_counter ;
uint16          Pressure_32hz_counter ;

uint16          Save_Counter_Normal_Data; // 20�� �ϳ��� Pack���� ���� �Ѵ�.
                                          // 1024 * 10 /20 = 512 ������ ��ȯ

uint16          Guard_Counter0;
uint16          Guard_Counter1;
uint16          Guard_Counter2;
uint16          Guard_Counter3;
uint16          Guard_Counter4;
uint16          Guard_Counter5;
uint16          Guard_Counter6;

uint8           Under_20L;
uint8           Min3_counter;
uint16          Min3_Per_Pulse;
uint16          Min3_Old_Pulse;
uint16          Under_20L_Current;

//��ſ� ���Ǵ� ������ ��Ž� �����Ǵ� ������

union sT1 St1;
union sT2 St2;
union sT3 St3;

union  Rx_Frame R_data;
union  Tx_Frame T_data;

//uint8  MeterID[8];
uint8  DeviceID = 0x39 ;
uint16 TX_counter;
uint8  *TX_A1_pointer;
uint16 *U16_ptr;
uint8  *U8_ptr;

uint16 Temp_Lenght;
uint16 Data_Lenght;
uint8  XOR_Bcc1;
uint8  SUM_Bcc2;
uint8  R_Bcc1;
uint8  R_Bcc2;

uint8  Defult_retry_count = 2;
uint8  Battery_Set_yy ;
uint8  Battery_Set_mm ;
uint8  Battery_Set_dd ;

uint16 Com_inertval_MIN = 360 ;
uint16 Com_inertval_MIN_Counter;
uint16 Read_Save_Interval_MIN = 60;
uint16 Read_Save_Interval_MIN_Counter;
uint16 Pressure_inteval_MIN = 10 ;
uint16 Pressure_inteval_MIN_Counter;
uint16 Battery_inteval_MIN  = 60 ;
uint16 Com_Battery_MIN_Counter;
uint16 Rssi_Val;
uint8  Meter_Jong;
uint8  Meter_Type;

uint8  EMC_command;
uint8  Valve_working_Sec;

uint16 LCD_Init_Counter;



reQ_METER_SETUP_W Save;

reP_NORMAL_READ   Woking;

uint16      asm_temp;   // only asm
uint16      asm_temp_15;
uint16      asm_temp_14;
uint16      asm_temp_13;
uint16      asm_temp_12;  
//---------------

uint16 toggle_counter_0_5;

uint16 ADC_test_32hz_counter;

uint16 Length_temp_Normal;

uint8   AT_case;
uint8   AT_Sub_case;
uint8   *Ptr_at;
uint16  Str_Counter_at; 
uint8    Nb_Str_Rx[150]; 
uint8    Nb_Str_Rx_temp[150];
//char    arg[3][64];
uint8   _index;
uint8   Nb_Retry_count;   
uint8   Nb_old_AT_case; 
uint8   Char_Length;
uint8   Char_Order;

uint16  MLWDLDataLen; 

/* Place following variables in segment NBIOT_RAM" */

#pragma default_variable_attributes = @ "NBIOT_RAM"
#pragma SET_DATA_SECTION (".nbiot_ram")
// 1024 ram �Ҵ�
char Nb_Str_Tx[450]; // 
char Nb_CGSN[16];     //
char Nb_CIMI[16];  
char Nb_MUICCIDD[21];  
char CIMI_Temp[12];
char MUICCIDD_Temp[21];
uint8  MeterID[8];
uint8 Cgsn;
  uint8 Data_index               ;
  uint8 OK_index                 ; 
  
union _oneHex Onehex;
union _oneHex Step1hex;
uint8  Mad_str[4];  
uint8  Mad_counter;
uint8  Const_String_Counter;
uint16 CharEnd_counter;
uint16 MadNum; 
char TX_data_Temp[50];
uint8  CTN_temp[11];  


/* Stop placing variables into NBIOT_RAM */
#pragma SET_DATA_SECTION ("")  // for ccs compiler
#pragma default_variable_attributes =


uint8 Lcd_Off_Counter;
uint8 Half_Detect;
uint16 Power_On_Counter;
uint16 RF_Module_Counter;
uint16 Cop_watting_Counter;
uint8  Creg_state;
uint16 T_data_number;
uint16 Creg1_5_watting_Counter;
uint8  Reboot_Counter;
uint16 Sequence_Counter;
uint8  HW_Reboot_counter;
uint8  Reset_Reboot_Day;
uint16  ReInit_counter;
uint8  RetrySec_counter;
uint8  OK_Counter;  // ok�� �޾��� ��� ����.
uint8  Tx_icon_on_Counter;  // ok�� �޾��� ��� ����.
uint8  Rx_icon_on_Counter;  // ok�� �޾��� ��� ����.
uint8  Illegal_Counter;     // �ڼ��� ���� �Ǿ��� ��� ����.. 
uint8  Uart_counter;
uint16 Return_Ilegal_counter;
uint8  RegRetry;
uint8  MLW_Event =1;  //�ʱ� ���� deregi   // 0: reg 1:dereg 3:overve 4:bootstrap 5:foata quary 6:download_quary 7:update_quary
uint16  WattingReg_Counter;
uint8  WattingDereg_Counter;	//�ִ� 3�� �̹Ƿ�..96 ��.. 255 �Ѿ�� ����...
uint8  DelayedPostDeregReqCounter;	//�ִ� 3�� �̹Ƿ�..96 ��.. 255 �Ѿ�� ����...

//--------- FTM ----------
const unsigned char string_ok[] = {"OK\r\n"};

st_mem_func_test    Factory;
st_mem_ftm_memory Factory_Memory;

uint8 ftm_uart_a1_rx[50];
uint8 sw_version[3];

uint8 refresh_ftm_display = 0;
uint8 refresh_normal_display = 0;

uint8 FTM_mode_flag;
uint8 uart_rx_done_flag = 0;
uint8 A1_Rx_FTM;
//-----------------------

st_log_save_counter_type	Logo;

