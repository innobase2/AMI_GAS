
#ifndef int8
typedef signed char int8;
//#define int8_t int8
#define INT8_MIN (-128)
#define INT8_MAX (127)
#endif

#ifndef int16
typedef signed int int16;
//#define int16_t int16
#define INT16_MIN (-32768)
#define INT16_MAX (32767)
#endif

#ifndef int32
typedef signed long int int32;
//#define int32 int32
#define INT32_MIN (-2147483648L)
#define INT32_MAX (2147483647L)
#endif

#ifndef uint8_t
typedef unsigned char uint8;
#define uint8_t uint8
#define UINT8_MAX (255)
#endif

#ifndef uint16
typedef unsigned int uint16;
//#define uint16 uint16
#define UINT16_MAX (65535U)
#endif

#ifndef uint32
typedef unsigned long int uint32;
//#define uint32 uint32
#define UINT32_MAX (4294967295UL)
#endif

#ifndef uint64
typedef unsigned long long int uint64;
#endif