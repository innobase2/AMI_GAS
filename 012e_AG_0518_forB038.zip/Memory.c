
#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"


void FRAMWrite(void);
void FRAMReade(void);
void Save_Mem_Data(void);
void Hex2Bcd( uint32 );
void Find_Last_Mem(void);

void Find_Last_Mem(void)
{
  uint16 *temp_Ptr;
  uint16  mem_temp_data;
  
  temp_Ptr = (uint16 *)(SAVED_COUNTER);
  mem_temp_data = *temp_Ptr ;
  mem_temp_data &=(0x1FF);
  
  if(mem_temp_data == 0x1FF)  // �ѹ��� ������ �ȵ� ����
  {

  }
  else
  {       
     Memory.Save_Counter    = mem_temp_data;
     Memory.Tx_temp_Counter = Memory.Save_Counter;
     //Memory.Data_ptr        = (uint8 *)(SAVE_START + ( ( Memory.Save_Counter - 1) * 20)) ;
     Memory.Data_ptr     = (uint8 *)(SAVE_START + ( ( Memory.Save_Counter - 1) * 20)) ; 
     Memory.FRAM_WR_ptr  = &(Woking.ymdhms.Year);     
     FRAMReade(); 
     
      while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready         
      RTCYEAR =Woking.ymdhms.Year ;                        // Year = 0x2017
      RTCMON = Woking.ymdhms.Month;                        // Month = 0x03 = Mar
      RTCDAY = Woking.ymdhms.Day;                          // Day = 0x01 = 1th
      RTCHOUR= Woking.ymdhms.Hours;                        // Hour = 0x10
      RTCMIN = Woking.ymdhms.Min;                          // Minute = 0x32
      RTCSEC = Woking.ymdhms.Sec;                          // Seconds = 0x45         
      Dec_Counter_H = __swap_bytes(Woking.AddupFlow_H) ;
      Dec_Counter_L = __swap_bytes(Woking.AddupFlow_L) ; 
      Memory.Trsmmi_Counter = Memory.Save_Counter;        
  }  
  
}


void FRAMReade(void)
{
  uint8 i=0;
  for ( i= 0; i<20; i++)
  {
    *Memory.FRAM_WR_ptr = *Memory.Data_ptr;
	Memory.FRAM_WR_ptr++;
    Memory.Data_ptr++;
  }
}


void FRAMWrite(void)
{
  uint8 i=0;
  _DINT();
  for ( i= 0; i<20; i++)
  {
    *Memory.FRAM_WR_ptr = *Memory.Data_ptr;
    Memory.FRAM_WR_ptr++;
    Memory.Data_ptr++;
  }
  _EINT();
}

void Save_Mem_Data(void)
{
  uint16 temp;
  uint16 *temp_Ptr;
    
  if(Stflag.bit.Save_mem)
  {
    Stflag.bit.Save_mem = 0;
    while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready
    Memory.Data.Normal.ymdhms.Year  = (0xFF & RTCYEAR );
    Memory.Data.Normal.ymdhms.Month = RTCMON;
    Memory.Data.Normal.ymdhms.Day   = RTCDAY;
    Memory.Data.Normal.ymdhms.Hours = RTCHOUR;
    Memory.Data.Normal.ymdhms.Min   = RTCMIN;
    Memory.Data.Normal.ymdhms.Sec   = RTCSEC;
    Memory.Data.Normal.Rssi         = __swap_bytes(Rssi_Val);
    Memory.Data.Normal.AddupFlow_H  = __swap_bytes(Dec_Counter_H);
    Memory.Data.Normal.AddupFlow_L  = __swap_bytes(Dec_Counter_L);
    Memory.Data.Normal.InstanFlow_00 = 0;
    
    asm_temp = Instant_Q ; // ���� ����
    Hex2Bcd32(asm_temp);
    temp = asm_temp_12;
    
    Memory.Data.Normal.InstanFlow_L = __swap_bytes(temp);
    
    temp = Pressure.Value / 1000 ;
    temp = __swap_bytes(temp);  
    Memory.Data.Normal.PressDigit_F = temp & 0xff;
    temp >>=8;
    Memory.Data.Normal.PressDigit_F = temp & 0xff;
    Memory.Data.Normal.St3.all      = St3.all;
    Memory.Data.Normal.St2.all      = St2.all; 
    Memory.Data.Normal.St1.all      = St1.all;
    
    Memory.Data_ptr = &(Memory.Data.Data_Str[0]);
    Memory.FRAM_WR_ptr = (uint8 *)(SAVE_START + (Memory.Save_Counter * 20));   
    FRAMWrite();
    Memory.Save_Counter ++;  
    temp_Ptr        = (uint16*)(SAVED_COUNTER);
    *temp_Ptr = Memory.Save_Counter;    
  }
  
  if((READ_BATT_TEMPER == 0) && (Guard.bit.Power_ON ==0 ))
  {     
    __delay_cycles(300000);
    
    if(READ_BATT_TEMPER == 0)
    {        
      DI1_MEM   = ( DI1_MEM & S9 ) | CHAR1_b;
      S1TO8_MEM |= S2  ; //�� ��� �� 
      T4_MEM      &= ~T4;
      T3_MEM      &= ~T3;
      T12_D12_MEM &= ~T2;
      _DINT();
      while(1);
    }
  }
}

#ifdef FEATURE_LOG_SAVE
void Logo_Save(uint8  *SaveStr)
{
	uint8 len;

	len  = strlen((char*)SaveStr);
	len  +=4;                
	*(uint8 *)(LOG_START + Logo.Counter) = len;
	Logo.Counter++;
	loop = ( loop>20) ? 20 : loop;
	
	while(!(RTCCTL13 & RTCRDY)); //Real-time clock ready

	*(uint8 *)(LOG_START + Logo.Counter) = RTCMON;
	Logo.Counter++;	
	*(uint8 *)(LOG_START + Logo.Counter) = RTCDAY;
	Logo.Counter++;
	*(uint8 *)(LOG_START + Logo.Counter) = RTCHOUR;
	Logo.Counter++;
	*(uint8 *)(LOG_START + Logo.Counter) = RTCMIN;
	Logo.Counter++;  
	while(len)
	{
		_DINT();
		*(uint8 *)(LOG_START + Logo.Counter) = *SaveStr++ ; 
		_EINT(); 
		Logo.Counter++; 
		len--;
	} 
}

void Send_LogData(void)
{
	int i;
	for ( i = 0 ; i < LOG_DATA_LEN; i++)
	{
		while(!(UCA1IFG & UCTXIFG));
		UCA1TXBUF= *(uint8*)(LOG_START+i);
		while(UCA1STATW & UCBUSY);
	}
	
}
#endif

