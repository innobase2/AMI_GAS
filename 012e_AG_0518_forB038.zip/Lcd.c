#include <msp430.h>
#include "Extern_Valiable.h"
#include "MSP_PIN_Con.h"
#include "Lcd.h"

void Lcd_init(void);
void Lcd_test(void);
void Lcd_Display(void);

extern void Buzzer_Start(void);

void Lcd_init(void)
{
//----------------------------------------------------------------------------//  
// NOTE: Settings for LCDDIVx, LCDPREx, LCDSSEL, LCDLP and LCDMXx             //
//       should be changed only while LCDON = 0.                              //
//----------------------------------------------------------------------------// 
    // Turn off LCD module
    LCDCCTL0 &=  ~LCDON ;  
    // LCD_FREQ = ACLK/32/2 = 256,  LCD Mux 4, LCD segment On 
    LCDCCTL0 =  LCDDIV__32  | LCD4MUX | LCDSON | LCDPRE__2 ;//| LCDPRE__2;
    //Charge pump generated internally at 2.96V,
    // VLCDx,  0010b to 1110b 
    // If VLCDREFx = 00 or 10: V(LCD) = 2.60 V + (VLCDx - 1) �� 0.06 V; 
    // If VLCDREFx = 01 or 11: V(LCD) = 2.17 �� V(REF) + (VLCDx - 1) �� V(REF)0.05
    // external bias (V2-V4) generation
    // 
    //LCDCVCTL = LCDCPEN | VLCD_2_96 | LCDREXT  ; //| LCD2B;//| LCDEXTBIAS;
    //LCDCVCTL &= ~LCDCPEN;
    
    //LCDCVCTL =  LCDREXT  |LCDEXTBIAS| R03EXT ;
    
    //LCDCVCTL = LCDCPEN | VLCD_2_9 | LCDEXTBIAS | LCDREXT ;//| LCD2B ;
    // Select LCD Segments              
    SEL_SEGMENT3
    SEL_SEGMENT2  //LCDM2
    SEL_SEGMENT1
    SEL_SEGMENT0  //LCDM17
    SEL_SEGMENT16 //LCDM14 
    SEL_SEGMENT15 
    SEL_SEGMENT14 //LCDM13
    SEL_SEGMENT13
    SEL_SEGMENT12 //LCDM12 
    SEL_SEGMENT11  
    SEL_SEGMENT10 //LCDM6  
    SEL_SEGMENT9
    SEL_SEGMENT8  //LCDM11
    SEL_SEGMENT7
    SEL_SEGMENT6  //LCDM5
    SEL_SEGMENT5   
    SEL_SEGMENT4  //LCDM4
      
    LCD_COMx_PIN_SEL  
    LCD_RX3_PIN_SEL
      
    LCDCCPCTL = LCDCPCLKSYNC;               // Clock synchronization enabled

    LCDCMEMCTL = LCDCLRM;                   // Clear LCD memory
      
      
    LCDCCTL0 |=  LCDON ; //turn on LCD module
  
  
}
void Lcd_test(void)
{
  uint8 temp_num0;
  
    LCDM17 = LCDM2 = LCDM6 = LCDM7 = LCDM13 = LCDM14 = LCDM4 =0x0;
    

    for(temp_num0 = 0 ;  10 > temp_num0 ; temp_num0++)
    {
      DI1_MEM = LCD_Tab_Center[temp_num0];
      DI2_MEM = LCD_Tab[temp_num0] ;
      DI3_MEM = LCD_Tab[temp_num0] ;
      DI4_MEM = LCD_Tab[temp_num0] ;
      DI5_MEM = LCD_Tab[temp_num0] ;
      DI6_MEM = LCD_Tab[temp_num0] ;
      DI7_MEM = LCD_Tab[temp_num0] ;

    __delay_cycles(200000);    
    }
    for(temp_num0 = 0 ;  11 > temp_num0 ; temp_num0++)
    {
      LCDMEM[IOCN_MAP[temp_num0]] |= LCD_ICON[temp_num0+1];
    __delay_cycles(200000);    
    } 
    
    T12_D12_MEM |= T1;
    __delay_cycles(200000);
    T12_D12_MEM |= T2;
    __delay_cycles(200000);   
    T3_MEM |= T4;
    __delay_cycles(200000);    
    T4_MEM |= T4;
    __delay_cycles(200000);
    T12_D12_MEM |= D1;
    __delay_cycles(200000);
    T12_D12_MEM |= D2;
    __delay_cycles(200000);    
    
    LCDM17 = LCDM2 = LCDM3 = LCDM6 = LCDM7 = LCDM13 = LCDM14 = LCDM4 = LCDM5 = 0x0;
    
    DI1_MEM = LCD_Tab_Center[0];
    T12_D12_MEM |= T1;
    T12_D12_MEM |= T2;
    T3_MEM |= T3;
    T4_MEM |= T4;
    

}

void Lcd_Display(void)
{
  uint16 LCD_temp_0;
  uint16 LCD_temp_1;
  
    if(Stflag.bit.LCD_display)
    {
      Stflag.bit.LCD_display = 0;
      
      LCD_temp_0 = Dec_Counter_L;
      
      LCD_temp_1 = ( LCD_temp_0 & 0x0f );      
      DI7_MEM = LCD_Tab[LCD_temp_1];
      
      LCD_temp_0 >>=4;
      LCD_temp_1 = ( LCD_temp_0 & 0x0f );      
      DI6_MEM = LCD_Tab[LCD_temp_1];
      
      LCD_temp_0 >>=4;
      LCD_temp_1 = ( LCD_temp_0 & 0x0f );      
      DI5_MEM = LCD_Tab[LCD_temp_1];
      
      LCD_temp_0 >>=4;
      LCD_temp_1 = ( LCD_temp_0 & 0x0f );      
      DI4_MEM = LCD_Tab[LCD_temp_1];  
      
      LCD_temp_0 = Dec_Counter_H;
      
      LCD_temp_1 = ( LCD_temp_0 & 0x0f );      
      DI3_MEM = LCD_Tab[LCD_temp_1];
      
      LCD_temp_0 >>=4;
      LCD_temp_1 = ( LCD_temp_0 & 0x0f );      
      DI2_MEM = LCD_Tab[LCD_temp_1];
    }
    else; 
}


