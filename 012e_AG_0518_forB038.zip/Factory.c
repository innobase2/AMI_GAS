#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"
#include "Lcd.h"
#include "Meter_Unit.h"
#include <string.h>

const unsigned char string_SV[] = {"012d_AG\r\n"}; // SW Version
// 020a_AG �ٲܰ�.
#define FTM_LED         0x31
#define FTM_BUZZER      0x32
#define FTM_LCD         0x33
#define FTM_TEST        0x34
#define FTM_BATT        0x35
#define FTM_TYPE_W      0x36
#define FTM_SERIAL_W    0x37
#define FTM_SERIAL_R    0x38
#define FTM_FLAG_W      0x39
#define FTM_FLAG_R      0x30
#define FTM_ENTER       0x45
#define FTM_MODEM       0x4D
#define FTM_EXIT        0x51
#define FTM_TYPE_R      0x52
#define FTM_VERSION     0x56
#define FTM_BYPASS      0x54

#ifdef FEATURE_LOG_SAVE
#define FTM_GET_LOG      0x4C 	// 'L'
#endif

const unsigned char string_modem[]  = {"MODEM: "};
const unsigned char string_sim[]    = {"SIM: "};
const unsigned char string_flow[]   = {"FLOW: "};
const unsigned char string_cheat[]  = {"CHEAT: "};
const unsigned char string_batt[]   = {"BATT: "};
const unsigned char string_button[] = {"BUTTON: "};

//const unsigned char string_ok[] = {"OK\r\n"};
const unsigned char string_ng[]    = {"NG\r\n"};
const unsigned char string_nt[]    = {"NT\r\n"};
const unsigned char string_cimi[]  = {"AT+CIMI\r\n"};  //IMSI �б� Device ID�� ����

static const uint8 __OK[]          = {"OK"};
static const uint8 __ERROR[]       = {"ERROR"};
static const uint8 __Uatr_Task[]   = {"Uart Task!!"};

unsigned int i; //Counter
int   Data_cnt=0;

extern void Buzzer_Start(void);
extern void Buzzer_Stop(void);
extern void Flow_Display(void);
extern void Nb_Tx_ComProcess(const uint8 *Tx_temp_ptr);
extern void Battery_Monitor(void);

int getCharSize(const unsigned char* pointer);
void SendString(const unsigned char* st);
void Clear_Item_Test(void);
void Factory_Test_Mode(void);
void Factory_Test(void);
void Main_Display(void);
void FTM_Display(void);
void ADC_Display(void);
void String_compare(void);

int getCharSize(const unsigned char* pointer)
{
  int j=-1;
  while(pointer[++j] != '\0'){ }
  return j;
}

void SendString(const unsigned char* st)
{
  unsigned int i; //Counter
  for ( i = 0 ; i < (getCharSize(st) -1); i++)
  {
    while(!(UCA1IFG & UCTXIFG));
    UCA1TXBUF= st[i];
    while(UCA1STATW & UCBUSY);
  }  
}
void Clear_Item_Test(void)
{
  CLR_LED;
  Stflag.bit.Conti_Buzzer = 0;
  Buzzer_Stop();
  REFCTL0 = 0;
  LED_error.bit.ADC_on_off  = 0;
  Stflag.bit.LCD_display = 0;
  LED_error.bit.ADC_display = 0;
  refresh_ftm_display = 1;
}

void Fatory_Test_Mode(void)
{
  Battery_Monitor();
  Factory_Test();
  FTM_Display();
  Lcd_Display();
  
  if(READ_BATT_TEMPER == 0)
  {            
    DI1_MEM   = ( DI1_MEM & S9 ) | CHAR1_b;
    S1TO8_MEM |= S2  ; //�� ��� �� 
    T4_MEM      &= ~T4;
    T3_MEM      &= ~T3;
    T12_D12_MEM &= ~T2;
    _DINT();           
    while(1);
  }
}

void Factory_Test(void)
{
  unsigned int buf_cnt;
  unsigned int mem_cnt;
  
  if(uart_rx_done_flag)
  {
    if(ftm_uart_a1_rx[1] == 0x47)
    {
      if(ftm_uart_a1_rx[2] == 0x2b)
      {
        switch(ftm_uart_a1_rx[3])
        {
        case FTM_LED:
          SendString(string_ok);
          Clear_Item_Test();
          SET_LED;
          break;
        case FTM_BUZZER:
          SendString(string_ok);
          Clear_Item_Test();
          Stflag.bit.Conti_Buzzer = 1;
          Buzzer_Start();
          break;
        case FTM_LCD:
          SendString(string_ok);
          Clear_Item_Test();
          Factory.lcd = 1;
          break;
        case FTM_TEST:
          refresh_ftm_display = 1;
          if(ftm_uart_a1_rx[4] == 0x45)
          {
            Clear_Item_Test();
            Factory.flow = 1;
            Factory.cheat = 1;
            Factory.button = 1;
            SendString(string_ok);
          }
          else if(ftm_uart_a1_rx[4] == 0x51)
          {
            Factory.flow = 0;
            Factory.cheat = 0;
            Factory.button = 0;
            SendString(string_ok);
          }
          break;
        case FTM_BATT:
          refresh_ftm_display = 1;
          LED_error.bit.ADC_display = 1;
          Clear_Item_Test();
//          if(Battery.ADC_loop == 0)
//          {
            Battery.ADC_Start = 1;
            //Battery.ADC_loop = 1;  
            LED_error.bit.ADC_on_off = 1;
            //LED_error.bit.ADC_display = 1;
//          }
          Factory.batt = 1;
          break;
        case FTM_TYPE_W:
          Clear_Item_Test();
          Factory_Memory.FRAM_WR_ptr = (uint8 *)METER_TYPE;
          _DINT();
          *Factory_Memory.FRAM_WR_ptr = ftm_uart_a1_rx[4];
          _EINT(); 
          SendString(string_ok);
          break;
        case FTM_TYPE_R:
          Clear_Item_Test();
          Factory_Memory.FRAM_WR_ptr = (uint8 *)METER_TYPE;
          while(!(UCA1IFG & UCTXIFG));
          UCA1TXBUF= *Factory_Memory.FRAM_WR_ptr;
          while(UCA1STATW & UCBUSY);
          while(!(UCA1IFG & UCTXIFG));
          UCA1TXBUF= 0x0A;
          while(UCA1STATW & UCBUSY);
          break;
        case FTM_SERIAL_W:
          Clear_Item_Test();
          mem_cnt = 0;
          for (buf_cnt = 4 ; buf_cnt < 10; buf_cnt++)
          {
            Factory_Memory.FRAM_WR_ptr = (uint8 *)FTM_SN_SAVE + mem_cnt;
            _DINT();
            *Factory_Memory.FRAM_WR_ptr = ftm_uart_a1_rx[buf_cnt];
            _EINT(); 
            mem_cnt++;
          }
          SendString(string_ok);
          break; 
        case FTM_SERIAL_R:
          Clear_Item_Test();
          for (mem_cnt = 0 ; mem_cnt < 7; mem_cnt++)
          {
            Factory_Memory.FRAM_WR_ptr = (uint8 *)FTM_SN_SAVE + mem_cnt;
            while(!(UCA1IFG & UCTXIFG));
            if(mem_cnt ==8)
              UCA1TXBUF= 0x0A;
            else
              UCA1TXBUF= *Factory_Memory.FRAM_WR_ptr;
            while(UCA1STATW & UCBUSY);
          }
          break;
        case FTM_FLAG_W:
          Clear_Item_Test();      
          Factory_Memory.FRAM_WR_ptr = (uint8 *)FTM_RESULT_SAVE;
          _DINT();
          *Factory_Memory.FRAM_WR_ptr = ftm_uart_a1_rx[4];
          _EINT();            
          SendString(string_ok);
          break;
        case FTM_FLAG_R:
          Clear_Item_Test();
          Factory_Memory.FRAM_WR_ptr = (uint8 *)FTM_RESULT_SAVE;
          while(!(UCA1IFG & UCTXIFG));
          UCA1TXBUF= *Factory_Memory.FRAM_WR_ptr;
          while(UCA1STATW & UCBUSY);
          while(!(UCA1IFG & UCTXIFG));
          UCA1TXBUF= 0x0A;
          while(UCA1STATW & UCBUSY);
          break;
        case FTM_ENTER:
          Clear_Item_Test();
          FTM_mode_flag = 1;
//          Factory_Memory.FRAM_WR_ptr = (uint8 *)FTM_SAVE;
//          _DINT();
//          *Factory_Memory.FRAM_WR_ptr = FTM_mode_flag;
//          _EINT(); 
          SendString(string_ok);
          break;
        case FTM_EXIT:
          Clear_Item_Test();
          refresh_normal_display = 1;
          FTM_Display();
          FTM_mode_flag = 0;
          Hex_Counter_H = 0;
          Dec_Counter_L = 0;
          
//          Factory_Memory.FRAM_WR_ptr = (uint8 *)FTM_SAVE;
//          _DINT();
//          *Factory_Memory.FRAM_WR_ptr = FTM_mode_flag;
          SendString(string_ok);
//          _EINT();
          break;      
          
        case FTM_MODEM:
          Clear_Item_Test();
          Factory.modem = 1;
          Nb_Tx_ComProcess(string_cimi);
          break;
        
        case FTM_VERSION:
          Clear_Item_Test();
          SendString(string_SV);
		  break;
#ifdef FEATURE_LOG_SAVE
		case FTM_GET_LOG:
			Send_LogData();
			break;
#endif
					
        default:
          break;
        }
      }
    }
    else if(ftm_uart_a1_rx[1] == FTM_BYPASS)
    {
      Factory.bypass = 1;
      Nb_Tx_ComProcess(ftm_uart_a1_rx);
    }
    uart_rx_done_flag = 0;
  }

  if(Factory.bypass == 1)
  {
    if(Com1.bit.At_Rx_end)
      Factory.bypass = 0;
  }
 
  if(Factory.modem == 1)
  {
    if(Com1.bit.At_Rx_end)
    {
      Com1.bit.At_Rx_end = 0;
      String_compare();
    }
  }
  
  if(Factory.button == 1)
  {
    if(Botton.bit.P_test  == 1)
    {    
      if(Factory.button)
      {
        SendString(string_button);
        SendString(string_ok);
        Factory.button = 0;
      }
      //      Factory.response.button = 1;
      //      Factory_test.func_response = 1;
      //Factory.button = 0;
    }
  }
  
  if(Stflag.bit.Inc_Pulse_Counter)
  {
    Stflag.bit.Inc_Pulse_Counter = 0; 
    if(Factory.flow)
    {
      SendString(string_flow);
      SendString(string_ok);
      Factory.flow = 0;
    }
    LED_error.bit.ADC_on_off  = 0;
    LED_error.bit.ADC_display = 0;
    
    Stflag.bit.LCD_display = 1;
    Input_Pulse_Counter++;
    
    if(Input_Pulse_Counter >= L_PLUSE_COUNTER ) 
    {
      Input_Pulse_Counter = 0;
      Stflag.bit.LCD_display = 1; // for Reflash
      
      
      Hex_Counter_L++   ;           
      if( __get_SR_register() & 1 ) // get carry bit ,Set if there is a carry from the MSB of the result, 
        // reset otherwise
      {
        Hex_Counter_H++;//00000.000 
      }
      else ;
      
      asm("   SETC  "); 
      asm("   DADC.W  &Dec_Counter_L"); // Dec_inc meter count   0x0000 ~ 0x9999
      if(Dec_Counter_L == 0 ) 
      {
        asm("   SETC  "); 
        asm("   DADC.W  &Dec_Counter_H");
        if(Dec_Counter_H == 0)
        {
          Dec_Counter_L = 1;
          
          Hex_Counter_H = 0;
          Hex_Counter_L = 0; // 10CC * 100 = 1000 CC = 1L
          Hex_Counter_025 = 0;
        }
      }
    }     
  }
  
  if(READ_MAGNET_CHK == 0)
  {
    if(Factory.cheat)
    {
      SendString(string_cheat);
      SendString(string_ok);
      Factory.cheat = 0;
    }
  }
  
  if(Factory.batt == 1)
  { 
    if(LED_error.bit.ADC_display)
    {
      SendString(string_batt);
      if(Battery._1mV > 750)
        SendString(string_ok);
       else
        SendString(string_ng);       
      Factory.batt = 0;
//      Battery.ADC_loop == 0;
    }
  }
}

void FTM_Display(void)
{
  uint16 hundred;
  uint16 ten;
  uint16 zero;

  if(Factory.lcd)
  {
    Factory.lcd = 0;
    refresh_ftm_display = 0;
    LCDM2 = LCDM3 = LCDM4 = LCDM5 = LCDM6 = LCDM7 = LCDM13 =  LCDM14 = LCDM17 = 0xFF;
  }
  else if(refresh_ftm_display)
  {
    LCDM2 = LCDM3 = LCDM4 = LCDM5 = LCDM6 = LCDM7 = LCDM13 =  LCDM14 = LCDM17 = 0x0; 
    DI1_MEM = CHAR1_A;
    S9_MEM |= ICON_S9;
    if(Stflag.bit.LCD_display == 0)
    {
      unsigned int string_count; //Counter
      
      for(string_count = 0 ; string_count < 3; string_count++)
        sw_version[string_count] = string_SV[string_count] & 0x0f;
      
      DI2_MEM = LCD_Tab[sw_version[0]];
      DI3_MEM = LCD_Tab[sw_version[1]];
      DI4_MEM = LCD_Tab[sw_version[2]];
    }
    refresh_ftm_display = 0;
  } 
  
  if(refresh_normal_display)
  {
    LCDM2 = LCDM3 = LCDM4 = LCDM5 = LCDM6 = LCDM7 = LCDM13 = LCDM14   = LCDM17 = 0x0; 
    DI1_MEM = LCD_Tab_Center[0];
    T12_D12_MEM |= T1;
    T12_D12_MEM |= T2;
    T3_MEM |= T3;
    T4_MEM |= T4;
    refresh_normal_display = 0;
  }
  
  if(LED_error.bit.ADC_display)
  {
    hundred = Battery._1mV / 100;
    ten = (Battery._1mV - (hundred * 100)) / 10;
    zero = Battery._1mV - (hundred * 100) - (ten * 10);
    
    hundred = hundred & 0x0f;
    ten = ten & 0x0f;
    zero = zero & 0x0f;  
    
    DI5_MEM = LCD_Tab[hundred];
    DI6_MEM = LCD_Tab[ten];
    DI7_MEM = LCD_Tab[zero];
    T12_D12_MEM |= D1 + D2; 
  }
}

void String_compare(void)
{
  char *devide_ptr;
  
  _index = 0;
  Data_index = 0;
  OK_index   = 0;
  
  Nb_Str_Rx[Str_Counter_at] = 0;
  
  memcpy(Nb_Str_Rx_temp,Nb_Str_Rx,Str_Counter_at);
  
  Data_cnt = 0;
  memset(Nb_Str_Rx, 0x00, sizeof(Nb_Str_Rx));
  
  for(_index=0;_index < Str_Counter_at;_index++)
  {
    if(Nb_Str_Rx_temp[_index]==0x00)
      Nb_Str_Rx_temp[_index]=0x20;
  }
  
  Str_Counter_at = 0;
  
  devide_ptr = strtok(Nb_Str_Rx_temp, "\r\n");      
  
  if(devide_ptr)
  {
    SendString(string_modem);
    if(strlen(devide_ptr) == 15)
      SendString(string_ok);
    else if(cus_strcmp( devide_ptr, __OK))  
      SendString(string_ng);
    else if(cus_strcmp( devide_ptr, __ERROR)) 
      SendString(string_ng);
    else if(cus_strcmp( devide_ptr, __Uatr_Task))
      SendString(string_ok); 
  }

    Factory.modem = 0;
}
