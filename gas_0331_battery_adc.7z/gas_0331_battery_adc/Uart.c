#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"
#include "Meter_Unit.h"
#include "Protocol.h"

void Init_Uart(void);
void Communication(void);

uint8 RXData;  // for test

void Init_Uart(void)
{
//	34	P3.4/UCA1SIMO/UCA1TXD/TB0.0/S21	        TX_DPLC	uart
//	35	P3.5/UCA1SOMI/UCA1RXD/TB0.1/S20	        RX_DPLC	uart  
  UART1_DPLC_SEL ;
  // Configure USCI_A0 for UART mode
  UCA1CTL1 |= UCSWRST;
  UCA1CTL1 = UCSSEL__ACLK;                  // Set ACLK = 32768 as UCBRCLK
  UCA1BR0 = 6;                              // 4800 baud
  UCA1MCTLW |= 0xDF00;                      // 32768/4800- INT(32768/4800)=0.85
                                            // UCBRSx value = 0xDF (See UG)
  UCA1BR1 = 0;
  UCA1CTL1 &= ~UCSWRST;                     // release from reset
  UCA1IE |= UCRXIE; 
  
//	40	P2.1/UCA0RXD/TB0.5/S15	RX_MODEM
//	41	P2.0/UCA0TXD/TB0.6/S14	TX_MODEM
  UART0_MODEM_SEL ;
  // Configure USCI_A0 for UART mode
  UCA0CTL1 |= UCSWRST;
  UCA0CTL1 = UCSSEL__ACLK;                  // Set ACLK = 32768 as UCBRCLK
  UCA0BR0 = 6;                              // 4800 baud
  UCA0MCTLW |= 0xDF00;                      // 32768/4800- INT(32768/4800)=0.85
                                            // UCBRSx value = 0xDF (See UG)
  UCA0BR1 = 0;
  UCA0CTL1 &= ~UCSWRST;                     // release from reset
  UCA0IE |= UCRXIE;   
  
}

#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
  switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG))
  {
    case USCI_NONE: break;
    case USCI_UART_UCRXIFG:
      UCA0TXBUF = UCA0RXBUF;                   // Read buffer

      __bic_SR_register_on_exit(LPM3_bits); // Exit LPM3 on reti
      break;
    case USCI_UART_UCTXIFG: break;
    case USCI_UART_UCSTTIFG: break;
    case USCI_UART_UCTXCPTIFG: break;
  }
}

#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)
{
  switch(__even_in_range(UCA1IV,USCI_UART_UCTXCPTIFG))
  {
    case USCI_NONE: break;
    case USCI_UART_UCRXIFG:
      UCA1TXBUF = UCA1RXBUF;                   // Read buffer

      __bic_SR_register_on_exit(LPM3_bits); // Exit LPM3 on reti
      break;
    case USCI_UART_UCTXIFG: break;
    case USCI_UART_UCSTTIFG: break;
    case USCI_UART_UCTXCPTIFG: break;
  }
}


void Communication(void)
{
  if(Com.all)
  {
    
    
  }
  
}