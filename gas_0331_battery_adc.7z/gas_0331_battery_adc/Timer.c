#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"

void Timer_Init(void);

void Timer_Init(void)
{
  
    //TA0CCR0 = 32768>>3;                         // 8 Hz inerval timer
    //TA0CCTL0 = CCIE;                            // TACCR0 interrupt enabled

    TA0CTL = TASSEL__ACLK | MC__CONTINUOUS  | TACLR;
    
    TA1CTL = TASSEL__SMCLK | MC__CONTINUOUS | TACLR;  

    TB0CCTL2 = CM_3 | CCIS_0 | SCS | CAP | CCIE;
                                            // Capture both.edge,
                                            // Use CCI2A=ACLK,
                                            // Synchronous capture,
                                            // Enable capture mode,
                                            // Enable capture interrupt

    TB0CTL = TBSSEL__ACLK | MC__CONTINUOUS; // Use SMCLK as clock source,
                                            // Start timer in continuous mode
    
    TA0CCR0 = 32768>>3;                     // 8 Hz tick timer
    TA0CCTL0 = CCIE;                        // TACCR0 interrupt enabled
  
}

// Timer0_A0 interrupt service routine
#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer0_A0_ISR (void)
{
  TA0CCR0 += 32768>>6;       // 8 HZ Ȯ��
  //if(Botton.bit.P_test)      //  port test
  //{
    if(READ_RETURN == 0) 
    {
      P_test_32hz_counter++;
      if(!(P_test_32hz_counter%20))
          S1TO8_MEM ^= S4 ;   // �����Ǹ� toggle ����
      if( P_test_32hz_counter > (32*7) ) P_test_32hz_counter = ( 32*7 );
    }
    else 
    {
      if(P_test_32hz_counter < 16)_NOP();       // 0.5�� �̸�
      else if( P_test_32hz_counter > ( 32*5 ) ) // 5�� �̻�
      {
        Botton.bit.Test_Button_On ^= 1;
        S9_MEM ^= S9;
        if(Botton.bit.Test_Button_On)
            Battery.ADC_Start = 1;
        else
        {
            Battery.ADC_loop = 0;
            Stflag.bit.ADC_display = 0;
        }
      }
      else
      {
        Com.bit.On_Module = 1;
      }
      S1TO8_MEM &=~S4 ;
      Botton.bit.P_test = 0;
      P_test_32hz_counter =0;      
    }  
  //}
  //else ;
  if(Battery.load_En)
  {
    if(Battery.Counter++ > 5) // 125ms
    {
      Battery.Counter   = 0;
      Battery.load_En   = 0;
      
      Battery.ADC_en    = 1;
      
      __bic_SR_register_on_exit(LPM3_bits);
    }
  }
  else ;
  if(Battery.ADC_en)
  {
    if(Battery.Counter++ > 4) // 66ms
    {
      Battery.Counter   = 0;
      Battery.ADC_en    = 0;
      
      Battery.ADC_on    = 1;

      __bic_SR_register_on_exit(LPM3_bits);
    }
  }
  else ;
  if(Battery.ADC_loop)
  {
      if(ADC_test_32hz_counter++ > (32*10))   // 5�� �̻�
      {
          Battery.ADC_Start = 1;
          ADC_test_32hz_counter = 0;

          __bic_SR_register_on_exit(LPM3_bits);
      }
  }
  else ;
  if(Pressure.Delay_on)
  {
    Pressure.Counter++;
    if( Pressure.Counter > 5)
    {
      Pressure.Delay_on = 0;
      UCB0IE |= UCRXIE | UCNACKIE | UCBCNTIE;
      while (UCB0CTL1 & UCTXSTP);             // Ensure stop condition got sent
      UCB0CTL1 |= UCTXSTT;                    // I2C start condition
      Pressure.Counter = 0;         
    }
  }
}

// Timer0_A1 Interrupt Vector (TAIV) handler
#pragma vector=TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{
  switch(__even_in_range(TA0IV, TA0IV_TAIFG))
  {
    case TA0IV_NONE:   break;               // No interrupt
    case TA0IV_TACCR1:                      // used Buzzer Interval 0.5 Sec
      TA0CCR1 += 32768>>1;                  // ���Ӱ����? LED + ������ 0.5 �� ON �ϰ� 
                                            // 1.5 �� OFF �ϴ� ���� 1 �ֱ�� ���� ��� �ݺ��ϴ� ���� ���Ѵ�.
      Stflag.bit.Buzzer_Set ^=1;
      if(Stflag.bit.Buzzer_Set == 0)
      {
        TA0CCR1 +=32768;
      }
      
      if( Stflag.bit.Conti_Buzzer == 0)
      {
        Buzzer_05s_counter++;
        if(Buzzer_05s_counter >=( Buzzer_Sec_counter * 2))
        { // stop Condition
          CLR_LED;
          CLR_BUZZER;
          Stflag.bit.Buzzer_Doing = 0;
          TA1CCTL0 = 0;
          TA0CCTL1 = 0;
        }
      }
      break;               
    case TA0IV_TACCR2: 
      break;               // CCR2 not used
    case TA0IV_3:      break;               // reserved
    case TA0IV_4:      break;               // reserved
    case TA0IV_5:      break;               // reserved
    case TA0IV_6:      break;               // reserved
    case TA0IV_TAIFG:                       // overflow
      P1OUT ^= BIT0;
      break;
    default: break;
  }
}



// Timer0_A0 interrupt service routine
#pragma vector = TIMER1_A0_VECTOR
__interrupt void Timer1_A0_ISR (void)
{
  TA1CCR0 += 150;
  if(Stflag.bit.Buzzer_Set)
  {
    XOR_BUZZER;
    SET_LED;
  }
  else 
  {
    CLR_BUZZER;
    CLR_LED;
  }
}

// Timer0_B3 CC1-4, TB Interrupt Handler

#pragma vector = TIMER0_B1_VECTOR
__interrupt void TIMER0_B1_ISR(void)
{
  switch (__even_in_range(TB0IV, TB0IV_TBIFG)) {
    case TB0IV_TB0CCR1:
      TB0CCR1         += 5;
#ifdef SMTEST_PIN         

XOR_PRO_BUTTON
  
#endif       
      if(Stflag.bit.Pulse_H_Capture)
      {
        if(READ_PULSE_IN)
        {
          Capture_D_Counter++;
          if(Capture_D_Counter>10)
          {
            Stflag.bit.Pulse_H_Stable = 1;
            TB0CCTL1        = 0;        // stop timer
          }
        }
        else
        {
          Capture_D_Counter = 0;
          TB0CCTL1        = 0;
        }        
      }
      if(Stflag.bit.Pulse_L_Capture)
      {
        if(READ_PULSE_IN == 0)
        {
          Capture_D_Counter++;
          if(Capture_D_Counter>10)
          {
            Stflag.bit.Pulse_L_Stable = 1;
            TB0CCTL1        = 0;            // stop timer
            if(Stflag.bit.Pulse_H_Stable)
            {
#ifdef SMTEST_PIN            

SET_LED
  
#endif 
              Stflag.bit.Pulse_H_Stable = 0;
              Stflag.bit.Inc_Pulse_Counter = 1;
              
#ifdef SMTEST_PIN             

CLR_LED
  
#endif 
                
              __bic_SR_register_on_exit(LPM3_bits); 
            }            
          }
        }
        else
        {
          Capture_D_Counter = 0;
          TB0CCTL1        = 0;
        }        
      }      
      
      break;
    case TB0IV_TB0CCR2:

      Capture_D_Counter = 0;      
      if(READ_PULSE_IN)
      {
        PosEdge_Counter = TB0CCR2;
        Stflag.bit.Pulse_H_Capture = 1;
        Stflag.bit.Pulse_H_Stable = 0;
        Stflag.bit.Pulse_L_Capture = 0;
        
#ifdef SMTEST_PIN        
        SET_INC_BUTTON
#endif          
      }
      else
      {
        NegEdge_Counter = TB0CCR2;        
        Stflag.bit.Pulse_L_Capture = 1;
        Stflag.bit.Pulse_L_Stable = 0;
        Stflag.bit.Pulse_H_Capture = 0;
        
#ifdef SMTEST_PIN         
        CLR_INC_BUTTON        
#endif          
      }
      
#ifdef SMTEST_PIN         
        XOR_PRO_BUTTON        
#endif      
      TB0CCR1         = 3 + TB0R ; 
      TB0CCTL1        = CCIE;

      break;
    case TB0IV_TB0IFG:
      break;
    default:
      break;
  }
}
