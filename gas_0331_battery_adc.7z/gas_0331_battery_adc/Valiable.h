#include "Struct.h"
#include "Lcd.h"

union rtC                       Rtc;
union def_st_flag               Stflag;
union def_Comm_flag             Com;
union def_st_leak_test_flag     leak;
union def_st_port_test_flag     Botton;
union def_lcd_error_flag        LED_error;


st_mem                  Stack;
st_mem_Pressure         Pressure ;
st_mem_ADC              Battery;

const char  LCD_Tab[11]=
{
CHAR_0,// displays "0"
CHAR_1,// displays "1"
CHAR_2,// displays "2"
CHAR_3,// displays "3"
CHAR_4,// displays "4"
CHAR_5,// displays "5"
CHAR_6,// displays "6"
CHAR_7,// displays "7"
CHAR_8,// displays "8"
CHAR_9,// displays "9"
GG     // " - "
 
};

const char  LCD_Tab_Center[14]=
{
CHAR1_0,// displays "0"
CHAR1_1,// displays "1"
CHAR1_2,// displays "2"
CHAR1_3,// displays "3"
CHAR1_4,// displays "4"
CHAR1_5,// displays "5"
CHAR1_6,// displays "6"
CHAR1_7,// displays "7"
CHAR1_8,// displays "8"
CHAR1_9,// displays "9"
CHAR1_A,// " A "
CHAR1_b,// " b "
CHAR1_n,// " n "
CHAR1_r // " r "
};

const char  LCD_ICON[14]=
{
0,
ICON_S1,// displays "����"
ICON_S2,// displays "���"
ICON_S3,// displays "����"
ICON_S4,// displays "�ܺ�"
ICON_S5,// displays "�з�"
ICON_S6,// displays "���"
ICON_S7,// displays "����"
ICON_S8,// displays "�ð�"
ICON_S9,// displays "����"
ICON_S10,// displays "<<>>"
ICON_S11 // displays "ant"
};

const char IOCN_MAP[11] =
{
16,16,16,16,16,16,16,16,1,6,12  
};
  
const char  LCD_ROLL[7]=
{
0,
ROLL_A,// displays "����"
ROLL_B,// displays "���"
ROLL_C,// displays "����"
ROLL_D,// displays "�ܺ�"
ROLL_E,// displays "�з�"
ROLL_F,// displays "���"
};
uint8           Roll = 1;

uint16          Test_0;
uint16          test;

uint8           Bcc1_Xor;
uint8           Bcc2_Sum;
uint8           Buzzer_05s_counter;
uint8           Buzzer_Sec_counter;

uint16          PosEdge_Counter;
uint16          NegEdge_Counter;
uint16          Capture_D_Counter;
uint8           Input_Pulse_Counter;

uint16          Dec_Counter_H;  // 10t  unit  9999 * 10    =  99990   m3
uint16          Dec_Counter_L;  // 1L   unit  9999 L       =  9.999 m3

uint16          Hex_Counter_H;  //
uint16          Hex_Counter_L;  // 10cc unit

uint32          Hex_Counter_025; // 250cc unit max 9999,9999 * 4 = < 32bit Num 

uint16          Instant_Q_Per10_Sec;
uint16          Sum_Q_Per10Sec;

uint8           Sec5_counter;
uint8           Sec10_counter;
uint8           Sec20_counter;
uint8           Min01_counter;
uint8           Min60_counter;

uint16          LowBatteryHour_counter;

uint16          U250_counter;

uint16          St2_Leak_Old_C;
uint16          St2_Leak_Min_counter;

uint16          St3_Over_Old_Q3_1;
uint16          St3_Over_Q3_1_counter;


uint16          St4_Unuse_1min_counter;

uint16          Dec_Pulse_Counter;

uint16          OverQ3_Per_5sec_Value;
uint16          LeakQ3_Per_1min_Value;
uint16          LeakQ1_Per_1min_Value;
uint16          Leak_Per_1min_Counter;

uint8           Button_temp;
uint8           StartTimetemp ;
uint16          CurrentMInStep[10];

uint8           Relese_Unused_counter;
uint8           Relese_Unused_test_on;
uint8           Relese_Unused_test_sec;

uint16          P_test_32hz_counter ;
uint16          Pressure_32hz_counter ;
uint16          ADC_test_32hz_counter ;


