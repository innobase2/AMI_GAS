#include <msp430.h>
#include "MSP_PIN_Con.h"

void Clock_Setting(void);

void Clock_Setting(void)
{
   // PJSEL0 |= BIT4 | BIT5; //lF Crystal
  
  // XT1 Setup ACLK = LFXT = 32768Hz, MCLK = SMCLK = default DCO = 1MHz
  CSCTL0_H = CSKEY >> 8;                    // Unlock CS registers
  CSCTL1 = DCOFSEL_0;                       // Set DCO to 1MHz
  CSCTL2 = SELA__LFXTCLK | SELS__DCOCLK | SELM__DCOCLK; // Set ACLK = XT1; MCLK = DCO
  CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1;     // Set all dividers
  CSCTL4 &= ~LFXTOFF;
  do
  {
    CSCTL5 &= ~LFXTOFFG;                    // Clear XT1 fault flag
    SFRIFG1 &= ~OFIFG;
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag
  CSCTL6 &= ~SMCLKREQEN;                    // FOR LPM0 SMCLK OFF
  CSCTL0_H = 0;                             // Lock CS registers   
  
}
