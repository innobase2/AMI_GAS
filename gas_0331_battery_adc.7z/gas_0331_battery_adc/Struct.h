#include "typedef_SM.h"
//  �� ���� �ð� ���� 
typedef struct {
  uint8 Write           : 1;  
  uint8 Read            : 1;  
  uint8 Sec5             : 1;  
  uint8 Sec10            : 1;
  
  uint8 Sec20            : 1;
  uint8 Min1             : 1;
  uint8 Min10            : 1;
  uint8 Min60            : 1;   

}Rtc_mem;

typedef union rtC
{
  uint8     all;
  Rtc_mem   bit ;  
}rtC;

// ������ ���ۿ� �ʿ��� ���� Ȯ�ο�

typedef struct {
  uint8 Buzzer_Start           : 1;  
  uint8 Buzzer_Doing           : 1;
  uint8 Buzzer_Set             : 1;
  
  uint8 Pulse_H_Capture        : 1; 
  uint8 Pulse_L_Capture        : 1;
  
  uint8 Pulse_H_Stable         : 1;
  uint8 Pulse_L_Stable         : 1;
  uint8 Inc_Pulse_Counter      : 1;
  //---------------------------------------
  uint8 LCD_display            : 1;
  uint8 Unused                 : 1;
  uint8 liter_cal              : 1;
  uint8 Conti_Buzzer           : 1;
  uint8 Entered_Unused         : 1;
  uint8 ADC_display            : 1;

}st_flag_mem;

typedef union def_st_flag
{
  uint16        all;
  st_flag_mem   bit ;  
}def_st_flag;

// --------------��ſ� ����ϴ� ���� --------------------

typedef struct {
  uint8 Ready_EMC             : 1;  
  uint8 Illegal               : 1;
  uint8 Unused                : 1;
  uint8 On_Module             : 1;
}st_com_mem;

typedef union def_Comm_flag
{
  uint16        all;
  st_com_mem    bit ;  
}def_Comm_flag;

//    ------- 32 �ʴ��� ���� ��꿡 ���

typedef struct {
  uint8  temp_counter               : 5;  // 2^5 32
  uint16 Mem[32]               ;
  uint16 deff_32min            ;
  uint16 Liter_per_hour        ;
  uint16 Ing_counter           ;
}st_mem;

//-----�������˿� �����跮�� �������� Flag----
typedef struct {
  uint8 OverQ3                : 1; 
  uint8 Unsued_used           : 1;  //������ �������� ������ ��ư����
  uint8 Used                  : 1;

}st_leak_test;

typedef union def_st_leak_test_flag
{
  uint16          all;
  st_leak_test    bit ;  
}def_st_leak_test_flag;
//----------Button_ ���� ���¿� 

typedef struct {
  uint8 Test_Button_On                : 1; //Leak test mode �϶��� ����
  uint8 P_test                        : 1;
}st_port_test;

typedef union def_st_port_test_flag
{
  uint16          all;
  st_port_test    bit ;  
}def_st_port_test_flag;


//-------pressure--------------------
typedef struct st_mem_Pressure {
  uint16        Counter ;
  uint16        Value                 ;
  uint8         L_Counter              ;
  uint8         H_Counter              ;
  uint8         Normal_Counter         ;
  uint8         Mem[2]                ;
  struct {
                uint8  Delay_on             : 1; 
                uint8  Done                 : 1;  //Leak test mode �϶��� ����
                uint8  Normal               : 1;
  };      

}st_mem_Pressure;

//---------- S1 Error Dispay-----------------
typedef struct {
  uint8 temp               : 1;  
  //uint8 Unused                : 1; 




}st_lcd_error_mem;

typedef union def_lcd_error_flag
{
  uint16              all;
  st_lcd_error_mem    bit ;  
}def_lcd_error_flag;

//-------ADC --------------------
typedef struct st_mem_ADC {
  uint16        Raw_Counter     ;
  uint32        _10mV           ;  
  uint16         Counter         ;
  struct {
                uint8  ADC_on             : 1; 
                uint8  load_En            : 1;  //Leak test mode �϶��� ����
                uint8  ADC_en             : 1;
                uint8  ADC_Start          : 1;
                uint8  ADC_Done           : 1;
                uint8  ADC_Doing          : 1;
                uint8  ADC_loop           : 1;
  };      

}st_mem_ADC;





