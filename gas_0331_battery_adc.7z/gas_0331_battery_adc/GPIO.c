#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Extern_Valiable.h"

void GPIO_Setting(void);

void GPIO_Setting(void)
{
  
  LFT_XTAL_SEL //lF Crystal
  //ALL_PORT_LOW
  //ALL_PORT_OUT
  IN_DIR_INT0EARTH
  IN_DIR_BATT_TEMPER // 16 
  IN_DIR_INT1EARTH

  IN_DIR_P_TEST
  H2L_EDGE_SEL_P_TEST
  FLGA_CLR_P_TEST
  EINT_PORT_P_TEST
  
  CLR_BUZZER  
  OUT_DIR_BUZZER
  CLR_TEST1  
  OUT_DIR_TEST1  
  CLR_TEST2  
  OUT_DIR_TEST2
  CLR_TEST3  
  OUT_DIR_TEST3 
  CLR_LED  
  OUT_DIR_LED
  IN_DIR_D_CHK  
  IN_DIR_PULSE_IN
    PULSE_IN_TB0CCI2A_SEL
  IN_DIR_CO2_SENSOR  
  IN_DIR_GAS_SENSOR
  SET_SV_OUT          // on LDO 
  CLR_SV_OUT          // off LDO      
  OUT_DIR_SV_OUT 
    
  IN_DIR_RETURN
    
  H2L_EDGE_SEL_RETURN
  FLGA_CLR_RETURN
  EINT_PORT_RETURN    
  
#ifndef SMTEST_PIN
    IN_DIR_INC_BUTTON
    H2L_EDGE_SEL_INC_BUTTON
    FLGA_CLR_INC_BUTTON
    EINT_PORT_INC_BUTTON
    
    IN_DIR_DIG_BUTTON
    H2L_EDGE_SEL_DIG_BUTTON
    FLGA_CLR_DIG_BUTTON
    EINT_PORT_DIG_BUTTON 
    
    IN_DIR_PRO_BUTTON 
    H2L_EDGE_SEL_PRO_BUTTON
    FLGA_CLR_PRO_BUTTON
    EINT_PORT_PRO_BUTTON 

#else
    SET_INC_BUTTON
    OUT_DIR_INC_BUTTON
    SET_DIG_BUTTON  
    OUT_DIR_DIG_BUTTON
    SET_PRO_BUTTON  
    OUT_DIR_PRO_BUTTON     
#endif    
    
  CLR_CW  
  OUT_DIR_CW
  CLR_CCW  
  OUT_DIR_CCW
  CLR_DRV_OUT  
  OUT_DIR_DRV_OUT  
  CLR_TEST4
  OUT_DIR_TEST4
  CLR_INITIAL_SETTING
  IN_DIR_INITIAL_SETTING 
  CLR_PULSE_OUT  
  OUT_DIR_PULSE_OUT
  LOW_BATT_ADC_SEL  
  CLR_LOW_BATT_1_EN  
  OUT_DIR_LOW_BATT_1_EN  
  CLR_MODEM_RESET    // RESET LOW  
  OUT_DIR_MODEM_RESET
  CLR_LOW_BATT_1_LOAD
  OUT_DIR_LOW_BATT_1_LOAD
  IN_DIR_MAGNET_CHK    
    
  // Disable the GPIO power-on default high-impedance mode to activate
  // previously configured port settings
  PM5CTL0 &= ~LOCKLPM5;
}

// Port 1 interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
    if(READ_INC_BUTTON == 0)
    {
      Button_temp |= INC_BUTTON; 
    }
    if(READ_PRO_BUTTON == 0)
    {
      Button_temp |= PRO_BUTTON;
    }    
    if(READ_DIG_BUTTON == 0)
    {
      Button_temp |= DIG_BUTTON;
    } 
    if(READ_RETURN == 0)
    {
      P_test_32hz_counter = 0;
      Botton.bit.P_test   = 1;
    }   


    P1IFG = 0;
}
  
// Port 3 interrupt service routine
#pragma vector=PORT3_VECTOR
__interrupt void Port_3(void)
{

    if(READ_P_TEST == 0)
    {
      P_test_32hz_counter = 0;
      Botton.bit.P_test   = 1;
    }   

    P3IFG = 0;
}    


