#include <msp430.h>
#include "MSP_PIN_Con.h"
#include "Valiable.h"
#include "Protocol.h"
#include "Meter_Unit.h"

extern void GPIO_Setting(void);
extern void Clock_Setting(void);
extern void RTC_Init(void);
extern void Lcd_init(void);
extern void Lcd_test(void);
extern void Lcd_Display(void);
extern void Timer_Init(void);
extern void Init_Uart(void);
extern void Inc_meter_value(void);
extern void Init_meter_valiable(void);
extern void Init_I2C_Pressure(void);
extern void Communication(void);
extern void Init_ADC(void);
extern void Battery_Monitor(void);
extern void Read_Pressure_Sensor(void);

void Buzzer_Start(void);
void Buzzer_Stop(void);
extern void Pressure_Sensor(void );


void main(void)
{
  //uint16 temp_main;
  
    WDTCTL = WDTPW | WDTHOLD;                 // Stop Watchdog
//  WDTCTL = WDTPW | WDTTMSEL | WDTSSEL_2 | WDTIS_5; // VLOCLK, ~1s interrupts
//  SFRIE1 |= WDTIE;                          // Enable WDT interrupt

    GPIO_Setting();  // Configure GPIO
    Clock_Setting(); // Clock System Setup
    RTC_Init();
    Lcd_init();
    Lcd_test();
    Timer_Init();
    //Init_Uart();
    Init_meter_valiable();
    //Init_I2C_Pressure(); 
    //Init_ADC();
    //Read_Pressure_Sensor();
    
#if  1 // for test
    Test_0 =0x1234;
    Battery.Raw_Counter = 3103; 
    Battery._10mV = ((uint32)Battery.Raw_Counter * 12 * 33 ) >> 12;   
    Buzzer_Sec_counter = 1;   
    Buzzer_Start();           
#endif    
    _EINT();
    while(1)
    {
      if( ( Stflag.bit.Buzzer_Doing) || (Battery.ADC_Doing)  )
        __low_power_mode_0();
      else
      {
         __low_power_mode_3();
      }
     
   
     Inc_meter_value();
     Pressure_Sensor();
     Battery_Monitor();
     //Lcd_Display();
     ADC_Display();


      __no_operation();                         // For debugger
    }
}

void Buzzer_Start(void)
{
  Stflag.bit.Buzzer_Doing = 1;
  TA1CCR0 = TA1R + 50;
  TA1CCTL0 = CCIE;
  
  TA0CCR1 = TA0R + (32768>>1); // 0.5��
  TA0CCTL1 = CCIE;
  Stflag.bit.Buzzer_Set = 1;
  Buzzer_05s_counter = 0;
    
}

void Buzzer_Stop(void)
{
    CLR_LED;
    CLR_BUZZER;
    Stflag.bit.Buzzer_Doing = 0;
    TA1CCTL0 = 0;
    TA0CCTL1 = 0;  
}



// Watchdog Timer interrupt service routine
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=WDT_VECTOR
__interrupt void WDT_ISR(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(WDT_VECTOR))) WDT_ISR (void)
#else
#error Compiler not supported!
#endif
{
  P1OUT ^= BIT0;                            // Toggle P1.0 (LED)
}
