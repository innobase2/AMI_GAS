
//#define  SMTEST_PIN 
#define  KTC_TEST   

/*

	MSP430FR6977IPNR	Rev2	                ���
PIN NO	PIN NAME	                Net name	
1	P4.3/UCA0RXD	                INT0EARTH	�뵵 ���� �ʿ�
2	P1.4/UCB0CLK/UCA0STE/TA1.0/S3	SEGMENT3	
3	P1.5/UCB0STE/UCA0CLK/TA0.0/S2	SEGMENT2	
4	P1.6/UCB0SIMO/UCB0SDA/TA0.1/S1	SDA_PRESSURE	PART No. Data sheet
5	P1.7/UCB0SOMI/UCB0SCL/TA0.2/S0	SCL_PRESSURE	PART No. Data sheet
6	R33/LCDCAP	                    lCD_LEVEL_OUT	
7	P6.0/R23	                    LCD_LEVEL2	
8	P6.1/R13/LCDREF	                LCD_LEVEL3	
9	P6.2/COUT/R03	                LCD_LEVEL4	
10	P6.3/COM0	                    COM0	
11	P6.4/TB0.0/COM1/S36	            COM1	
12	P6.5/TB0.1/COM2/S35	            COM2	
13	P6.6/TB0.2/COM3/S34	            COM3	
14	P2.4/TB0.3/COM4/S33	            SEGMENT1	
15	P2.5/TB0.4/COM5/S32	            SEGMENT0	
16	P2.6/TB0.5/COM6/S31	            BATT_TEMPER	�뵵 ���� �ʿ�
17	P2.7/TB0.6/COM7/S30	            INT1EARTH	PART No. Data sheet
18	P3.0/UCB1CLK/S29	            P_TEST	        �뵵 ���� �ʿ�
19	P3.1/UCB1SIMO/UCB1SDA/S28	    SDA_EARTH	PART No. Data sheet
20	P3.2/UCB1SOMI/UCB1SCL/S27	    SCL_EARTH	PART No. Data sheet
21	DVSS1	                        GND	
22	DVCC1	                        VCC_3V	
23	MAGNET_CHK/SBWTCK	            SBWTCK	
24	RST/NMI/SBWTDIO	                SBWTDIO	
25	PJ.0/TDO/TB0OUTH/SMCLK/SRSCG1	BUZZER	        ���� ���ļ� �뿪 �ʿ�.
26	PJ.1/TDI/TCLK/MCLK/SRSCG0	    NC	        MAGNET_CHK PIN ó�� ��û 
27	PJ.2/TMS/ACLK/SROSCOFF	        NC	        MAGNET_CHK PIN ó�� ��û
28	PJ.3/TCK/COUT/SRCPUOFF	        NC	        MAGNET_CHK PIN ó�� ��û
29	P6.7/TA0CLK/S26	                SEGMENT16	
30	P7.5/TA0.2/S25	                SEGMENT15	
31	P7.6/TA0.1/S24	                SEGMENT14	
32	P7.7/TA1.2/TB0OUTH/S23	        LED	        �뵵 ���� �ʿ� 
33	P3.3/TA1.1/TB0CLK/S22	        D_CHK	        �뵵 ���� �ʿ�
34	P3.4/UCA1SIMO/UCA1TXD/TB0.0/S21	TX_DPLC	        �������� �ʿ�
35	P3.5/UCA1SOMI/UCA1RXD/TB0.1/S20	RX_DPLC	        �������� �ʿ�
36	P3.6/UCA1CLK/TB0.2/S19	        PULSE_IN	1 Pules 250cc
37	P3.7/UCA1STE/TB0.3/S18	        CO2_SENSOR	
38	P2.3/UCA0STE/TB0OUTH/S17	GAS_SENSOR	
39	P2.2/UCA0CLK/TB0.4/RTCCLK/S16	SV_OUT	        �뵵 ���� �ʿ�
40	P2.1/UCA0RXD/TB0.5/S15	        RX_MODEM	�������� ���� �ʿ�( Battery ���� �κ�)
41	P2.0/UCA0TXD/TB0.6/S14	        TX_MODEM	�������� ���� �ʿ�( Battery ���� �κ�)
42	P7.0/TA0CLK/S13	                SEGMENT13	
43	P7.1/TA0.0/S12	                SEGMENT12	
44	P7.2/TA0.1/S11	                SEGMENT11	
45	P7.3/TA0.2/S10	                SEGMENT10	
46	DVSS2	                        GND	
47	DVCC2	                        VCC_3V	
48	P1.3/TA1.2/A3/C3	            RETURN	
49	P1.2/TA1.1/TA0CLK/COUT/A2/C2	INC_BUTTON	
50	P1.1/TA0.2/TA1CLK/COUT/A1/	    DIG_BUTTON	
51	P1.0/TA0.1/DMAE0/RTCCLK/	    PRO_BUTTON	
52	P9.0/A8/C8	                    CW	        Valve ���� �Ǵ� ���� �ʿ�
53	P9.1/A9/C9	                    CCW	        Valve ���� �Ǵ� ���� �ʿ�
54	P9.2/A10/C10	                DRV_OUT	
55	P9.3/A11/C11	                NC	        MAGNET_CHK PIN ó�� ��û
56	P9.4/A12/C12	                INITIAL_SETTING	�뵵 ���� �ʿ�
57	P9.5/A13/C13	                PULSE_OUT	1 Pules Unit �ʿ�
58	P9.6/A14/C14	                LOW_BATT_1_ADC	Low V �Ǵ� ���� �ʿ�
59	P9.7/A15/C15	                LOW_BATT_1_EN	 Low Battery ���� �ֱ� �ʿ�.
60	DVCC4	                        VCC_3V	
61	DVSS4	                        GND	
62	NC	NC	
63	NC	NC	
64	AVCC1	                        AVCC1	
65	AVSS3	                        GND	
66	PJ.7/HFXOUT	                    MODEM_RESET	�뵵 ���� �ʿ�
67	PJ.6/HFXIN	                    LOW_BATT_1_LOAD	Low Battery ���� �ֱ� �ʿ�.
68	AVSS1	GND	
69	PJ.4/LFXIN	                    32.768	
70	PJ.5/LFXOUT	                    32.768	
71	AVSS2	                        GND	
72	P4.4/UCB1STE/TA1CLK/S9	        SEGMENT9	
73	P4.5/UCB1CLK/TA1.0/S8	        SEGMENT8	
74	P4.6/UCB1SIMO/UCB1SDA/TA1.1/S7	SEGMENT7	
75	P4.7/UCB1SOMI/UCB1SCL/TA1.2/S6	SEGMENT6	
76	P4.0/UCB1SIMO/UCB1SDA/MCLK/S5	SEGMENT5	
77	P4.1/UCB1SOMI/UCB1SCL/ACLK/S4	SEGMENT4	
78	DVSS3	                        GND	
79	DVCC3	                        VCC_3V	
80	P4.2/UCA0TXD	                MAGNET_CHK	�뵵 ���� �ʿ�

*/
//      1	P4.3/UCA0RXD	                        INT0EARTH
#define INT0EARTH                       BIT3 
#define OUT_DIR_INT0EARTH               P4DIR |=INT0EARTH;
#define IN_DIR_INT0EARTH                P4DIR &=~INT0EARTH;
#define SET_INT0EARTH                   P4OUT |=INT0EARTH;
#define CLR_INT0EARTH                   P4OUT &=~INT0EARTH;
#define XOR_INT0EARTH                   P4OUT ^=INT0EARTH;
#define READ_INT0EARTH                  (P4IN & INT0EARTH)

//      2	P1.4/UCB0CLK/UCA0STE/TA1.0/S3	        SEGMENT3
#define SEL_SEGMENT3                    LCDCPCTL0 |= LCDS3;

//      3	P1.5/UCB0STE/UCA0CLK/TA0.0/S2	        SEGMENT2
#define SEL_SEGMENT2                    LCDCPCTL0 |= LCDS2;

//      4	P1.6/UCB0SIMO/UCB0SDA/TA0.1/S1	        SDA_PRESSURE
//      5	P1.7/UCB0SOMI/UCB0SCL/TA0.2/S0	        SCL_PRESSURE
#define SDA_PRESSURE    BIT6 //  
#define SCL_PRESSURE    BIT7 // 
#define I2C_PRESSURE_SEL     P1SEL1 &=~SDA_PRESSURE ; P1SEL0 |= SDA_PRESSURE;\
                             P1SEL1 &=~SCL_PRESSURE ; P1SEL0 |= SCL_PRESSURE;
//      6	R33/LCDCAP	                        LCD_LEVEL_OUT	resis
//      7	P6.0/R23	                        LCD_LEVEL2	resis
//      8	P6.1/R13/LCDREF	                        LCD_LEVEL3	resis
//      9	P6.2/COUT/R03	                        LCD_LEVEL4	resis
//      10	P6.3/COM0	                        COM0	
//      11	P6.4/TB0.0/COM1/S36                     COM1	
//      12	P6.5/TB0.1/COM2/S35             	COM2	
//      13	P6.6/TB0.2/COM3/S34             	COM3	
                             
//      14	P2.4/TB0.3/COM4/S33             	SEGMENT1	seg
#define SEL_SEGMENT1                    LCDCPCTL2 |= LCDS33; 
                             
//      15	P2.5/TB0.4/COM5/S32             	SEGMENT0	seg
#define SEL_SEGMENT0                    LCDCPCTL2 |= LCDS32; 
                             
//	16	P2.6/TB0.5/COM6/S31	                BATT_TEMPER
#define BATT_TEMPER                     BIT3 
#define OUT_DIR_BATT_TEMPER             P2DIR |=BATT_TEMPER;
#define IN_DIR_BATT_TEMPER              P2DIR &=~BATT_TEMPER;
#define SET_BATT_TEMPER                 P2OUT |=BATT_TEMPER;
#define CLR_BATT_TEMPER                 P2OUT &=~BATT_TEMPER;
#define XOR_BATT_TEMPER                 P2OUT ^=BATT_TEMPER;
#define READ_BATT_TEMPER                (P2IN & BATT_TEMPER)

//	17	P2.7/TB0.6/COM7/S30	                INT1EARTH
#define INT1EARTH                       BIT7 
#define OUT_DIR_INT1EARTH               P2DIR |=INT1EARTH;
#define IN_DIR_INT1EARTH                P2DIR &=~INT1EARTH;
#define SET_INT1EARTH                   P2OUT |=INT1EARTH;
#define CLR_INT1EARTH                   P2OUT &=~INT1EARTH;
#define XOR_INT1EARTH                   P2OUT ^=INT1EARTH;
#define READ_INT1EARTH                  (P2IN & INT1EARTH)

//	18	P3.0/UCB1CLK/S29	                P_TEST
#define P_TEST                          BIT0
#define OUT_DIR_P_TEST                  P3DIR |=P_TEST;
#define IN_DIR_P_TEST                   P3DIR &=~P_TEST;
#define SET_P_TEST                      P3OUT |=P_TEST;
#define CLR_P_TEST                      P3OUT &=~P_TEST;
#define XOR_P_TEST                      P3OUT ^=P_TEST;
#define READ_P_TEST                     (P3IN & P_TEST)
#define H2L_EDGE_SEL_P_TEST             P3IES |= P_TEST;                              // P1.1 Hi/Lo edge
#define L2H_EDGE_SEL_P_TEST             P3IES &=~ P_TEST;                             // P1.1 Lo/Hi edge                          
#define EINT_PORT_P_TEST                P3IE  |= P_TEST;                              // P1.1 EINT_EN
#define FLGA_CLR_P_TEST                 P3IFG &=~ P_TEST; 
                             
//	19	P3.1/UCB1SIMO/UCB1SDA/S28	        SDA_EARTH
//	20	P3.2/UCB1SOMI/UCB1SCL/S27	        SCL_EARTH
#define SDA_EARTH    BIT1 //  
#define SCL_EARTH    BIT2 // 
#define I2C_SCL_EARTH_SEL     P3SEL1 &=~SDA_EARTH ; P3SEL0 |= SDA_EARTH;\
                              P3SEL1 &=~SCL_EARTH ; P3SEL0 |= SCL_EARTH;
//	21	DVSS1	                                GND
//	22	DVCC1	                                VCC_3V
//	23	MAGNET_CHK/SBWTCK	                SBWTCK
//	24	RST/NMI/SBWTDIO	                        SBWTDIO
                              
//	25	PJ.0/TDO/TB0OUTH/SMCLK/SRSCG1	        BUZZER
#define BUZZER                          BIT0 
#define OUT_DIR_BUZZER                  PJDIR |=BUZZER;
#define IN_DIR_BUZZER                   PJDIR &=~BUZZER;
#define SET_BUZZER                      PJOUT |=BUZZER;
#define CLR_BUZZER                      PJOUT &=~BUZZER;
#define XOR_BUZZER                      PJOUT ^=BUZZER;
#define READ_BUZZER                     (PJIN & BUZZER) 
//	26	PJ.1/TDI/TCLK/MCLK/SRSCG0
#define TEST1                     BIT1 
#define OUT_DIR_TEST1             PJDIR |=TEST1;
#define IN_DIR_TEST1              PJDIR &=~TEST1;
#define SET_TEST1                 PJOUT |=TEST1;
#define CLR_TEST1                 PJOUT &=~TEST1;
#define XOR_TEST1                 PJOUT ^=TEST1;
#define READ_TEST1                (PJIN & TEST1)
//	27	PJ.2/TMS/ACLK/SROSCOFF
#define TEST2                     BIT2 
#define OUT_DIR_TEST2             PJDIR |=TEST2;
#define IN_DIR_TEST2              PJDIR &=~TEST2;
#define SET_TEST2                 PJOUT |=TEST2;
#define CLR_TEST2                 PJOUT &=~TEST2;
#define XOR_TEST2                 PJOUT ^=TEST2;
#define READ_TEST2                (PJIN & TEST2)
//	28	PJ.3/TCK/COUT/SRCPUOFF
#define TEST3                           BIT3 
#define OUT_DIR_TEST3                   PJDIR |=TEST3;
#define IN_DIR_TEST3                    PJDIR &=~TEST3;
#define SET_TEST3                       PJOUT |=TEST3;
#define CLR_TEST3                       PJOUT &=~TEST3;
#define XOR_TEST3                       PJOUT ^=TEST3;
#define READ_TEST3                      (PJIN & TEST3) 
                              
//	29	P6.7/TA0CLK/S26	SEGMENT16	        seg
#define SEL_SEGMENT16                    LCDCPCTL1 |= LCDS26;   //  0316                            
//	30	P7.5/TA0.2/S25	SEGMENT15	        seg
#define SEL_SEGMENT15                    LCDCPCTL1 |= LCDS25;    //  0316                           
//	31	P7.6/TA0.1/S24	SEGMENT14	        seg
#define SEL_SEGMENT14                    LCDCPCTL1 |= LCDS24;    //  0316
                              
//	32	P7.7/TA1.2/TB0OUTH/S23	                LED	
#define LED                                 BIT7 
#define OUT_DIR_LED                         P7DIR |=LED;
#define IN_DIR_LED                          P7DIR &=~LED;
#define SET_LED                             P7OUT |=LED;
#define CLR_LED                             P7OUT &=~LED;
#define XOR_LED                             P7OUT ^=LED;
#define READ_LED                            (P7IN & LED) 
//	33	P3.3/TA1.1/TB0CLK/S22	                D_CHK                              
#define D_CHK                                   BIT3
#define OUT_DIR_D_CHK                           P3DIR |=D_CHK;
#define IN_DIR_D_CHK                            P3DIR &=~D_CHK;
#define SET_D_CHK                               P3OUT |=D_CHK;
#define CLR_D_CHK                               P3OUT &=~D_CHK;
#define XOR_D_CHK                               P3OUT ^=D_CHK;
#define READ_D_CHK                              (P3IN & D_CHK)                              
//	34	P3.4/UCA1SIMO/UCA1TXD/TB0.0/S21	        TX_DPLC	uart
//	35	P3.5/UCA1SOMI/UCA1RXD/TB0.1/S20	        RX_DPLC	uart
#define TX_DPLC        BIT1 
#define RX_DPLC        BIT0 
#define UART1_DPLC_SEL      P3SEL1 &=~TX_DPLC ; P3SEL0 |= TX_DPLC;\
                            P3SEL1 &=~RX_DPLC ; P3SEL0 |= RX_DPLC;
//	36	P3.6/UCA1CLK/TB0.2/S19	                PULSE_IN
#define PULSE_IN                        BIT6
#define OUT_DIR_PULSE_IN                P3DIR |=PULSE_IN;
#define IN_DIR_PULSE_IN                 P3DIR &=~PULSE_IN;
#define SET_PULSE_IN                    P3OUT |=PULSE_IN;
#define CLR_PULSE_IN                    P3OUT &=~PULSE_IN;
#define XOR_PULSE_IN                    P3OUT ^=PULSE_IN;
#define READ_PULSE_IN                   (P3IN & PULSE_IN) 
#define PULSE_IN_TB0CCI2A_SEL           P3SEL1 |= PULSE_IN ; P3SEL0 &=~PULSE_IN;                           
//	37	P3.7/UCA1STE/TB0.3/S18	                CO2_SENSOR
#define CO2_SENSOR                      BIT7
#define OUT_DIR_CO2_SENSOR              P3DIR |=CO2_SENSOR;
#define IN_DIR_CO2_SENSOR               P3DIR &=~CO2_SENSOR;
#define SET_CO2_SENSOR                  P3OUT |=CO2_SENSOR;
#define CLR_CO2_SENSOR                  P3OUT &=~CO2_SENSOR;
#define XOR_CO2_SENSOR                  P3OUT ^=CO2_SENSOR;
#define READ_CO2_SENSOR                 (P3IN & CO2_SENSOR)                            
//	38	P2.3/UCA0STE/TB0OUTH/S17	        GAS_SENSOR
#define GAS_SENSOR                      BIT3 // 2.3 - 30
#define OUT_DIR_GAS_SENSOR              P2DIR |=GAS_SENSOR;
#define IN_DIR_GAS_SENSOR               P2DIR &=~GAS_SENSOR;
#define SET_GAS_SENSOR                  P2OUT |=GAS_SENSOR;
#define CLR_GAS_SENSOR                  P2OUT &=~GAS_SENSOR;
#define XOR_GAS_SENSOR                  P2OUT ^=GAS_SENSOR;
#define READ_GAS_SENSOR                 (P2IN & GAS_SENSOR)                            
//	39	P2.2/UCA0CLK/TB0.4/RTCCLK/S16	        SV_OUT
#define SV_OUT                          BIT2
#define OUT_DIR_SV_OUT                  P2DIR |=SV_OUT;
#define IN_DIR_SV_OUT                   P2DIR &=~SV_OUT;
#define SET_SV_OUT                      P2OUT |=SV_OUT;
#define CLR_SV_OUT                      P2OUT &=~SV_OUT;
#define XOR_SV_OUT                      P2OUT ^=SV_OUT;
#define READ_SV_OUT                     (P2IN & SV_OUT)                            
//	40	P2.1/UCA0RXD/TB0.5/S15	RX_MODEM
//	41	P2.0/UCA0TXD/TB0.6/S14	TX_MODEM
#define RX_MODEM        BIT1 
#define TX_MODEM        BIT0 
#define UART0_MODEM_SEL      P2SEL1 &=~RX_MODEM ; P2SEL0 |= RX_MODEM;\
                             P2SEL1 &=~TX_MODEM ; P2SEL0 |= TX_MODEM;
                             
//	42	P7.0/TA0CLK/S13	                        SEGMENT13
#define SEL_SEGMENT13                    LCDCPCTL0 |= LCDS13;                             
//	43	P7.1/TA0.0/S12	                        SEGMENT12
#define SEL_SEGMENT12                    LCDCPCTL0 |= LCDS12;                             
//	44	P7.2/TA0.1/S11	                        SEGMENT11
#define SEL_SEGMENT11                    LCDCPCTL0 |= LCDS11;                               
//	45	P7.3/TA0.2/S10	                        SEGMENT10
#define SEL_SEGMENT10                    LCDCPCTL0 |= LCDS10; 
                             
//	46	DVSS2	                                GND
//	47	DVCC2	                                VCC_3V
                             
//	48	P1.3/TA1.2/A3/C3	                RETURN
#define RETURN                          BIT3 
#define OUT_DIR_RETURN                  P1DIR |=RETURN;
#define IN_DIR_RETURN                   P1DIR &=~RETURN;
#define SET_RETURN                      P1OUT |=RETURN;
#define CLR_RETURN                      P1OUT &=~RETURN;
#define XOR_RETURN                      P1OUT ^=RETURN;
#define READ_RETURN                     (P1IN & RETURN) 
#define H2L_EDGE_SEL_RETURN             P1IES |= RETURN;                              // P1.1 Hi/Lo edge
#define L2H_EDGE_SEL_RETURN             P1IES &=~ RETURN;                             // P1.1 Lo/Hi edge                          
#define EINT_PORT_RETURN                P1IE  |= RETURN;                              // P1.1 EINT_EN
#define FLGA_CLR_RETURN                 P1IFG &=~ RETURN;                              
//	49	P1.2/TA1.1/TA0CLK/COUT/A2/C2	        INC_BUTTON
#define INC_BUTTON                      BIT2
#define OUT_DIR_INC_BUTTON              P1DIR |=INC_BUTTON;
#define IN_DIR_INC_BUTTON               P1DIR &=~INC_BUTTON;
#define SET_INC_BUTTON                  P1OUT |=INC_BUTTON;
#define CLR_INC_BUTTON                  P1OUT &=~INC_BUTTON;
#define XOR_INC_BUTTON                  P1OUT ^=INC_BUTTON;
#define READ_INC_BUTTON                 (P1IN & INC_BUTTON) 
#define H2L_EDGE_SEL_INC_BUTTON         P1IES |= INC_BUTTON;                              // P1.1 Hi/Lo edge
#define L2H_EDGE_SEL_INC_BUTTON         P1IES &=~ INC_BUTTON;                             // P1.1 Lo/Hi edge                          
#define EINT_PORT_INC_BUTTON            P1IE  |= INC_BUTTON;                              // P1.1 EINT_EN
#define FLGA_CLR_INC_BUTTON             P1IFG &=~ INC_BUTTON;                              
//	50	P1.1/TA0.2/TA1CLK/COUT/A1/C1/V(E)REF+	DIG_BUTTON
#define DIG_BUTTON                      BIT1 
#define OUT_DIR_DIG_BUTTON              P1DIR |=DIG_BUTTON;
#define IN_DIR_DIG_BUTTON               P1DIR &=~DIG_BUTTON;
#define SET_DIG_BUTTON                  P1OUT |=DIG_BUTTON;
#define CLR_DIG_BUTTON                  P1OUT &=~DIG_BUTTON;
#define XOR_DIG_BUTTON                  P1OUT ^=DIG_BUTTON;
#define READ_DIG_BUTTON                 (P1IN & DIG_BUTTON)
#define H2L_EDGE_SEL_DIG_BUTTON         P1IES |= DIG_BUTTON;                              // P1.1 Hi/Lo edge
#define L2H_EDGE_SEL_DIG_BUTTON         P1IES &=~ DIG_BUTTON;                             // P1.1 Lo/Hi edge                          
#define EINT_PORT_DIG_BUTTON            P1IE  |= DIG_BUTTON;                              // P1.1 EINT_EN
#define FLGA_CLR_DIG_BUTTON             P1IFG &=~ DIG_BUTTON;                             
//	51	P1.0/TA0.1/DMAE0/RTCCLK/A0/C0/V(E)REF-	PRO_BUTTON
#define PRO_BUTTON                      BIT0 
#define OUT_DIR_PRO_BUTTON              P1DIR |=PRO_BUTTON;
#define IN_DIR_PRO_BUTTON               P1DIR &=~PRO_BUTTON;
#define SET_PRO_BUTTON                  P1OUT |=PRO_BUTTON;
#define CLR_PRO_BUTTON                  P1OUT &=~PRO_BUTTON;
#define XOR_PRO_BUTTON                  P1OUT ^=PRO_BUTTON;
#define READ_PRO_BUTTON                 (P1IN & PRO_BUTTON)
#define H2L_EDGE_SEL_PRO_BUTTON         P1IES |= PRO_BUTTON;                              // P1.1 Hi/Lo edge
#define L2H_EDGE_SEL_PRO_BUTTON         P1IES &=~ PRO_BUTTON;                             // P1.1 Lo/Hi edge                          
#define EINT_PORT_PRO_BUTTON            P1IE  |= PRO_BUTTON;                              // P1.1 EINT_EN
#define FLGA_CLR_PRO_BUTTON             P1IFG &=~ PRO_BUTTON;                               
//	52	P9.0/A8/C8	                        CW
#define CW                              BIT0 
#define OUT_DIR_CW                      P9DIR |=CW;
#define IN_DIR_CW                       P9DIR &=~CW;
#define SET_CW                          P9OUT |=CW;
#define CLR_CW                          P9OUT &=~CW;
#define XOR_CW                          P9OUT ^=CW;
#define READ_CW                         (P9IN & CW)                              
//	53	P9.1/A9/C9	                        CCW
#define CCW                             BIT1 
#define OUT_DIR_CCW                     P9DIR |=CCW;
#define IN_DIR_CCW                      P9DIR &=~CCW;
#define SET_CCW                         P9OUT |=CCW;
#define CLR_CCW                         P9OUT &=~CCW;
#define XOR_CCW                         P9OUT ^=CCW;
#define READ_CCW                        (P9IN & CCW)                               
//	54	P9.2/A10/C10	                        DRV_OUT
#define DRV_OUT                         BIT2 // J.2 - 23
#define OUT_DIR_DRV_OUT                 P9DIR |=DRV_OUT;
#define IN_DIR_DRV_OUT                  P9DIR &=~DRV_OUT;
#define SET_DRV_OUT                     P9OUT |=DRV_OUT;
#define CLR_DRV_OUT                     P9OUT &=~DRV_OUT;
#define XOR_DRV_OUT                     P9OUT ^=DRV_OUT;
#define READ_DRV_OUT                    (P9IN & DRV_OUT) 
//	55	P9.3/A11/C11	                        NC
#define TEST4                           BIT3 
#define OUT_DIR_TEST4                   P9DIR |=TEST4;
#define IN_DIR_TEST4                    P9DIR &=~TEST4;
#define SET_TEST4                       P9OUT |=TEST4;
#define CLR_TEST4                       P9OUT &=~TEST4;
#define XOR_TEST4                       P9OUT ^=TEST4;
#define READ_TEST4                      (P9IN & TEST4)  
//	56	P9.4/A12/C12	                        INITIAL_SETTING
#define INITIAL_SETTING                 BIT4 
#define OUT_DIR_INITIAL_SETTING         P9DIR |=INITIAL_SETTING;
#define IN_DIR_INITIAL_SETTING          P9DIR &=~INITIAL_SETTING;
#define SET_INITIAL_SETTING             P9OUT |=INITIAL_SETTING;
#define CLR_INITIAL_SETTING             P9OUT &=~INITIAL_SETTING;
#define XOR_INITIAL_SETTING             P9OUT ^=INITIAL_SETTING;
#define READ_INITIAL_SETTING            (P9IN & INITIAL_SETTING)                             
//	57	P9.5/A13/C13	                        PULSE_OUT
#define PULSE_OUT                       BIT5
#define OUT_DIR_PULSE_OUT               P9DIR |=PULSE_OUT;
#define IN_DIR_PULSE_OUT                P9DIR &=~PULSE_OUT;
#define SET_PULSE_OUT                   P9OUT |=PULSE_OUT;
#define CLR_PULSE_OUT                   P9OUT &=~PULSE_OUT;
#define XOR_PULSE_OUT                   P9OUT ^=PULSE_OUT;
#define READ_PULSE_OUT                  (P9IN & PULSE_OUT)                             
//	58	P9.6/A14/C14	                        LOW_BATT_1_ADC
#define LOW_BATT_1_ADC                  BIT5
#define LOW_BATT_ADC_SEL                P9SEL1 |= LOW_BATT_1_ADC ; P9SEL0 |= LOW_BATT_1_ADC;                             
//	59	P9.7/A15/C15	                        LOW_BATT_1_EN
#define LOW_BATT_1_EN                   BIT7 
#define OUT_DIR_LOW_BATT_1_EN           P9DIR |=LOW_BATT_1_EN;
#define IN_DIR_LOW_BATT_1_EN            P9DIR &=~LOW_BATT_1_EN;
#define SET_LOW_BATT_1_EN               P9OUT |=LOW_BATT_1_EN;
#define CLR_LOW_BATT_1_EN               P9OUT &=~LOW_BATT_1_EN;
#define XOR_LOW_BATT_1_EN               P9OUT ^=LOW_BATT_1_EN;
#define READ_LOW_BATT_1_EN              (P9IN & LOW_BATT_1_EN)
                             
//	60	DVCC4	                                VCC_3V
//	61	DVSS4	                                GND
//	62	NC	                                NC
//	63	NC	                                NC
//	64	AVCC1	                                AVCC1
//	65	AVSS3	                                GND
                             
//	66	PJ.7/HFXOUT	                        MODEM_RESET
#define MODEM_RESET                     BIT7 
#define OUT_DIR_MODEM_RESET             PJDIR |=MODEM_RESET;
#define IN_DIR_MODEM_RESET              PJDIR &=~MODEM_RESET;
#define SET_MODEM_RESET                 PJOUT |=MODEM_RESET;
#define CLR_MODEM_RESET                 PJOUT &=~MODEM_RESET;
#define XOR_MODEM_RESET                 PJOUT ^=MODEM_RESET;
#define READ_MODEM_RESET                (PJIN & MODEM_RESET)
//	67	PJ.6/HFXIN	                        LOW_BATT_1_LOAD
#define LOW_BATT_1_LOAD                 BIT6 
#define OUT_DIR_LOW_BATT_1_LOAD         PJDIR |=LOW_BATT_1_LOAD;
#define IN_DIR_LOW_BATT_1_LOAD          PJDIR &=~LOW_BATT_1_LOAD;
#define SET_LOW_BATT_1_LOAD             PJOUT |=LOW_BATT_1_LOAD;
#define CLR_LOW_BATT_1_LOAD             PJOUT &=~LOW_BATT_1_LOAD;
#define XOR_LOW_BATT_1_LOAD             PJOUT ^=LOW_BATT_1_LOAD;
#define READ_LOW_BATT_1_LOAD            (PJIN & LOW_BATT_1_LOAD)                              
//	68	AVSS1	GND
                             
//	69	PJ.4/LFXIN	                        32.768
//	70	PJ.5/LFXOUT	                        32.768
#define LFT_XTAL_SEL                    PJSEL0 |= BIT4 | BIT5; //lF Crystal
                             
//	71	AVSS2	GND
//	72	P4.4/UCB1STE/TA1CLK/S9	                SEGMENT9
#define SEL_SEGMENT9                    LCDCPCTL0 |= LCDS9;                               
//	73	P4.5/UCB1CLK/TA1.0/S8	                SEGMENT8
#define SEL_SEGMENT8                    LCDCPCTL0 |= LCDS8;                              
//	74	P4.6/UCB1SIMO/UCB1SDA/TA1.1/S7	        SEGMENT7
#define SEL_SEGMENT7                    LCDCPCTL0 |= LCDS7;                               
//	75	P4.7/UCB1SOMI/UCB1SCL/TA1.2/S6	        SEGMENT6
#define SEL_SEGMENT6                    LCDCPCTL0 |= LCDS6;                               
//	76	P4.0/UCB1SIMO/UCB1SDA/MCLK/S5	        SEGMENT5
#define SEL_SEGMENT5                    LCDCPCTL0 |= LCDS5;                              
//	77	P4.1/UCB1SOMI/UCB1SCL/ACLK/S4	        SEGMENT4
#define SEL_SEGMENT4                    LCDCPCTL0 |= LCDS4;                              
//	78	DVSS3	GND
//	79	DVCC3	VCC_3V
                             
//	80	P4.2/UCA0TXD	                        MAGNET_CHK
#define MAGNET_CHK                      BIT2 
#define OUT_DIR_MAGNET_CHK            P4DIR |=MAGNET_CHK;
#define IN_DIR_MAGNET_CHK             P4DIR &=~MAGNET_CHK;
#define SET_MAGNET_CHK                P4OUT |=MAGNET_CHK;
#define CLR_MAGNET_CHK                P4OUT &=~MAGNET_CHK;
#define XOR_MAGNET_CHK                P4OUT ^=MAGNET_CHK;
#define READ_MAGNET_CHK               (P4IN & MAGNET_CHK)                             

                           
// COM 0 ~ 3
#define COM0_PIN        BIT3 // 6.3 - 10  P6SEL1 &=~COM0_PIN ; P6SEL0 |= COM0_PIN; OR 
#define COM1_PIN        BIT4 // 6.4 - 11  P6SEL1 &=~COM1_PIN ; P6SEL0 |= COM1_PIN;
#define COM2_PIN        BIT5 // 6.5 - 12  P6SEL1 &=~COM2_PIN ; P6SEL0 |= COM2_PIN;
#define COM3_PIN        BIT6 // 6.6 - 13  P6SEL1 &=~COM3_PIN ; P6SEL0 |= COM3_PIN;
#define LCD_COMx_PIN_SEL  P6SEL1 |= COM0_PIN ; P6SEL0 |= COM0_PIN;\
                          P6SEL1 |= COM1_PIN ; P6SEL0 |= COM1_PIN;\
                          P6SEL1 |= COM2_PIN ; P6SEL0 |= COM2_PIN;\
                          P6SEL1 |= COM3_PIN ; P6SEL0 |= COM3_PIN;  
// R03 ~ R33
#define R23_PIN         BIT0 // 6.0 - 7   P6SEL1 |= R23_PIN ; P6SEL0 |= R23_PIN;
#define R13_PIN         BIT1 // 6.1 - 8   P6SEL1 |= R13_PIN ; P6SEL0 |= R13_PIN;
#define R03_PIN         BIT2 // 6.2 - 9   P6SEL1 |= R03_PIN ; P6SEL0 |= R03_PIN;
#define LCD_RX3_PIN_SEL   P6SEL1 |= R23_PIN ; P6SEL0 |= R23_PIN;\
                          P6SEL1 |= R13_PIN ; P6SEL0 |= R13_PIN;\
                          P6SEL1 |= R03_PIN ; P6SEL0 |= R03_PIN;  


#define ALL_PORT_LOW   P1DIR = P2DIR = P3DIR = P4DIR = P5DIR = P6DIR = P7DIR = P8DIR = P9DIR = PJDIR = 0XFF;                               
                          
#define ALL_PORT_OUT   P1OUT = P2OUT = P3OUT = P4OUT = P5OUT = P6OUT = P7OUT = P8OUT = P9OUT = PJOUT = 0; 
/*
#define OUT_DIR_        P3DIR |=
#define IN_DIR_         P3DIR &=~
#define SET_            P3OUT |=
#define CLR_            P3OUT &=~
#define XOR_            P3OUT ^=
#define READ_           (P3IN & )
                          
#define H2L_EDGE_SEL   P1IES |= BIT1;                              // P1.1 Hi/Lo edge
#define L2H_EDGE_SEL   P1IES &=~ BIT1;                             // P1.1 Lo/Hi edge                          
#define EINT_PORT_     P1IE  |= BIT1;                              // P1.1 EINT_EN
#define FLGA_CLR       P1IFG &=~ BIT1;                             // Clear all P1 interrupt flags                         
                         
*/
