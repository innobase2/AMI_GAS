#include "Struct.h"
#include "Lcd.h"

extern union rtC                        Rtc;
extern union def_st_flag                Stflag;
extern union def_Comm_flag              Com;
extern union def_st_leak_test_flag      leak;
extern union def_st_port_test_flag      Botton;
extern union def_lcd_error_flag         LED_error;


extern st_mem                  Stack;
extern st_mem_Pressure         Pressure ;
extern st_mem_ADC              Battery;

extern const char       LCD_Tab[11];
extern const char       LCD_Tab_Center[14];
extern const char       LCD_ICON[14];
extern const char       IOCN_MAP[11];
extern const char       LCD_ROLL[7];


extern uint8           Roll;

extern uint16          Test_0;
extern uint16          test;

extern uint8           Bcc1_Xor;
extern uint8           Bcc2_Sum;
extern uint8           Buzzer_05s_counter;
extern uint8           Buzzer_Sec_counter;

extern uint16          PosEdge_Counter;
extern uint16          NegEdge_Counter;
extern uint16          Capture_D_Counter;
extern uint8           Input_Pulse_Counter;

extern uint16          Dec_Counter_H;
extern uint16          Dec_Counter_L;

extern uint16          Hex_Counter_H;
extern uint16          Hex_Counter_L;

extern uint32           Hex_Counter_025;

extern uint16          Instant_Q_Per10_Sec;
extern uint16          Sum_Q_Per10Sec;

extern uint8           Sec5_counter;
extern uint8           Sec10_counter;
extern uint8           Sec20_counter;
extern uint8           Min01_counter;
extern uint8           Min60_counter;

extern uint16          LowBatteryHour_counter;

extern uint16          U250_counter;

extern uint16          St2_Leak_Old_C;
extern uint16          St2_Leak_Min_counter;

extern uint16          St3_Over_Old_Q3_1;
extern uint16          St3_Over_Q3_1_counter;

extern uint16          St4_Unuse_1min_counter;

extern uint16          Dec_Pulse_Counter;

extern uint16          OverQ3_Per_5sec_Value;
extern uint16          LeakQ3_Per_1min_Value;
extern uint16          LeakQ1_Per_1min_Value;
extern uint16          Leak_Per_1min_Counter;

extern uint8           Button_temp ;
extern uint8           StartTimetemp;
extern uint16          CurrentMInStep[10];

extern uint8           Relese_Unused_counter;
extern uint8           Relese_Unused_test_on;
extern uint8           Relese_Unused_test_sec;

extern uint16          P_test_32hz_counter ;
extern uint16          ADC_test_32hz_counter ;
